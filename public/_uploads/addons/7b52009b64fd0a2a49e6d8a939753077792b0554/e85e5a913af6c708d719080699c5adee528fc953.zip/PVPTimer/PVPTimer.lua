--[[
	PVP Timer 0.03 by EVmaker
	
	A simple mod to display the remaining time left on the players flagged PVP timer either in its own window,
	or in a LDB Displayer (Titan, Fubar, etc..)
]]--

-- Declare the locals
local PVPT_EML = "PVPTimer";
local debugMode = false;
local PVPT_updateInterval = 1.0;
local PVPT_defaultSettings = {
["Version"] = "0.03",
["OnOff"] = true,
["ShowWindow"] = true
}
local playFaction, _ = UnitFactionGroup("player");
local factionColors = {
	["Red"] = EML_getColor("red"),
	["Blue"] = EML_getColor("blue"),
	["Yellow"] = EML_getColor("yellow")
}
local backR,backG,backB,textR,textG,textB;
if (playFaction == "Horde") then
	backR,backG,backB = EML_splitTable(factionColors.Red);
	textR,textG,textB = EML_splitTable(factionColors.Yellow);
else
	backR,backG,backB = EML_splitTable(factionColors.Blue);
	textR,textG,textB = EML_splitTable(factionColors.Yellow);
end

-- Declare the global variables
PVPT_whatTimer = "wait";
PVPT_Settings = {
["Version"] = "0.03";
["OnOff"] = true,
["ShowWindow"] = true
}

-- Setup stuff
function PVPT_OnLoad()
	this:RegisterEvent("PLAYER_ENTERING_WORLD");
	this:RegisterEvent("UNIT_FACTION");
	this:RegisterEvent("CHAT_MSG_SYSTEM");
	SLASH_PVPT1 = "/pvptimer"
	SLASH_PVPT2 = "/pvpt"
	SlashCmdList["PVPT"] = function(msg)
		PVPT_SlashHandler(msg);
	end
	EMLChat("PVP Timer "..PVPT_defaultSettings["Version"].." loaded","plainchat",PVPT_EML,"teal")
end

function PVPT_OnEvent(event)
	if (event == "PLAYER_ENTERING_WORLD") then
		if (PVPT_Settings["OnOff"]) then
			PVPT_updatePVP()
		end
		if (PVPT_Settings["Version"] ~= PVPT_defaultSettings["Version"]) then
			if (debugMode) then EMLChat("Version is different.","chat",PVPT_EML) end
			PVPT_Reset("version")
		else
			if (debugMode) then EMLChat("Version is the same.","chat",PVPT_EML) end
		end
	end
	if (event == "CHAT_MSG_SYSTEM" and PVPT_Settings["OnOff"]) then
		if (arg1 == "You will be unflagged for PvP combat after five minutes of non-PvP action in friendly territory.") then
			PVPT_whatTimer = "wait";
			PVPT_updatePVP()
		end
	end
	if (event == "UNIT_FACTION" and arg1 == "player" and PVPT_Settings["OnOff"]) then
		PVPT_whatTimer = "wait";
		PVPT_updatePVP()
	end
end

function PVPT_SlashHandler(theMsg)
	msg = strtrim(strlower(theMsg or ""))
	if msg == "version" then
		EMLChat("This version of PVP Timer is: "..PVPT_defaultSettings["Version"],"chat",PVPT_EML)
	elseif msg == "debug" then
		if (debugMode) then
			debugMode = false;
			EMLChat("Toggling debug mode off","chat",PVPT_EML)
		else
			debugMode = true;
			EMLChat("Toggling debug mode on","chat",PVPT_EML)
		end
	elseif msg == "reset" then
		PVPT_Reset()
	elseif msg == "window" then
		PVPT_whatTimer = "wait";
		local WindowStatus = EMLFrame_Toggle("PVPT1");
		if (WindowStatus == "show") then 
			EMLFrame_Toggle("PVPT_Timer","open")
		else
			EMLFrame_Toggle("PVPT_Timer","close")
		end
	elseif msg == "toggle pvptimer" then
		if (PVPT_Settings["OnOff"]) then
			PVPT_Settings["OnOff"]=false;
			EMLChat("PVP Timer toggled off.","chat",PVPT_EML)
		else
			PVPT_Settings["OnOff"]=true;
			EMLChat("PVP Timer toggled on.","chat",PVPT_EML)
		end
	elseif msg == "toggle window" then
		if (PVPT_Settings["ShowWindow"]) then
			PVPT_Settings["ShowWindow"]=false;
			EMLChat("PVP Timer's window will not be shown.","chat",PVPT_EML)
		else
			PVPT_Settings["ShowWindow"]=true;
			EMLChat("PVP Timer's window will be shown.","chat",PVPT_EML)
		end
	elseif msg == "toggle status" then
		if (PVPT_Settings["OnOff"]) then
			EMLChat("PVP Timer is on.","chat",PVPT_EML,"green")
		else
			EMLChat("PVP Timer is off.","chat",PVPT_EML,"red")
		end
		if (PVPT_Settings["ShowWindow"]) then
			EMLChat("PVP Timer's window will be shown.","chat",PVPT_EML,"green")
		else
			EMLChat("PVP Timer's window will not be shown.","chat",PVPT_EML,"red")
		end
	elseif msg == "test1" then
		PVPT_testFunction()
	elseif msg == "authors" then
		EMLChat("evmaker, the Lua Coder.","chat",PVPT_EML)
	elseif msg == "evmaker" then
		EMLChat("EVmaker codes the Lua (only) part of the mod.","chat",PVPT_EML)
	else
		EMLChat("Valid Options:","chat",PVPT_EML)
		EMLChat("toggle status (shows the status of PVP Timer's settings)","chat",PVPT_EML)
		EMLChat("toggle pvptimer (turns PVP Timer on or off)","chat",PVPT_EML)
		EMLChat("toggle window (turns whether to display the timer window on or off)","chat",PVPT_EML)
		EMLChat("-----------------","chat",PVPT_EML)
		EMLChat("Other Commands:","chat",PVPT_EML)
		EMLChat("window (opens or closes the PVP Timer window)","chat",PVPT_EML)
		EMLChat("version (displays PVP Timers version)","chat",PVPT_EML)
		EMLChat("-----------------","chat",PVPT_EML)
		EMLChat("Authors, slashes for them as well.","chat",PVPT_EML)
	end
end

-- Functions for testing code
function PVPT_testFunction(arg)
	EMLChat("Test Function 1:","chat",PVPT_EML,"teal")
	local testArray = PVPT_pvpCheck();
	if (testArray) then
		EMLChat("PVP Timer is running, with "..testArray.Minutes.." minutes and "..testArray.Seconds.." seconds left.","chat",PVPT_EML)
	end
end
-- End of test functions

-- Resets and updates settings
function PVPT_Reset(arg)
	local localSettings = EML_copyTable(PVPT_defaultSettings);
	PVPT_Settings=EML_mergeTable(PVPT_Settings,localSettings);
	if (arg == "version") then
		PVPT_Settings["Version"]=localSettings["Version"];
		EMLChat("Version is changed, resetting and updating settings.","chat",PVPT_EML)
	else
		EMLChat("Everythings reset","chat",PVPT_EML)
		EML_clearTable(PVPT_Settings)
		PVPT_Settings=localSettings;
	end
end

-- Returns the remaining time on the players pvp timer or nil (doesn't have one)
function PVPT_getPVP(arg)
	local pvpArray = {};
	local isPvP = IsPVPTimerRunning();
	if (isPvP) then
		pvpArray["Running"] = IsPVPTimerRunning();
		pvpArray["TimeLeft"] = tonumber(floor(GetPVPTimer()/1000));
		pvpArray["Minutes"] = tonumber(floor(pvpArray["TimeLeft"]/60));
		pvpArray["Seconds"] = tonumber(pvpArray["TimeLeft"]%60);
	else
		if (PVPT_whatTimer == "wait") then EMLFrame_Toggle("PVPT_Timer","open") end
		return nil;
	end
	return pvpArray;
end

-- Sets up the PVP Timer window
function PVPT_displayWindow(arg)
	if (arg == "open" and PVPT_Settings["OnOff"] and PVPT_Settings["ShowWindow"]) then
		EMLFrame_Toggle("PVPT1","open")
		EMLFrame_Toggle("PVPT_Timer","open")
	elseif (arg == "close" and PVPT_Settings["OnOff"]) then
		EMLFrame_Toggle("PVPT1","close")
		EMLFrame_Toggle("PVPT_Timer","open")
	else
		EMLFrame_Toggle("PVPT_Timer","open")
	end
end

-- Sets the display's information
function PVPT_updatePVP()
	local pvpArray = PVPT_getPVP();
	if (pvpArray) then
		local theText = tostring(pvpArray.Minutes.."."..pvpArray.Seconds);
		PVPT_Color:SetVertexColor(backR,backG,backB);
		PVPT_textTime:SetText(theText)
		PVPT_textTime:SetTextColor(textR,textG,textB)
		PVPT_displayWindow("open")
	else
		PVPT_Color:SetVertexColor(1,1,1);
		PVPT_textTime:SetText("0")
		PVPT_textTime:SetTextColor(1,1,0);
		PVPT_displayWindow("close")
	end	
end

-- Timer to delay actions
function PVPT_waitTimer(self,elapsed,whatDo)
	local isPvP = IsPVPTimerRunning();
	self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed;
	if (whatDo == "normal") then
		if (not isPvP) then
			self.TimeSinceLastUpdate = 0;
			PVPT_Timer:Hide()
			PVPT_updatePVP()
			PVPT_whatTimer = "wait";
			if (debugMode) then EMLChat("Normal Ran.","chat",PVPT_EML) end
		end
	elseif (whatDo == "wait") then
		if (self.TimeSinceLastUpdate > (PVPT_updateInterval*2)) then
			self.TimeSinceLastUpdate = 0;
			PVPT_updatePVP()
			PVPT_whatTimer = "normal";
			if (debugMode) then EMLChat("Wait Ran.","chat",PVPT_EML) end
		end
	end
	if (self.TimeSinceLastUpdate > PVPT_updateInterval and whatDo == "normal") then
		self.TimeSinceLastUpdate = 0;
		PVPT_updatePVP()
	end
end
-- End of code