Readme for PVP Timer, a World of Warcraft Mod.
----

Version 0.03
PVP Timer by EVmaker

A simple mod to display the remaining time left on the players flagged PVP timer either in its own window,
or in a LDB Displayer (Titan, Fubar, etc.., in the next release).  PVP Timer's window can be placed wherever
you wish and it will remember its location, it can be opened manually (/pvpt window) or open itself
automatically when your pvp countdown starts (if showing its window is on, which is the default).

Commands:
/pvpt version (shows the version)
/pvpt window (opens PVP Timer's window)
/pvpt toggle {option} (see below)
Options:
/pvpt toggle status (shows what's on or off)
/pvpt toggle pvptimer (toggles PVP Timer on or off)
/pvpt toggle window (whether to automatically display its window or not)

A GUI for these options, and an LDB displayer will be in the next release.
----
Todos:

In-Line Todos:
	* Add LDB (Titan Panel, Fubar, etc..) support.
	* Add a basic GUI.
	* Add options for customizing displayed colors.

Future Todo:
	* TBD

Eternal Todos:
	* Eliminate any bugs (if any)
----------------------------------------------------------------------
Changelog:
0.03:
3.3 Compatibility and TOC Update.

0.02b:
3.2 Compatibility and TOC Update.  Essentially just an update for the TOC, so that 'load out of date addons' does not need to be
checked, since PVPTimer was 3.2 Compatible already.

0.01b:
Initial release, has the PVP Timer window which displays the time remaining on your pvp counter, colored by faction (red and yellow
for horde, blue and yellow for alliance).  Slash options for whether to show the window constantly (/pvpt toggle window) and to turn
the mod itself on or off (pvpt toggle pvptimer).  Mod is also already 3.2 Compatible.