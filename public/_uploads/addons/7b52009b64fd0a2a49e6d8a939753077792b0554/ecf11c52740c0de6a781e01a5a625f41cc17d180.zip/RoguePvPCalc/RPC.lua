-- Rogue PvP Calculator
-- By GT4 / Hidden@Nazjatar-EU / Tanny@Blackmoore-EU

resilience = 493
armor = 3000
dodge = 0
parry = 0
crit = 0
ap = 0
hit = 0
expert = 0
mainspeed = 2.4
mainnspeed = 2.4
maindps = 0
offspeed = 1.7
offnspeed = 1.7
offdps = 0

-- talents
t_m = 0
t_pw = 0
t_l = 0
t_iks = 0
t_sf = 0
t_fw = 0
t_p = 0
t_dws = 0
t_ms = 0
t_bf = 0
t_ss = 0
t_we = 0
t_cp = 0
t_o = 0
t_sb = 0


function out(str)
	local at = 1
	for i=1, string.len(str), 1 do
		if ((string.sub(str,(i+1),(i+1)) == "$") or (string.len(str)==i)) then
			DEFAULT_CHAT_FRAME:AddMessage(tostring(string.sub(str,at,(i))));
			at = i+2
		end;
	end
end

function round(num, idp)
    local mult = 10^(idp or 0)
    return math.floor(num * mult + 0.5) / mult
end


out("Rogue PvP Calculator loaded - /rpc or /rp for options");

SLASH_RoguePvPCalc1 = "/rpc";
SLASH_RoguePvPCalc2 = "/rp";
SlashCmdList["RoguePvPCalc"] = function(msg)
	RPC_CommandHandler(msg);
end

function RPC_CommandHandler(msg)
	if (string.len(msg) == 0) then
		out("RoguePvPCalc - Commands List (Usually the current value is returned if you give no value)$- /rp resi | armor | dodge | parry <value> : Change the enemy Resilience/Armor/Dodge Chance/Parry Chance to <value>$- /rp loadstats : Automatically gets your relevant character stats for calculations$- /rp ap | crit | hitrating | expertiserating <value> : Manually changes your Attack Power/Crit Rate/Hit Rating/Expertise Rating to <value>$- /rp loadweapons : Automatically gets your equippted Weapons$- /rp loadtalents : Automatically gets your talent spec$- /rp calc auto | muti : Calculates damage for Auto Hits/Mutilate$- /rp loadall : Loads all your character data");
		return
	end;
	local rtext = nil
	local cmd = {}
	local begin = 1
	local run = 1
	for i=1, string.len(msg) ,1 do
		if (string.sub(msg, i, i) == " ") then
			if (string.sub(msg, begin, i-1) ~= "") then
				cmd[run] = string.sub(msg, begin, i-1)
				run = run+1
			end;
			begin = i+1
		end;
		if (i == string.len(msg)) then
			cmd[run] = string.sub(msg, begin, i)
		end;
	end
	
	
	if (cmd[1] == "resi") then
		if (cmd[2] == nil) then
			rtext = "Enemy Resilience is currently set to " .. resilience
			else
			resilience = cmd[2]
			rtext = "Enemy Resilience set to " .. resilience
		end;
	end;
	
	if (cmd[1] == "armor") then
		if (cmd[2] == nil) then
			rtext = "Enemy Armor is currently set to " .. armor
			else
			armor = cmd[2]
			rtext = "Enemy Armor set to " .. armor
		end;
	end;
	
	if (cmd[1] == "dodge") then
		if (cmd[2] == nil) then
			rtext = "Enemy Dodge Chance is currently set to " .. dodge
			else
			dodge = cmd[2]
			rtext = "Enemy Dodge Chance set to " .. dodge
		end;
	end;
	
	if (cmd[1] == "parry") then
		if (cmd[2] == nil) then
			rtext = "Enemy Armor is currently set to " .. parry
			else
			parry = cmd[2]
			rtext = "Enemy Armor set to " .. parry
		end;
	end;
	
	if (cmd[1] == "loadstats") then
		crit = GetCritChance()
		local base, posBuff, negBuff = UnitAttackPower("player")
		ap = base + posBuff + negBuff
		hit = GetCombatRating(6)
		expert = GetCombatRating(24)
		rtext = "Crit Chance: " .. round(crit,4) .. "$Attack Power: " .. ap .. "$Hit Rating: " .. hit .. "$Expertise Rating: " .. expert
	end;
	
	if (cmd[1] == "ap") then
		if (cmd[2] == nil) then
			rtext = "Attack Power is currently set to " .. ap
			else
			ap = cmd[2]
			rtext = "Attack Power set to " .. ap
		end;
	end;
	
	if (cmd[1] == "crit") then
		if (cmd[2] == nil) then
			rtext = "Crit Chance is currently set to " .. crit
			else
			crit = cmd[2]
			rtext = "Crit Chance set to " .. crit
		end;
	end;
	
	if (cmd[1] == "hitrating") then
		if (cmd[2] == nil) then
			rtext = "Hit Rating is currently set to " .. hit
			else
			hit = cmd[2]
			rtext = "Hit Rating set to " .. hit
		end;
	end;
	
	if (cmd[1] == "expertiserating") then
		if (cmd[2] == nil) then
			rtext = "Expertise Rating is currently set to " .. expert
			else
			expert = cmd[2]
			rtext = "Expertise Rating set to " .. expert
		end;
	end;
	
	if (cmd[1] == "loadweapons") then
		mainspeed, offspeed = UnitAttackSpeed("player");
		local lowDmg, hiDmg, offlowDmg, offhiDmg, posBuff, negBuff, percentmod = UnitDamage("player");
		local base, posBuff, negBuff = UnitAttackPower("player")		
		maindps = ((lowDmg+hiDmg)/2)/mainspeed-(base+posBuff+negBuff)/14
		offdps = (((offlowDmg+offhiDmg)/2)/offspeed)*(100/(50+(TPoints(2,12))*5))-(base+posBuff+negBuff)/14
		if (getType(16) == "Daggers") then
			mainnspeed = 1.7
			else
			mainnspeed = 2.4
		end;
		if (getType(17) == "Daggers") then
			offnspeed = 1.7
			else
			offnspeed = 2.4
		end;
		rtext = "Main-hand Weapon DPS: " .. round(maindps,2) .. "$Main-hand Weapon Speed: " .. mainspeed .. "$Main-hand Normalization Speed: " .. mainnspeed .. "$Off-hand Weapon DPS: " .. round(offdps,2) .. "$Off-hand Weapon Speed: " .. offspeed .. "$Off-hand Normalization Speed: " .. offnspeed
	end;
	
	if (cmd[1] == "loadtalents") then
		t_m = TPoints(1,5)
		t_pw = TPoints(1,6)
		t_l = TPoints(1,9)
		t_iks = TPoints(1,14)
		t_sf = TPoints(1,16)
		t_fw = TPoints(1,20)
		t_p = TPoints(2,6)
		t_dws = TPoints(2,12)
		t_ms = TPoints(2,13)
		t_bf = TPoints(2,14)
		t_ss = TPoints(2,15)
		t_we = TPoints(2,18)
		t_cp = TPoints(2,23)
		t_o = TPoints(3,2)
		t_sb = TPoints(3,11)
		rtext = "Murder: " .. t_m .. "$Puncturing Wounds: " .. t_pw .. "$Lethality: " .. t_l .. "$Improved Kidney Shot: " .. t_iks .. "$Seal Fate: " .. t_sf .. "$Find Weakness: " .. t_fw .. "$Precision: " .. t_p .. "$Dual Wield Specialization: " .. t_dws .. "$Mace Specialization: " .. t_ms .. "$Blade Flurry: " .. t_bf .. "$Sword Specialization: " .. t_ss .. "$Weapon Expertise: " .. t_we .. "$Combat Potency: " .. t_cp .. "$Opportunity: " .. t_o .. "$Serrated Blades: " .. t_sb
	end;
	
	if (cmd[1] == "loadall") then
		crit = GetCritChance()
		local base, posBuff, negBuff = UnitAttackPower("player")
		ap = base + posBuff + negBuff
		hit = GetCombatRating(6)
		expert = GetCombatRating(24)
		mainspeed, offspeed = UnitAttackSpeed("player");
		local lowDmg, hiDmg, offlowDmg, offhiDmg, posBuff, negBuff, percentmod = UnitDamage("player");
		local base, posBuff, negBuff = UnitAttackPower("player")		
		maindps = ((lowDmg+hiDmg)/2)/mainspeed-(base+posBuff+negBuff)/14
		offdps = (((offlowDmg+offhiDmg)/2)/offspeed)*(100/(50+(TPoints(2,12))*5))-(base+posBuff+negBuff)/14
		if (getType(16) == "Daggers") then
			mainnspeed = 1.7
			else
			mainnspeed = 2.4
		end;
		if (getType(17) == "Daggers") then
			offnspeed = 1.7
			else
			offnspeed = 2.4
		end;
		t_m = TPoints(1,5)
		t_pw = TPoints(1,6)
		t_l = TPoints(1,9)
		t_iks = TPoints(1,14)
		t_sf = TPoints(1,16)
		t_fw = TPoints(1,20)
		t_p = TPoints(2,6)
		t_dws = TPoints(2,12)
		t_ms = TPoints(2,13)
		t_bf = TPoints(2,14)
		t_ss = TPoints(2,15)
		t_we = TPoints(2,18)
		t_cp = TPoints(2,23)
		t_o = TPoints(3,2)
		t_sb = TPoints(3,11)
		rtext = "Character Data loaded"
	end;
	
	if (cmd[1] == "calc") then
		if (cmd[2] == "auto") then
			rtext = "Autohit DPS: " .. round(AutohitDPS(),2) .. "$DPS Increase of 2 AP: " .. round((AutohitDPS(2,0,0,0,0,0,0)-AutohitDPS()),4) .. "$DPS Increase of 1 Agility: " .. round((AutohitDPS(1,(1/40),0,0,0,0,0)-AutohitDPS()),4) .. " (worth " .. round((2*(AutohitDPS(1,(1/40),0,0,0,0,0)-AutohitDPS())/(AutohitDPS(2,0,0,0,0,0,0)-AutohitDPS())),3) .. " AP)" .. "$DPS Increase of 1 Crit Rating: " .. round((AutohitDPS(0,(1/22.08),0,0,0,0,0)-AutohitDPS()),4) .. " (worth " .. round((2*(AutohitDPS(0,(1/22.08),0,0,0,0,0)-AutohitDPS())/(AutohitDPS(2,0,0,0,0,0,0)-AutohitDPS())),3) .. " AP)" .. "$DPS Increase of 1 Hit Rating: " .. round((AutohitDPS(0,0,1,0,0,0,0)-AutohitDPS()),4) .. " (worth " .. round((2*(AutohitDPS(0,0,1,0,0,0,0)-AutohitDPS())/(AutohitDPS(2,0,0,0,0,0,0)-AutohitDPS())),3) .. " AP)"
		end;
		if (cmd[2] == "muti") then
			local damage, energy = mutilate()
			rtext = "Mutilate Average(/w Find Weakness): " .. round(damage,2) .. " damage / " .. round(energy,2) .. " energy ( " .. round(damage/energy,3) .. " DpE )"
			local damageap, energyap = mutilate(2,0,0,0,0,0,0)
			rtext = rtext .. "$DpE Increase of 2 AP: " .. round(((damageap/energyap)-(damage/energy)),5)
			local damageagi, energyagi = mutilate(1,(1/40),0,0,0,0,0)
			rtext = rtext .. "$DpE Increase of 1 Agi: " .. round(((damageagi/energyagi)-(damage/energy)),5) .. " (worth " .. round((2*((damageagi/energyagi)-(damage/energy))/((damageap/energyap)-(damage/energy))),3) .. " AP)"
			local damagecrit, energycrit = mutilate(0,(1/22.08),0,0,0,0,0)
			rtext = rtext .. "$DpE Increase of 1 Crit Rating: " .. round(((damagecrit/energycrit)-(damage/energy)),5) .. " (worth " .. round((2*((damagecrit/energycrit)-(damage/energy))/((damageap/energyap)-(damage/energy))),3) .. " AP)"
			local damagehit, energyhit = mutilate(0,0,1,0,0,0,0)
			rtext = rtext .. "$DpE Increase of 1 Hit Rating: " .. round(((damagehit/energyhit)-(damage/energy)),5) .. " (worth " .. round((2*((damagehit/energyhit)-(damage/energy))/((damageap/energyap)-(damage/energy))),3) .. " AP)"
		end;
	end;
	
	if (rtext ~= nil) then
		out("RoguePvPCalc - Command '" .. msg .. "' executed$" .. rtext);
		else
		out("RoguePvPCalc - Command '" .. msg .. "' not found");
	end;
end

function getType(int)
	local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(GetInventoryItemLink("player",int))	
	return itemSubType
end

function TPoints(tab, talent)
	local nameTalent, iconPath, tier, column, currentRank, maxRank, isExceptional, meetsPrereq = GetTalentInfo(tab, talent);	
	return currentRank
end

function AutohitDPS(plusap, pluscrit, plushit, plusmaindps, plusoffdps, plusexpert, plusapen)
	if (plusap == nil) then
		plusap = 0
	end;
	if (plushit == nil) then
		plushit = 0
	end;
	if (pluscrit == nil) then
		pluscrit = 0
	end;
	if (plusmaindps == nil) then
		plusmaindps = 0
	end;
	if (plusoffdps == nil) then
		plusoffdps = 0
	end;
	if (plusexpert == nil) then
		plusexpert = 0
	end;
	if (plusapen == nil) then
		plusapen = 0
	end;
	local a_armor = math.max((armor-plusapen),0)
	local a_ap = ap+plusap
	local a_crit = crit+pluscrit
	local a_hit = hit+plushit
	local a_expert = (expert+plusexpert)/3.92
	local a_maindps = maindps+plusmaindps
	local a_offdps = offdps+plusoffdps
	local misschance = math.max(0,(0.24-a_hit/1577-t_p*0.01))
	local parrychance = math.max(0,(parry/100-a_expert/400-t_we/80))
	local dodgechance = math.max(0,(dodge/100-a_expert/400-t_we/80))
	local critchance = math.min(math.max(0,(a_crit/100-resilience/3940)),(1-misschance-parrychance-dodgechance))
	local hitchance = (math.max(0, (1-misschance-parrychance-dodgechance-critchance) ))
	local basedps = ((a_maindps+a_ap/14)+((a_offdps+a_ap/14)*(50+t_dws*5)/100))
	local critmod = 2*(1-resilience/1970)
	local totaldps = (basedps*hitchance+basedps*critchance*critmod)*(1-a_armor/(a_armor+10557.5))
	return totaldps
end

function mutilate(plusap, pluscrit, plushit, plusmaindps, plusoffdps, plusexpert, plusapen)
	if (plusap == nil) then
		plusap = 0
	end;
	if (plushit == nil) then
		plushit = 0
	end;
	if (pluscrit == nil) then
		pluscrit = 0
	end;
	if (plusmaindps == nil) then
		plusmaindps = 0
	end;
	if (plusoffdps == nil) then
		plusoffdps = 0
	end;
	if (plusexpert == nil) then
		plusexpert = 0
	end;
	if (plusapen == nil) then
		plusapen = 0
	end;
	local a_armor = math.max((armor-plusapen),0)
	local a_ap = ap+plusap
	local a_crit = crit+pluscrit
	local a_hit = hit+plushit
	local a_expert = (expert+plusexpert)/3.92
	local a_maindps = maindps+plusmaindps
	local a_offdps = offdps+plusoffdps
	local misschance = math.max(0,(0.05-a_hit/1577-t_p*0.01))	
	local critchance = math.max(0,(a_crit/100-resilience/3940+t_pw*0.05))
	local offdmg = 101+(a_offdps*offspeed+a_ap/14*offnspeed)*(50+t_dws*5)/100
	local maindmg = 101+a_maindps*mainspeed+a_ap/14*mainnspeed
	local critmod = (2+t_l*0.06)*(1-resilience/1970)
	local averagedamage = ((offdmg+maindmg)*(1+t_o*0.04)*1.5*(1-misschance-critchance)+(offdmg+maindmg)*(1+t_o*0.04)*1.5*critchance*critmod)*(1+0.02*t_fw)
	local cost = 60-12*misschance
	return averagedamage, cost
end