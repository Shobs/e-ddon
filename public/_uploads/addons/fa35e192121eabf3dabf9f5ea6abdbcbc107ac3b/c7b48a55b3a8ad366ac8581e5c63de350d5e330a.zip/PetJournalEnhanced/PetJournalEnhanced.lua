local SETTINGS_VERSION = 7
local SORT_LEVEL = 1
local SORT_ALPHA = 2
local SORT_PETTYPE = 3
local SORT_RARITY = 4
local SORT_MAXSTAT =5
local SORT_PETID = 6
local MAX_BALANCED = 0
local MAX_ATTACK = 5
local MAX_SPEED = 10
local MAX_STAMINA = 15
local ASCENDING =  1
local DESCENDING = 2

PetJournalEnhanced = CreateFrame("frame")
PetJournalEnhanced.PetJournal_UpdatePetListOld = nil
PetJournalEnhanced.petMapping = nil
PetJournalEnhanced.numPets = 0;
PetJournalEnhanced.numOwned = 0;
PetJournalEnhanced.GetPetInfoByIndex =  C_PetJournal.GetPetInfoByIndex
PetJournalEnhanced.GetNumPets = C_PetJournal.GetNumPets


PetJournalEnhanced.PetJournal_UpdatePetCardPostHook = function()
	if PetJournalPetCard.petID  then
		local speciesID, customName, level, xp, maxXp, displayID, name, icon, petType, creatureID, sourceText, description, isWild, canBattle, tradable = C_PetJournal.GetPetInfoByPetID(PetJournalPetCard.petID)
	    if canBattle and (PetJournalEnhancedOptions.showExtraPetInfo or isWild) then
			local health, maxHealth, power, speed, rarity = C_PetJournal.GetPetStats(PetJournalPetCard.petID)
			PetJournalPetCard.QualityFrame.quality:SetText(_G["BATTLE_PET_BREED_QUALITY"..rarity])
			local color = ITEM_QUALITY_COLORS[rarity-1]
			PetJournalPetCard.QualityFrame.quality:SetVertexColor(color.r, color.g, color.b)
			PetJournalPetCard.QualityFrame:Show()
		else
			PetJournalPetCard.QualityFrame:Hide()
		end
	end
end

PetJournalEnhanced.PetJournalFilterDropDown_Reload = function(self)
	UIDropDownMenu_Initialize(PetJournalFilterDropDown,self.PetJournalFilterDropDown , "MENU")
end

PetJournalEnhanced.PetJournalFilterDropDown = function(self, level)
	PetJournalFilterDropDown_Initialize(self, level)
	local info = UIDropDownMenu_CreateInfo()
	
	
	if level == 1 then
		info.keepShownOnClick = true
		info.checked = 	nil
		info.isNotRadio = nil
		info.func =  nil
		info.hasArrow = true
		info.notCheckable = true		
		info.text = "Sort Options"
		info.value = 3
		UIDropDownMenu_AddButton(info, level)
		
		
		
		
		info = UIDropDownMenu_CreateInfo()
		
		info.keepShownOnClick = false
		info.checked = PetJournalEnhancedOptions.showExtraPetInfo
		info.isNotRadio = true
	
		info.text = "Show additional pet info"
		info.func = 	function(_, _, _, value)
					
					PetJournalEnhancedOptions.showExtraPetInfo = not PetJournalEnhancedOptions.showExtraPetInfo
					PetJournalEnhanced:PetJournal_UpdatePetListPostHook()
					PetJournalEnhanced:PetJournal_UpdatePetCardPostHook()
				end 
		info.checked = function() return PetJournalEnhancedOptions.showExtraPetInfo end
		UIDropDownMenu_AddButton(info, level)
		
		info.text = "Filter pets by current zone"
		info.func = 	function(_, _, _, value)
					
					PetJournalEnhancedOptions.filterByZone = not PetJournalEnhancedOptions.filterByZone
					PetJournalEnhanced:SortPets()
					
				end 
		info.checked = function() return PetJournalEnhancedOptions.filterByZone end
		UIDropDownMenu_AddButton(info, level)
	
	end
	if level == 2 and UIDROPDOWNMENU_MENU_VALUE == 3 then
		info.keepShownOnClick = true
		info.text = "Sort Order:"
		info.func = nil;
		info.notCheckable = true		
		UIDropDownMenu_AddButton(info, level)
		
		info.notCheckable = false;	
		local sortTypes = {["Level"] = SORT_LEVEL, ["Alphabetical"]= SORT_ALPHA, ["Pet Type"]= SORT_PETTYPE, ["Rarity"]= SORT_RARITY, ["Pet Highest Stat"]= SORT_MAXSTAT,["Added to Pet Journal"]=SORT_PETID}
		
		for sortName,sortValue in pairs(sortTypes) do 
		
			info.keepShownOnClick = true
			info.checked = false
			info.isNotRadio = false
			info.text = sortName
			info.func = 	function(_, _, _, value)
						
						PetJournalEnhancedOptions.sortSelection = sortValue
						UIDropDownMenu_Refresh(PetJournalFilterDropDown,1,2)
						PetJournalEnhanced:SortPets()
					end 
			info.checked = function() return PetJournalEnhancedOptions.sortSelection == sortValue end
			UIDropDownMenu_AddButton(info, level)
		
		end
		
		info.keepShownOnClick = true
		info.checked = false
		info.isNotRadio = false
		
		
		info.text = "Sort Direction:"
		info.func = nil;
		info.notCheckable = true		
		UIDropDownMenu_AddButton(info, level)
		
		info.notCheckable = false;	
		info.text = "Sort Ascending"
		info.func = 	function(_, _, _, value)
					
					PetJournalEnhancedOptions.sortOrder = ASCENDING
					UIDropDownMenu_Refresh(PetJournalFilterDropDown,1,2)
					PetJournalEnhanced:SortPets()
				end 
		info.checked = function() return PetJournalEnhancedOptions.sortOrder ==  ASCENDING end
		UIDropDownMenu_AddButton(info, level)
		
		info.text = "Sort Descending"
		info.func = 	function(_, _, _, value)
					PetJournalEnhancedOptions.sortOrder = DESCENDING
					UIDropDownMenu_Refresh(PetJournalFilterDropDown,1,2)
					PetJournalEnhanced:SortPets()
					
				end 
		info.checked = function() return  PetJournalEnhancedOptions.sortOrder == DESCENDING end
		UIDropDownMenu_AddButton(info, level)
	end
	
	if level == 2 and UIDROPDOWNMENU_MENU_VALUE == 4 then
		
	end

end

PetJournalEnhanced.PetJournal_UpdatePetListPostHook= function()
	
	local scrollFrame = PetJournal.listScroll
	local offset = HybridScrollFrame_GetOffset(scrollFrame)
	local petButtons = scrollFrame.buttons
	local pet
	
	pcall(PetJournalEnhanced.PetJournal_UpdatePetListOld)
	 
	for i = 1,#petButtons do
		pet = petButtons[i]
		if not pet.highStat then
			pet.highStat = pet:CreateTexture(nil,"OVERLAY")
			pet.highStat:SetTexture("Interface\\PetBattles\\PetBattle-StatIcons")
			pet.highStat:SetTexCoord(0.0,0.5,0.0,0.5)
			pet.highStat:SetSize(12,12)
			pet.highStat:SetPoint("BOTTOMLEFT",pet.icon,"BOTTOMLEFT",2,1)
			pet.highStat:SetDrawLayer("OVERLAY", 7)
			
			pet.highStatBg = pet:CreateTexture(nil,"OVERLAY",2)
			pet.highStatBg:SetTexture("Interface\\PetBattles\\PetJournal")
			pet.highStatBg:SetTexCoord(0.06835938,0.10937500,0.02246094,0.04296875)
			pet.highStatBg:SetSize(21,21)
			pet.highStatBg:SetPoint("BOTTOMLEFT",pet.icon,"BOTTOMLEFT",-3,-3)
			pet.highStatBg:SetDrawLayer("OVERLAY", 6)
		end
		
		pet.highStat:Hide()
		pet.highStatBg:Hide()
		
		if pet.petID and pet.owned then
			local speciesID, customName, level, xp, maxXp, displayID, name, icon, petType, creatureID, sourceText, description, isWild, canBattle, tradable = C_PetJournal.GetPetInfoByPetID(pet.petID)
			if canBattle and pet.petID then
				local health, maxHealth, attack, speed, rarity = C_PetJournal.GetPetStats(pet.petID)
				
				
				if PetJournalEnhancedOptions.showExtraPetInfo then
					if rarity then
						pet.iconBorder:SetVertexColor(ITEM_QUALITY_COLORS[rarity-1].r, ITEM_QUALITY_COLORS[rarity-1].g, ITEM_QUALITY_COLORS[rarity-1].b)
						pet.iconBorder:Show()
					end
					
					if  pet.owned and canBattle then
						local maxStat = PetJournalEnhanced.GetMaxStat(maxHealth,attack,speed)
						
						if maxStat == MAX_BALANCED then
							pet.highStat:SetTexCoord(0.0,0.0,0.0,0.0)
							pet.highStat:Hide()
							pet.highStatBg:Hide()
						else
							if maxStat == MAX_ATTACK then
								pet.highStat:SetTexCoord(0.0,0.5,0.0,0.5)
							elseif maxStat == MAX_STAMINA then
								pet.highStat:SetTexCoord(0.5,1.0,0.5,1.0)
							elseif maxStat == MAX_SPEED then
								pet.highStat:SetTexCoord(0.0,0.5,0.5,1)
							end
							pet.highStat:Show()
							pet.highStatBg:Show()
						end
					end
				end
			end
		end
	end
end

 PetJournalEnhanced.InitPetJournal = function(self)
	PetJournalEnhanced:PetJournalFilterDropDown_Reload()
	hooksecurefunc("PetJournal_UpdatePetCard", self.PetJournal_UpdatePetCardPostHook)
	
	PetJournal.listScroll.update = PetJournalEnhanced.PetJournal_UpdatePetListPostHook
	PetJournalEnhanced.PetJournal_UpdatePetListOld = PetJournal_UpdatePetList
	PetJournal_UpdatePetList = PetJournalEnhanced.PetJournal_UpdatePetListPostHook
end

C_PetJournal.GetPetInfoByIndex = function(index,isWild)
	if PetJournalEnhanced.petMapping and PetJournalEnhanced.petMapping[index] then
		return PetJournalEnhanced.GetPetInfoByIndex(PetJournalEnhanced.petMapping[index].index,isWild)
	end
	return PetJournalEnhanced.GetPetInfoByIndex(index,isWild)
end

C_PetJournal.GetNumPets = function(isWild)
	return PetJournalEnhanced.numPets, PetJournalEnhanced.numOwned;
end



PetJournalEnhanced.GetSortFunctions = function(self)
	local sortFunctions = {}
	local levelThenName = self.GetCompareFunc("level", self.GetCompareFunc("name",nil,ASCENDING))
	sortFunctions[SORT_LEVEL] = self.GetCompareFunc("isOwned", levelThenName , DESCENDING)
	sortFunctions[SORT_ALPHA] = self.GetCompareFunc("isOwned", self.GetCompareFunc("name", self.GetCompareFunc("level")) , DESCENDING)
	sortFunctions[SORT_PETTYPE] = self.GetCompareFunc("isOwned" , self.GetCompareFunc("petType", levelThenName) , DESCENDING )
	sortFunctions[SORT_RARITY] = self.GetCompareFunc("isOwned" , self.GetCompareFunc("rarity", levelThenName) , DESCENDING )
	sortFunctions[SORT_MAXSTAT] = self.GetCompareFunc("isOwned" , self.GetCompareFunc("maxStat",levelThenName) , DESCENDING ) 
	sortFunctions[SORT_PETID] = self.GetCompareFunc("isOwned" , self.GetCompareFunc("petID",self.GetCompareFunc("name",nil, ASCENDING)) , DESCENDING)
	return sortFunctions
end

PetJournalEnhanced.GetCompareFunc = function(var,func,direction)
	
	return function(a,b)
		
		
		local avar = a[var] 
		local bvar = b[var]
		if type(avar) == "boolean" then 
			avar = avar and 1 or 0
			bvar = bvar and 1 or 0 
		end
		
		if avar == bvar and func then 
			return func(a,b)
		end
		
		
		if direction and direction == ASCENDING then
			return avar < bvar
		elseif direction and direction == DESCENDING then
			return avar > bvar
			
		elseif  PetJournalEnhancedOptions.sortOrder == ASCENDING then
			return avar < bvar
		elseif PetJournalEnhancedOptions.sortOrder == DESCENDING then
			return avar > bvar
		end
		
		
	end
end

PetJournalEnhanced.GetMaxStat=function(maxHealth,attack,speed)
	
	maxHealth = tonumber(maxHealth)
	stamina = tonumber(math.floor((maxHealth -100)/5))
	attack = tonumber(attack)
	speed = tonumber(speed)
	
	if attack > speed and attack > stamina then 
		return MAX_ATTACK 
	elseif speed > attack and speed > stamina  then 
		return MAX_SPEED 
	elseif stamina > attack and stamina > speed  then 
		return MAX_STAMINA 
	end
	
	return MAX_BALANCED
end

PetJournalEnhanced.Reset = function()
	PetJournalEnhancedOptions = {}
	PetJournalEnhancedOptions.SettingsVersion = SETTINGS_VERSION
	PetJournalEnhancedOptions.showExtraPetInfo = false
	PetJournalEnhancedOptions.sortSelection = {}
	PetJournalEnhancedOptions.sortSelection = 1
	PetJournalEnhancedOptions.filterByZone = false;
	PetJournalEnhancedOptions.sortOrder = ASCENDING
end




PetJournalEnhanced.SortPets = function(self)
	if IsAddOnLoaded("Blizzard_PetJournal") then 
		PetJournalEnhanced.numOwned = 0;
		PetJournalEnhanced.numPets = 0;
		local numPets = PetJournalEnhanced.GetNumPets(PetJournal.isWild)
		self.petMapping = {}
		for i=1,numPets do
			local petID, speciesID, isOwned, customName, level, favorite, isRevoked, name, icon, petType, creatureID, sourceText, description, isWildPet, canBattle = PetJournalEnhanced.GetPetInfoByIndex(i, PetJournal.isWild)
			local health, maxHealth, attack, speed, rarity = C_PetJournal.GetPetStats(petID)
			
			pet = {["petID"] = petID, ["speciesID"] = speciesID, ["isOwned"] = isOwned, ["customName"] = customName, ["level"] = level, ["favorite"] = favorite, ["isRevoked"] = isRevoked, ["name"] =name, ["icon"] =icon,["petType"]=petType, ["creatureID"] = creatureID, ["sourceText"] = sourceText, ["description"] = description, ["isWildPet"] = isWildPet, [ "canBattle"] = canBattle }
			pet.index = i
			pet.health = health
			pet.maxHealth = maxHealth
			pet.attack = attack
			pet.speed = speed
			pet.rarity = rarity
			pet.health = 0
			pet.maxHealth = 0
			pet.attack = 0
			pet.speed = 0
			pet.rarity = rarity
			pet.maxStat = 0
			if petID and petID > 0 and canBattle and maxHealth and attack and speed then
				pet.maxStat = PetJournalEnhanced.GetMaxStat(maxHealth,attack,speed)
			end
			
			--/run x={};p = C_PetJournal;print(GetZoneText());for i=1,p.GetNumPets(false) do id,_,_,_,_,_,_,n,_,_,_,d=p.GetPetInfoByIndex(i);if string.find(d, GetZoneText()) and not x[n] then if id>0 then print(p.GetBattlePetLink(id));else print(n);x[n]=1;end end end
			--filter here
			--if 
			if PetJournalEnhancedOptions.filterByZone then
				if string.find(sourceText, GetZoneText(),1,true) then
					if isOwned then PetJournalEnhanced.numOwned = PetJournalEnhanced.numOwned +1 end
					PetJournalEnhanced.numPets = PetJournalEnhanced.numPets + 1;
					table.insert(self.petMapping,pet)
				end
			else
				if isOwned then PetJournalEnhanced.numOwned = PetJournalEnhanced.numOwned +1 end
				PetJournalEnhanced.numPets = PetJournalEnhanced.numPets + 1;
				table.insert(self.petMapping,pet)
			end
		end
		
		table.sort(self.petMapping,PetJournalEnhanced.SortFunctions[PetJournalEnhancedOptions.sortSelection])
	end
	self:PetJournal_UpdatePetListPostHook()
end

PetJournalEnhanced:SetScript("OnEvent", function(self, event, ...)
	
	if event == "ADDON_LOADED" then 
		local name , arg1 = ...
		if name == "Blizzard_PetJournal" then
			
		elseif name== "PetJournalEnhanced" then
			local loaded, reason = LoadAddOn("Blizzard_PetJournal")
			
			if not PetJournalEnhancedOptions or not PetJournalEnhancedOptions.SettingsVersion or PetJournalEnhancedOptions.SettingsVersion ~= SETTINGS_VERSION then
				self:Reset()
			end
			
			if loaded then 
				PetJournalEnhanced:InitPetJournal()
				self:UnregisterEvent("ADDON_LOADED")
			end
		end
	elseif event == "PET_JOURNAL_LIST_UPDATE" or event == "PET_JOURNAL_PET_DELETED" or event == "COMPANION_UPDATE"  or event == "ZONE_CHANGED_NEW_AREA" or event == "ZONE_CHANGED" then	
			self:SortPets()
	end
 end)
 
PetJournalEnhanced:RegisterEvent("PET_JOURNAL_LIST_UPDATE")
PetJournalEnhanced:RegisterEvent("ADDON_LOADED")
PetJournalEnhanced:RegisterEvent("PET_JOURNAL_PET_DELETED")
PetJournalEnhanced:RegisterEvent("COMPANION_UPDATE")
PetJournalEnhanced:RegisterEvent("ZONE_CHANGED");
PetJournalEnhanced:RegisterEvent("ZONE_CHANGED_NEW_AREA")
PetJournalEnhanced.SortFunctions = PetJournalEnhanced:GetSortFunctions()

