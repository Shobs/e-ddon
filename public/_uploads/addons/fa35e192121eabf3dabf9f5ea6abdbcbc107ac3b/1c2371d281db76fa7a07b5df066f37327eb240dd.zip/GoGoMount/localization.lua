﻿
-- Constants
	GoGo_Variables.Localize.ApprenticeRiding = 33388  -- 75 Riding Skill
	GoGo_Variables.Localize.AquaForm = 1066
	GoGo_Variables.Localize.ArtisanRiding = 34091  -- 300 Riding skill
	GoGo_Variables.Localize.AspectCheetah = 5118
	GoGo_Variables.Localize.AspectPack = 13159
--	GoGo_Variables.Localize.AzerothianNavigation = 90269  -- changed during beta to 90267
	GoGo_Variables.Localize.CatForm = 768
	GoGo_Variables.Localize.ColdWeatherFlying = 54197
	GoGo_Variables.Localize.CrusaderAura = 32223
	GoGo_Variables.Localize.ExpertRiding = 34090  -- 225 Riding skill
	GoGo_Variables.Localize.FastFlightForm = 40120
	GoGo_Variables.Localize.FlightMastersLicense = 90267
	GoGo_Variables.Localize.FlightForm = 33943
	GoGo_Variables.Localize.GhostWolf = 2645
	GoGo_Variables.Localize.JourneymanRiding = 33391  -- 150 Riding Skill
	GoGo_Variables.Localize.MasterRiding = 90265  -- 300 Riding Skill + 310% speed
	GoGo_Variables.Localize.RunningWild = 87840
	GoGo_Variables.Localize.SeaLegs = 73701
	GoGo_Variables.Localize.TravelForm = 783
	GoGo_Variables.Localize.Glyph_GhostWolf = 59289
	GoGo_Variables.Localize.Glyph_AquaticForm = 57856
	GoGo_Variables.Localize.Skill.MasterRiding = 325
	GoGo_Variables.Localize.Skill.ArtisanRiding = 300
	GoGo_Variables.Localize.Skill.ExpertRiding = 225
	GoGo_Variables.Localize.Skill.JourneymanRiding = 150
	GoGo_Variables.Localize.Skill.ApprenticeRiding = 75