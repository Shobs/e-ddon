﻿if GetLocale() == "ptBR" then

function rsclocalel()



end


end