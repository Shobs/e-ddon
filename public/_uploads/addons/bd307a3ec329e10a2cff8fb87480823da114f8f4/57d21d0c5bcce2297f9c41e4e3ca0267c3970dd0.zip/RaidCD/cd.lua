-- Based on haste's oCD (http://github.com/haste/ocd/)

local defaults = {
	size = 30,
	min = 2.0,
	max = 20*60,
	textPos = "right",
	growth = "down",
}

local spells = {
	["2825"] = {  -- Bloodlust
		time = 5*60,
	},
	["32182"] = { -- Heroism
		time = 5*60,
	},
	["80353"] = { -- Time Warp
		time = 5*60,
	},
	["29166"] = { -- Innervate
		time = 3*60,
	},
	["16190"] = { -- ana Tide
		time = 3*60,
	},
	["20484"] = { -- Rebirth
		time = 10*60,
		event = "SPELL_RESSURECT"
	},
	["61999"] = { -- Raise Ally
		time = 10*60,
	},
	["20707"] = { -- Soulstone
		time = 15*60,
		event = "SPELL_AURA_APPLIED"
	},
	["33206"] = { -- Pain Suppression
		time = 3*60,
	},
	["62618"] = { -- Power Word: Barrier
		time = 3*60,
	},
	["47788"] = { -- Guardian with Glyph
		time = 3*60-30,
	},
	["6346"] = { -- Fear Ward
		time = 3*60,
	},
}

local addon = CreateFrame"Frame"
addon:Hide()

local GetSpellInfo = GetSpellInfo

local function UnitGUIDInRaid(guid)
	for i = 1, GetNumRaidMembers() do
		local pguid = UnitGUID("raid"..i)
		if pguid == guid then
			return true, UnitName("raid"..i)
		end
	end
	return false
end

-- TODO: Remove the global reference to this table.
local timers = {}
addon.timers = timers

local time, duration, enable
local updateCooldown = function(self)
	for name, obj in pairs(addon.timers) do
		local p = obj.player
		local id = tostring(obj.spellid)
		if addon.db.rcd[p.."_"..id] and GetTime() < addon.db.rcd[p.."_"..id]+spells[id].time then
			time = addon.db.rcd[p.."_"..id]
			duration = spells[id].time
		else
			time = 0
			duration = 0
			addon.db.rcd[p.."_"..id] = nil
		end
		obj(duration, time)
	end
end

-- Initiate the addon
local register, setMinMax, setTextPosition
function addon:PLAYER_LOGIN()
	register = self.bars.register
	setMinMax = self.bars.setMinMax
	setTextPosition = self.bars.setTextPosition
	if not RaidCDDB then RaidCDD = {} end
	self.db = RaidCDDB

	if not self.db.size then self.db.size = defaults.size end
	if not self.db.rcd then self.db.rcd = {} end
	setMinMax(defaults.min, defaults.max)
	self.bars.CreateMainFrame()
	self:updatePositions()
end

local check = function(...)
	local event = select(4, ...)
	local id = tostring(select(14, ...))
	local spellname = select(15, ...)
	local sGUID = select(6, ...)
	local inraid, gname = UnitGUIDInRaid(sGUID)
	if inraid then
		if id and spells[id] then
			updateCooldown()
			if (spells[id].event and spells[id].event == event) or event == "SPELL_CAST_SUCCESS" then
				register(spellname, id, gname)
				addon.db.rcd[gname.."_"..id] = GetTime()
				setMinMax(defaults.min, defaults.max)
				setTextPosition(defaults.textPos)
				updateCooldown()
			end
		end
	end
end

local updateTimers = function(self)
	updateCooldown()
	for n,t in pairs(addon.db.rcd) do
		local p, id = strsplit("_", n)
		if GetTime() > t+spells[id].time then
			addon.db.rcd[n] = nil
		else
			local name = select(1,GetSpellInfo(tonumber(id)))
			register(name, id, p)
			setTextPosition(defaults.textPos)
		end
	end
	updateCooldown()
end

addon.PLAYER_ENTERING_WORLD = updateTimers

addon.COMBAT_LOG_EVENT_UNFILTERED = check

function addon:Test()
	register("Rebirth", "20484", UnitName"player")
	register("ana Tide", "16190", UnitName"player")
	self.db.rcd[UnitName"player" .. "_16190"] = GetTime()
	self.db.rcd[UnitName"player" .. "_20484"] = GetTime()
	setTextPosition(defaults.textPos)
	updateCooldown()
end

function addon:updatePositions(n)
	if(self.db.Pos) then
		local x, y = strsplit(" ", self.db.Pos)
		local s = self.frame:GetEffectiveScale()
		
		self.frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x/s, y/s)
	elseif(self.frame) then
		self.frame:ClearAllPoints()
		self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
	end
end

function addon:savePosition()
	local f = self.frame
	local x,y = f:GetLeft(), f:GetTop()
	local s = f:GetEffectiveScale()
	
	x,y = x*s,y*s
	
	self.db.Pos = strjoin(" ", x, y)
end

addon:SetScript("OnEvent", function(self, event, ...)
	self[event](self, event, ...)
end)

addon:RegisterEvent"PLAYER_LOGIN"
addon:RegisterEvent"PLAYER_ENTERING_WORLD"
addon:RegisterEvent"COMBAT_LOG_EVENT_UNFILTERED"

SlashCmdList["RAIDCD"] = function(cmd)
	local a1, a2 = strsplit(" ", cmd)
	if cmd == "show" then
		raidcd.frame:Show()
	elseif cmd == "hide" then
		raidcd.frame:Hide()
	elseif cmd == "test" then
		raidcd:Test()
	elseif a1 == "size" then
		raidcd.db.size = a2
	else
		print"/raidcd show - Shows the movable frame."
		print"/raidcd hide - Hide the movable frame."
		print"/raidcd test - Shows testbars."
		print"/raidcd size - changes the size of the icon/text [Default is 30]"
	end
end

SLASH_RAIDCD1 = "/raidcd"

_G.raidcd = addon
