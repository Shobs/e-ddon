-- TODO: 
-- add events and handling for BRF monitoring activated changed and raid config changed
-- owner tinkering with player rights in channel will transfer ownership?
-- do not hand out ownership to someone on your ignore list?

local _G = _G

-- addon name and namespace
local ADDON, NS = ...

-- the plugin name
local PLUGIN    = "Forwarder"

-- local functions
local strlower          = strlower
local strfind           = strfind
local strupper          = strupper
local string_format     = string.format
local tinsert           = table.insert
local table_sort        = table.sort
local pairs             = pairs
local time              = time
local floor             = floor
local gsub              = gsub

local GetChannelList  = _G.GetChannelList

-- colors
NS.HexColors = {
	Red      = "ff0000",
	White    = "ffffff",
	Green    = "00ff00",
	GrayOut  = "888888",
}

function NS:Colorize(color, text) return NS.HexColors[color] and ("|cff" .. NS.HexColors[color] .. tostring(text) .. "|r") or tostring(text) end

local function GetArgs(str, pattern)
   local ret = {}
   local pos=0
   
   while true do
     local word
     _, pos, word=string.find(str, pattern, pos+1)
	 
     if not word then
       break
     end
	 
     word = string.lower(word)
     table.insert(ret, word)
   end
   
   return ret
end

-- setup libs
local LibStub  			= LibStub

-- get translations
local L                 = LibStub:GetLibrary("AceLocale-3.0"):GetLocale(ADDON)

-- addon and locals
BRFForwarder = LibStub:GetLibrary("AceAddon-3.0"):NewAddon(ADDON, "AceEvent-3.0", "AceTimer-3.0", "AceConsole-3.0")

-- addon constants
BRFForwarder.MODNAME   = "BRFForwarder"
BRFForwarder.FULLNAME  = "Broker: Raid Finder - Forwarder"
BRFForwarder.SHORTNAME = "BRF-Forwarder"

-- broker raid finder
local BrokerRaidFinder = _G.BrokerRaidFinder

-- infrastcructure
function BRFForwarder:OnInitialize()
	-- init constants
	self.MSG_AUTHOR = "Author: "
	self.MSG_BODY   = "Message: "
	self.MSG_SPACE  = " "

	-- init variables
	self.ready_to_fwd = false
	
	self.ready_for_channel = false

	-- the active flag
	self.active = false
	
	-- the channel owner
	self.owner = nil
	
	-- current owner is on ignore list
	self.ignored = false
	
	-- setup message cache
	self.cache = {}
	
	-- setup player queue of candidates for ownership (players currently in a major city)
	self.candidates = {}
	
	-- label text
	self.label = "F"
	
	-- debugging
	self.debug = false
	
	self:RegisterChatCommand("brfforwarder", "ChatCommand")
	self:RegisterChatCommand("brffwd", "ChatCommand")
	
	-- plugin host
	self.host = nil	
end

function BRFForwarder:OnEnable()
	self.PlayerName = UnitName("player")
	
	self.language = GetDefaultLanguage("player")
	
	-- grace time before any channel will be joined
	-- else on slow clients channel will be joined before any of the global channels and be registered as channel id 1
	self:ScheduleTimer("GraceTimerElapsed", 15)
	
	self:RegisterPlugin()	
end

function BRFForwarder:OnDisable()	
	-- shutdown event handlers
	self:UnregisterEventHandlers()
		
	-- unregister the plugin
	self:UnregisterPlugin()
end

function BRFForwarder:RegisterPlugin()
	self:Debug("BrokerRaidFinder " .. (BrokerRaidFinder and L["found"] or L["not found"]))
	
	if BrokerRaidFinder then
		self:Debug("BrokerRaidFinder:RegisterPlugin " .. (BrokerRaidFinder.RegisterPlugin and L["found"] or L["not found"]))
	end

	if BrokerRaidFinder and BrokerRaidFinder.RegisterPlugin then
		if BrokerRaidFinder:RegisterPlugin(self) then
			self:Debug(L["Plug-in registered with BrokerRaidFinder"])
			self.host = BrokerRaidFinder
			
			self:UpdateSetup()
		else
			self:Output(L["Plug-in failed to register with BrokerRaidFinder"])
		end
	end
end

function BRFForwarder:UnregisterPlugin()
	if self.host then
		if host.UnregisterPlugin then
			self.host:UnregisterPlugin(self)
		end
		
		self:Debug(L["Plug-in unregistered."])
		
		self.host = nil
		
		self:UpdateSetup()
	end
end

function BRFForwarder:UpdateSetup()
	-- update ready to send
	self:CheckReadyToForward()
		
	if self.host and self:IsActive() then
		-- setup comm
		self:SetupCommunication()
		
		-- setup event handlers
		self:RegisterEventHandlers()
		
		-- setup channel
		self:SetupChannel()
	else
		-- shutdown channel
		self:SetupChannel()
		
		-- shutdown comm
		self:ShutdownCommunication()
	end
end

function BRFForwarder:RegisterEventHandlers()
	-- register channel tracking
	self:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")				
	self:RegisterEvent("IGNORELIST_UPDATE")				
end

function BRFForwarder:UnregisterEventHandlers()
	-- unregister channel tracking
	self:UnregisterEvent("CHAT_MSG_CHANNEL_NOTICE")			
	self:UnregisterEvent("IGNORELIST_UPDATE")				
end

function BRFForwarder:ChatCommand(input)
    if input then  
		args = GetArgs(input, "^ *([^%s]+) *")
		
		BRFForwarder:TriggerAction(args[1], args)
	else
		BRFForwarder:TriggerAction("help")
	end
end

function BRFForwarder:TriggerAction(action, args)
	if action == "debug" then
		if args[2] == "on" then
			self:Output("debug mode turned on")
			self.debug = true
		end
		if args[2] == "off" then
			self:Output("debug mode turned off")
			self.debug = false
		end
	elseif action == "version" then
		-- print version information
		self:PrintVersionInfo()
	elseif action == "fwd" then
		if args[2] and args[3] then
			local msg = ""
			for i = 3, #args do
				msg = msg .. args[i] .. " "
			end

			self:ForwardMessage(msg, args[2])
		else
			self:Output("forward is missing an argument")
		end
	elseif action == "toggle" then
		self:ToggleActive()
		self:Output("Plugin is " .. (self:IsActive() and "activated" or "deactivated"))
	elseif action == "on" then
		self:SetActive(true)
		self:Output("Plugin is " .. (self:IsActive() and "activated" or "deactivated"))
	elseif action == "off" then
		self:SetActive(false)
		self:Output("Plugin is " .. (self:IsActive() and "activated" or "deactivated"))
	elseif action == "register" then
		self:RegisterPlugin()
		self:Output("Plugin is " .. (self.host and "registered" or "not registered"))
	elseif action == "unregister" then
		self:UnregisterPlugin()
		self:Output("Plugin is " .. (self.host and "registered" or "not registered"))
	elseif action == "status" then
		self:Output("Plugin is " .. (self.host and "registered" or "not registered"))
		self:Output("Plugin is " .. (self:IsActive() and "activated" or "deactivated"))	
		self:Output("Channel ID: " .. tostring(self.channel_id))	
		self:Output("Channel name: " .. tostring(self.channel_name))	
		self:Output("Channel owner: " .. tostring(self.owner) .. " (self: " .. (self:IsOwner() and "yes" or "no") .. ")")	
		self:Output("Ready to forward: " .. (self:IsReadyToForward() and "yes" or "no"))
		self:Output("Candidates: ")
		for name, _ in pairs(self.candidates) do
			self:Output(name)
		end
	else -- if action == "help" then
		-- display help
		self:Output(L["Usage:"])
		self:Output(L["/brfforwarder arg"])
		self:Output(L["/brffwd arg"])
		self:Output(L["Args:"])
		self:Output(L["on - activate forwarding"])
		self:Output(L["off - deactivate forwarding"])
		self:Output(L["version - display version information"])
		self:Output(L["help - display this help"])
	end
end

function BRFForwarder:GraceTimerElapsed()
	self.ready_for_channel = true
end

function BRFForwarder:UpdateLabelText()
	local old = self.label
	
	self.label = "F"
	
	if self:IsActive() then
		if self.channel_id then
			if self.ignored or self.invalids then
				self.label = NS:Colorize("Red", self.label.."!")
			else
				self.label = NS:Colorize("Green", self.label)
			end
		else
			self.label = NS:Colorize("White", self.label)
		end
	else	
		self.label = NS:Colorize("GrayOut", self.label)
	end
	
	if self.label ~= old and self.host then
		self.host:RequestUpdatePluginLabel()
	end
end

-- implement plugin interface
function BRFForwarder:GetPluginName()
	return PLUGIN
end

function BRFForwarder:GetPluginDescription()
	return L["Plugin adds support to forward LFG messages over a shared channel. This allows cross addon communication for all users of this plugin."]
end

-- keep it short (1-2 chars) - this is additional to the label text of the host
function BRFForwarder:GetLabelText()	
	return self.label
end

function BRFForwarder:GetTooltipMessages()
	local messages = {}
	
	if self:IsActive() then
		if self.channel_id then
			tinsert(messages, NS:Colorize("Green", L["Message forwarding active."]))
						
			if self.invalids then
				tinsert(messages, NS:Colorize("Red", L["Using fallback channel"] .. " " .. tostring(self.invalids) .. "."))
			end
			
			if self.ignored then
				tinsert(messages, NS:Colorize("Red", L["Current channel owner is on ignore list."]))
			end
		end
	end
	
	return messages
end

function BRFForwarder:SetActive(active)
	if active ~= self.active then
		self.active = active

		self:UpdateSetup()
		self:UpdateLabelText()
	end
end

function BRFForwarder:IsActive()
	return self.active
end

function BRFForwarder:HandleEvent(event, data)
	if not self:IsActive() or not self:IsOwner() then
		return
	end

	-- event has to be at least EVENT_MATCH_LFG
	if event >= self.host.EVENT_MATCH_LFG then
		data = data or {}
		
		-- restricted data is to be handled locally only and may not be forwarded
		if not data.restricted then
			self:ForwardMessage(data.message, data.author)
		end
	end	
end

-- testing
function BRFForwarder:Debug(msg)
	if self.debug then
		if ( msg ~= nil and DEFAULT_CHAT_FRAME ) then
			DEFAULT_CHAT_FRAME:AddMessage(self.MODNAME .. " (dbg): " .. msg, 1.0, 0.37, 0.37)
		end		
	end
end

-- event handlers
function BRFForwarder:CHAT_MSG_CHANNEL_NOTICE(event, message, sender, language, channelString, target, flags, unknown, channelNumber, channelName)
	self:Debug("CHAT_MSG_CHANNEL_NOTICE: sender " .. tostring(sender) .." msg " .. tostring(message) .. " channelName " .. tostring(channelName) .. " channelNumber " .. tostring(channelNumber) .. " channelString >" .. tostring(channelString) .. "<" )
	
	if channelName == self.channel_name then
		if message == "YOU_JOINED" then
			self:ChannelJoined(channelNumber)
		elseif message == "YOU_LEFT" then
			self:ChannelLeft()
			
			-- in case we left the channel 'involuntary'
			self:SetupChannel()
		end
	else
		self:Debug("CHAT_MSG_CHANNEL_NOTICE: other channel")
		if message == "YOU_JOINED" or message == "YOU_LEFT" or message == "SUSPENDED" then
			self:Debug("CHAT_MSG_CHANNEL_NOTICE: CheckReadyToForward")
			self:CheckReadyToForward()
		end
	end
end

function BRFForwarder:IGNORELIST_UPDATE()
	self:Debug("IGNORELIST_UPDATE")
	
	self:CheckOwnerIgnored()
end

-- message handling
function BRFForwarder:HandleChannelMessage(msg, sender)
	self:Debug("HandleChannelMessage: by sender " .. tostring(sender))
	if sender == self.PlayerName then
		self:Debug("HandleChannelMessage: no need to handle self")
		return
	end

	self:ProcessMessage(msg, sender)
end

function BRFForwarder:ProcessMessage(rawmsg, sender)
	self:Debug("ProcessMessage")
	
	-- we forwarded the message ourself
	if self:IsOwner() then
		return
	end
	
	-- we read can read the chat anyway
	if self:IsReadyToForward() then
		return
	end
	
	if not self.host then
		self:Debug("ProcessMessage: host missing")
		return
	end
	
	-- get original author
	local author = rawmsg:gsub(self.MSG_AUTHOR .. "(.-)" .. self.MSG_SPACE .. ".*", "%1")
	
	-- get original message
	local message = rawmsg:gsub(".-" .. self.MSG_BODY .. "(.*)", "%1")
	
	self:Debug("ProcessMessage: ".. tostring(author) .. ": " .. tostring(message))
	
	-- process message when not in town
	if author and message then
		self.host:ProcessMessage(message, author, self.owner)
	end
end

-- user functions
function BRFForwarder:PrintVersionInfo()
    self:Output(L["Version"] .. " " .. NS:Colorize("White", GetAddOnMetadata(ADDON, "Version")))
end

-- utilities
function BRFForwarder:Output(msg)
	if ( msg ~= nil and DEFAULT_CHAT_FRAME ) then
		DEFAULT_CHAT_FRAME:AddMessage(self.MODNAME..": "..msg, 0.6, 1.0, 1.0)
	end
end

function BRFForwarder:HostRequestUpdateLabel()
	if not self.host then
		return
	end
	
	self.host:PluginRequestsLabelUpdate()
end

-- settings
function BRFForwarder:CheckReadyToForward()
	local was_ready = self.ready_to_fwd

	self.ready_to_fwd = false
	
	if self.host then
		local channels = {GetChannelList()}
		
		for i=1, #channels, 2 do
			if self.host:IsMonitoredChannel(channels[i]) then
				-- if monitored channel is not just general chat
				if channels[i] > 1 then
					self.ready_to_fwd = true
					break
				end
			end
		end		
	end
	
	
	if self.ready_to_fwd ~= was_ready then
		self:HandleReadyToForwardChanged()
	end
end

function BRFForwarder:HandleReadyToForwardChanged()
	if self:IsOwner() then
		-- transfer ownership if we are no longer ready
		if not self.ready_for_send then
			self:TryTransferOwnership()
		end
	else
		-- owner if informed about both states: ready and not ready
		self:NotifyOwner()
	end
end

function BRFForwarder:IsReadyToForward()
	return self.ready_to_fwd
end

