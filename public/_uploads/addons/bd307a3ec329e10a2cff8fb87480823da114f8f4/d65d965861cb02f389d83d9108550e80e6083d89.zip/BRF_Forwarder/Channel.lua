local _G = _G

-- addon name and namespace
local ADDON, NS = ...

local BRFForwarder = _G.BRFForwarder

-- local functions
local tinsert    = table.insert
local tremove    = table.remove
local pairs      = pairs
local next       = next

local JoinTemporaryChannel	= _G.JoinTemporaryChannel
local LeaveChannelByName	= _G.LeaveChannelByName
local DisplayChannelOwner	= _G.DisplayChannelOwner
local SetChannelOwner		= _G.SetChannelOwner
local IsIgnored				= _G.IsIgnored
local ChannelModerate		= _G.ChannelModerate
local SetChannelPassword	= _G.SetChannelPassword
local GetChannelName        = _G.GetChannelName

-- local constants
local TIMEOUT       = 5
local NOTIFYTIMEOUT = 10

local BRF_CHANNEL_NAME   = "BRFForwarder"
local BRF_CHANNEL_PASS   = "BRFForwarderpass" -- dummy password that should prevent someone stumbling in accidently (non-functional for any security considerations)
local MAX_CHANNEL_OFFSET = 100

-- how long are messages valid in cache
local MAXCACHEDURATION = 180

-- max characters per second rate of forwarding messages
local MAXCPS           = 500

-- messages that could not be forwarded within this time [s] will be dropped
local FORWARDTIMEOUT   = 10

-- max number of channels
local MAXCHANNELS      = 10

-- channel handling
function BRFForwarder:SetupChannel()
	self:Debug("SetupChannel")
	if self.host and self:IsActive() == true then
		-- check if initial timeout to join channel has elapsed
		if self.ready_for_channel then
			self:JoinChannel()
		else
			-- try again in a sec
			self:ScheduleTimer("SetupChannel", 1)
		end
	else
		self:LeaveChannel()
	end
end

function BRFForwarder:JoinChannel()
	self:Debug("JoinChannel")
	if self.channel_id then 
		return
	end
	
	if self.join_timer then
		return
	end
	
	-- check if we already are in the channel befor we try joining it
	if self:IsDefaultChannelActive() then
		return
	end
	
	local offset = ""
	
	if self.invalids then
		offset = tostring(self.invalids)
	end
	
	self.channel_name = BRF_CHANNEL_NAME..offset
	
	self.join_timer = self:ScheduleTimer("JoinTimeout", TIMEOUT)
	
	JoinTemporaryChannel(self.channel_name) -- , BRF_CHANNEL_PASS)
	self:Debug("JoinChannel done")	
end

function BRFForwarder:ChannelJoined(id)
	self:Debug("ChannelJoined:" .. tostring(id))	
	if not id then
		return
	end

	if self.join_timer then
		self:CancelTimer(self.join_timer)
		self.join_timer = nil
	end

	-- assign channel id
	self.channel_id = id
		
	-- set up message queue
	self.send_queue = {}
	
	-- character counter used to limit message throughput
	self.chars = 0	
	
	-- register required events
	self:RegisterEvent("CHAT_MSG_CHANNEL")
	self:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE_USER")
	self:RegisterEvent("CHAT_MSG_CHANNEL_JOIN")
	self:RegisterEvent("CHAT_MSG_CHANNEL_LEAVE")
	
	-- request channel owner info
	DisplayChannelOwner(self.channel_name)	
	
	self:UpdateLabelText()
end

function BRFForwarder:LeaveChannel()
	self:Debug("LeaveChannel")
	if not self.channel_id then 
		return
	end
	
	if self.leave_timer then
		return
	end
	
	-- assign successor for ownership
	if self:IsOwner() then
		self:TryTransferOwnership()
	end
	
	self.leave_timer = self:ScheduleTimer("LeaveTimeout", TIMEOUT)
	
	LeaveChannelByName(self.channel_name)
	self:Debug("LeaveChannel done")	
end

function BRFForwarder:ChannelLeft()
	self:Debug("ChannelLeft")	
	if self.leave_timer then
		self:CancelTimer(self.leave_timer)
		self.leave_timer = nil
	end

	-- unregister events
	self:UnregisterEvent("CHAT_MSG_CHANNEL")	
	self:UnregisterEvent("CHAT_MSG_CHANNEL_NOTICE_USER")
	self:UnregisterEvent("CHAT_MSG_CHANNEL_JOIN")
	self:UnregisterEvent("CHAT_MSG_CHANNEL_LEAVE")	
	
	-- clear channel data
	self.invalids     = nil
	
	self.channel_id   = nil
	self.channel_name = nil
	
	-- reset owner info
	self:SetOwner(nil)
	
	self:UpdateLabelText()	
end

function BRFForwarder:JoinTimeout()
	self.join_timer = nil

	-- something prevents us from joining the current channel
	if not self.invalids then
		self.invalids = 1
	else
		self.invalids = self.invalids + 1
	end
	
	if self.invalids >= MAX_CHANNEL_OFFSET then
		-- apparently we are unable to enter any channel
		self.invalids = nil
		-- disable plugin
		self:SetActive(false)
	else
		-- retry
		self:SetupChannel()
	end	
end

function BRFForwarder:LeaveTimeout()
	self.leave_timer = nil

	-- retry
	self:SetupChannel()
end

function BRFForwarder:IsDefaultChannelActive()
	local id = self:CheckChannel(BRF_CHANNEL_NAME)
	
	if id then
		self.channel_name = BRF_CHANNEL_NAME
		self:ChannelJoined(id)
		return true
	end
	
	return false
end

function BRFForwarder:CheckChannel(channel)
	for i = 1, MAXCHANNELS do
		id, name = GetChannelName(i)
		if name == channel then
			-- channel exists
			return id
		end
	end
end

function BRFForwarder:IsMonitoredChannel(id)
	return id and id == self.channel_id
end

function BRFForwarder:ForwardMessage(msg, author)
	self:Debug("ForwardMessage")
	if not self:IsOwner() then
		self:Debug("ForwardMessage: we are not channel owner - abort")
		return
	end
	
	if not msg then
		self:Debug("ForwardMessage: message missing")
		return
	end

	if not author then
		self:Debug("ForwardMessage: author missing")
		return
	end

	if self:IsCached(msg, author) then
		self:Debug("ForwardMessage: message is cached: " .. msg)
		return
	end

	-- add cache entry
	local timestamp = self:AddToCache(msg, author)
	
	-- review cache for old entries
	self:ReviewCache()
	
	-- assemble message for channel
	local message = self.MSG_AUTHOR .. author .. self.MSG_SPACE .. self.MSG_BODY .. msg

	-- put into message queue
	local entry = {
		message   = message,
		timestamp = timestamp,
	}
	
	tinsert(self.send_queue, entry)
	self:Debug("ForwardMessage: added msg to queue: " .. entry.message)
	
	self:ProcessMessageQueue()
end

function BRFForwarder:ProcessMessageQueue()
	local now = time()

	while #self.send_queue > 0 and self.chars < MAXCPS do
		local entry = tremove(self.send_queue, 1)
		
		-- drop messages to old (to make sure we do not face an ever growing queue)
		if entry.timestamp >= now - FORWARDTIMEOUT then
			self:Debug("ProcessMessageQueue: sending " .. tostring(entry.message) .. " (" .. tostring(entry.timestamp) .. ")")
			SendChatMessage(entry.message, "CHANNEL", self.language, self.channel_id)	
	
			-- add up to character count (which is reset once every second)
			self.chars = self.chars + entry.message:len()
		end
	end	
end

function BRFForwarder:ResetCharacterCount()
	self.chars = 0
	
	-- in case there are still unsent messages in the queue
	self:ProcessMessageQueue()
end

-- event handlers
function BRFForwarder:CHAT_MSG_CHANNEL(event, message, author, arg3, arg4, arg5, arg6, arg7, id)
	if self:IsMonitoredChannel(id) then
		self:HandleChannelMessage(message, author)
	end
end

function BRFForwarder:CHAT_MSG_CHANNEL_NOTICE_USER(event, message, sender, language, channelString, target, flags, arg7, channelNumber, channelName)
	self:Debug("CHAT_MSG_CHANNEL_NOTICE_USER: sender " .. tostring(sender) .." chan " .. tostring(channelName) .. " #" .. tostring(channelNumber))
	if self:IsMonitoredChannel(channelNumber) then
		self:Debug("CHAT_MSG_CHANNEL_NOTICE_USER: message " .. tostring(message))
		if message == 'OWNER_CHANGED' then
			self:SetOwner(sender)
		elseif message == 'CHANNEL_OWNER' then
			self:SetOwner(sender)
		elseif message == "PLAYER_NOT_FOUND" then
			-- only action we perform in this addon to trigger this is to pass the ownership
			
			-- if the player is not found we remove it from the list of candidates
			self:RemoveCandidate(target)
			
			-- try again
			self:TryTransferOwnership()
		end
	end
end

function BRFForwarder:CHAT_MSG_CHANNEL_JOIN(event, arg1, sender, arg3, channelString, arg5, arg6, arg7, channelNumber, channelName)
	self:Debug("CHAT_MSG_CHANNEL_JOIN: sender " .. tostring(sender) .." chan " .. tostring(channelName) .. " #" .. tostring(channelNumber))
	if self:IsMonitoredChannel(channelNumber) then
		self:Debug("CHAT_MSG_CHANNEL_JOIN: user " .. tostring(sender) .." joined")
		-- new user invalidates the whole cache because the user doesn't know any of the messages
		self:ClearCache()
	end
end

function BRFForwarder:CHAT_MSG_CHANNEL_LEAVE(event, arg1, sender, arg3, channelString, arg5, arg6, arg7, channelNumber, channelName)
	self:Debug("CHAT_MSG_CHANNEL_LEAVE: sender " .. tostring(sender) .." chan " .. tostring(channelName) .. " #" .. tostring(channelNumber))
	if self:IsMonitoredChannel(channelNumber) then
		self:Debug("CHAT_MSG_CHANNEL_LEAVE: user " .. tostring(sender) .." left")
		-- player leaving the chat will be removed from list of candidates
		self:RemoveCandidate(sender)
	end
end

-- cache handling
function BRFForwarder:ClearCache()
	for k in pairs(self.cache) do
		self.cache[k] = nil
	end
end

function BRFForwarder:IsCached(msg, author)
	return self.cache[author] and self.cache[author].cache[msg]
end

function BRFForwarder:AddToCache(msg, author)
	if self:IsCached(msg, author) then
		return self.cache[author].cache[msg]
	end

	local now = time()
	
	if not self.cache[author] then
		self.cache[author] = {
			lines = 0,
			cache = {},
		}
	end
	
	self.cache[author].cache[msg] = now
	self.cache[author].lines = self.cache[author].lines + 1
	
	return now
end

function BRFForwarder:ReviewCache()
	local now    = time()
	local oldest = now - MAXCACHEDURATION
	
	-- if the oldest timestamp in cache is inside the time frame we dont have to check
	if self.oldest_cache_stamp and self.oldest_cache_stamp > oldest then
		return
	end
	
	self.oldest_cache_stamp = now
	
	for author, messages in pairs(self.cache) do
		for msg, timestamp in pairs(messages.cache) do
			if timestamp < oldest then
				self:RemoveFromCache(msg, author)
			elseif timestamp < self.oldest_cache_stamp then
				self.oldest_cache_stamp = timestamp
			end
		end
	end
end

function BRFForwarder:RemoveFromCache(msg, author)
	if not self:IsCached(msg, author) then
		return
	end
		
	if self.cache[author].lines == 1 then
		self.cache[author] = nil
	else
		self.cache[author].cache[msg] = nil
		self.cache[author].lines = self.cache[author].lines - 1
	end
end

-- owner handling
function BRFForwarder:IsOwner()
	return self.PlayerName == self.owner
end

function BRFForwarder:TryTransferOwnership()
	if not self:IsOwner() then
		return
	end
	
	local candidate = self:SelectCandidate()
	
	if candidate then
		SetChannelOwner(self.channel_name, candidate);
	end
end

function BRFForwarder:SetOwner(owner)
	if owner == "" then
		owner = nil
	end
	
	self:Debug("SetOwner: " .. tostring(owner))
	if self.owner == owner then
		return
	end

	-- clean up data if we have been the owner so far
	if self:IsOwner() then
		self:ClearCache()
		self:ClearCandidates()
		
		-- clear send queue
		for k in pairs(self.send_queue) do
			self.send_queue[k] = nil
		end
			
		-- cancel timer to reset character count
		self:CancelTimer(self.cps_timer)
	else
		-- clear pending notifications for old owner
		self:CancelPendingNotifications(self.owner)
	end
	
	self.owner = owner

	if self:IsOwner() then
		-- set default password in case some clown changed it
		-- SetChannelPassword(self.channel_name, BRF_CHANNEL_PASS)
		
		-- reset character counter
		self:ResetCharacterCount()
		
		-- timer to reset character counter
		self.cps_timer = self:ScheduleRepeatingTimer("ResetCharacterCount", 1)
		
		-- if we have been assigned ownership, but we are not inside a city try to pass on the ownership right away
		if not self:IsReadyToForward() then
			self:TryTransferOwnership()
		end		
	else		
		--notify new owner, that we are ready to send
		if self:IsReadyToForward() then
			-- send delayed notification to avoid msg burst on receiver side
			self:NotifyOwner(true)
		end
		
		self:CheckOwnerIgnored()
	end
end

function BRFForwarder:CheckOwnerIgnored()
	local was_ignored = self.ignored

	if self.owner and IsIgnored(self.owner) then
		self.ignored = true
	else
		self.ignored = false
	end
	
	if was_ignored ~= self.ignored then
		if self.ignored then
			self:Output("Channel owner '" .. tostring(self.owner) .. "' is on your ignore list!")
		else
			self:Output("Channel owner '" .. tostring(self.owner) .. "' is no longer on your ignore list!")
		end
		
		self:UpdateLabelText()
	end
end

-- handle channel owner candidates
function BRFForwarder:SetCandidate(player)
	if self.candidates[player] then
		return
	end
	
	self.candidates[player] = time()
end

function BRFForwarder:RemoveCandidate(player)
	self.candidates[player] = nil
end

function BRFForwarder:ClearCandidates()
	for k in pairs(self.candidates) do
		self.candidates[k] = nil
	end
end

-- selects oldest player entry (newest entry, if param is true)
function BRFForwarder:SelectCandidate(newest)
	local candidate = nil
	local since     = nil
	
	local better    = nil
	
	if newest then
		better = function(a, b) return a > b end
	else
		better = function(a, b) return a < b end
	end
	
	for name, timestamp in pairs(self.candidates) do
		if not since or better(timestamp, since) then
			candidate = name
			since     = timestamp
		end
	end	
	
	return candidate
end
