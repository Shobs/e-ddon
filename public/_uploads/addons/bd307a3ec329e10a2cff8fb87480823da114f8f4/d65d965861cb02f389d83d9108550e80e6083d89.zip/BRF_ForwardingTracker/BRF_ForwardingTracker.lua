local _G = _G

-- addon name and namespace
local ADDON, NS = ...

-- the plugin name
local PLUGIN    = "Forwarding Tracker"

-- local functions
local strfind           = strfind
local tinsert           = table.insert
local pairs             = pairs

local GetChannelList  = _G.GetChannelList

-- LFG Forwarder data

-- global channel name
local LFW_CHANNEL_NAME = _G.LFW_CHANNEL_NAME
local TFW_CHANNEL_NAME = _G.TFW_CHANNEL_NAME

-- taken directly from LFGForwarder.lua
local LFW_SEP_R = "_%$"
local LFW_PATTERN_R = "^"..LFW_SEP_R.."(%d+)([^%d]+)"..LFW_SEP_R.."(.+)"..LFW_SEP_R.."(%x%x%x%x%x%x)%$$"

-- colors
NS.HexColors = {
	Red      = "ff0000",
	White    = "ffffff",
	Green    = "00ff00",
	GrayOut  = "888888",
}

function NS:Colorize(color, text) return NS.HexColors[color] and ("|cff" .. NS.HexColors[color] .. tostring(text) .. "|r") or tostring(text) end

local function GetArgs(str, pattern)
   local ret = {}
   local pos=0
   
   while true do
     local word
     _, pos, word=string.find(str, pattern, pos+1)
	 
     if not word then
       break
     end
	 
     word = string.lower(word)
     table.insert(ret, word)
   end
   
   return ret
end

-- setup libs
local LibStub  			= LibStub

-- get translations
local L                 = LibStub:GetLibrary("AceLocale-3.0"):GetLocale(ADDON)

-- addon and locals
BRFForwardingTracker = LibStub:GetLibrary("AceAddon-3.0"):NewAddon(ADDON, "AceEvent-3.0", "AceTimer-3.0", "AceConsole-3.0")

-- addon constants
BRFForwardingTracker.MODNAME   = "BRFForwardingTracker"
BRFForwardingTracker.FULLNAME  = "Broker: Raid Finder - Forwarding Tracker"
BRFForwardingTracker.SHORTNAME = "BRF-ForwardingTracker"

-- broker raid finder
local BrokerRaidFinder = _G.BrokerRaidFinder

-- infrastcructure
function BRFForwardingTracker:OnInitialize()
	-- init variables
	self.is_tracking_lfg     = false
	self.is_tracking_trade   = false
	
	self.needs_tracking_data = false

	-- the active flag
	self.active = false
	
	-- label text
	self.label = "T"
	
	-- debugging
	self.debug = false
	
	self:RegisterChatCommand("brffwdtracker", "ChatCommand")
	self:RegisterChatCommand("brftrack",      "ChatCommand")
	
	-- plugin host
	self.host = nil	
end

function BRFForwardingTracker:OnEnable()
	self.PlayerName = UnitName("player")

	-- register the plugin
	self:RegisterPlugin()	
end

function BRFForwardingTracker:OnDisable()	
	-- unregister the plugin
	self:UnregisterPlugin()
end

function BRFForwardingTracker:RegisterPlugin()
	self:Debug("BrokerRaidFinder " .. (BrokerRaidFinder and L["found"] or L["not found"]))
	
	if BrokerRaidFinder then
		self:Debug("BrokerRaidFinder:RegisterPlugin " .. (BrokerRaidFinder.RegisterPlugin and L["found"] or L["not found"]))
	end

	if BrokerRaidFinder and BrokerRaidFinder.RegisterPlugin then
		if BrokerRaidFinder:RegisterPlugin(self) then
			self:Debug(L["Plug-in registered with BrokerRaidFinder"])
			self.host = BrokerRaidFinder
			
			self:UpdateSetup()
		else
			self:Output(L["Plug-in failed to register with BrokerRaidFinder"])
		end
	end
end

function BRFForwardingTracker:UnregisterPlugin()
	if self.host then
		if host.UnregisterPlugin then
			self.host:UnregisterPlugin(self)
		end
		
		self:Debug(L["Plug-in unregistered."])
		
		self.host = nil
		
		self:UpdateSetup()
	end
end

function BRFForwardingTracker:UpdateSetup()
	-- update current channel states
	self:CheckChannelStates()
		
	if self.host and self:IsActive() then
		-- setup event handlers
		self:RegisterEventHandlers()
	else
		-- unregister event handlers
		self:UnregisterEventHandlers()
	end
end

function BRFForwardingTracker:RegisterEventHandlers()
	-- register channel tracking
	self:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")				
	self:RegisterEvent("CHAT_MSG_CHANNEL")				
end

function BRFForwardingTracker:UnregisterEventHandlers()
	-- unregister channel tracking
	self:UnregisterEvent("CHAT_MSG_CHANNEL_NOTICE")			
	self:UnregisterEvent("CHAT_MSG_CHANNEL")			
end

function BRFForwardingTracker:ChatCommand(input)
    if input then  
		args = GetArgs(input, "^ *([^%s]+) *")
		
		BRFForwardingTracker:TriggerAction(args[1], args)
	else
		BRFForwardingTracker:TriggerAction("help")
	end
end

function BRFForwardingTracker:TriggerAction(action, args)
	if action == "debug" then
		if args[2] == "on" then
			self:Output("debug mode turned on")
			self.debug = true
		end
		if args[2] == "off" then
			self:Output("debug mode turned off")
			self.debug = false
		end
	elseif action == "version" then
		-- print version information
		self:PrintVersionInfo()
	elseif action == "toggle" then
		self:ToggleActive()
		self:Output("Plugin is " .. (self:IsActive() and "activated" or "deactivated"))
	elseif action == "on" then
		self:SetActive(true)
		self:Output("Plugin is " .. (self:IsActive() and "activated" or "deactivated"))
	elseif action == "off" then
		self:SetActive(false)
		self:Output("Plugin is " .. (self:IsActive() and "activated" or "deactivated"))
	elseif action == "register" then
		self:RegisterPlugin()
		self:Output("Plugin is " .. (self.host and "registered" or "not registered"))
	elseif action == "unregister" then
		self:UnregisterPlugin()
		self:Output("Plugin is " .. (self.host and "registered" or "not registered"))
	elseif action == "status" then
		self:Output("Plugin is " .. (self.host and "registered" or "not registered"))
		self:Output("Plugin is " .. (self:IsActive() and "activated" or "deactivated"))	
		self:Output("Needs tracking: " .. (self:NeedsTrackingData() and "yes" or "no"))	
		self:Output("Is tracking: " .. (self:IsTracking() and "yes" or "no"))	
	else -- if action == "help" then
		-- display help
		self:Output(L["Usage:"])
		self:Output(L["/brffwdtracker arg"])
		self:Output(L["/brftrack arg"])
		self:Output(L["Args:"])
		self:Output(L["on - activate tracking"])
		self:Output(L["off - deactivate tracking"])
		self:Output(L["version - display version information"])
		self:Output(L["help - display this help"])
	end
end

function BRFForwardingTracker:UpdateLabelText()
	local old = self.label
	
	self.label = "T"
	
	if self:IsActive() then
		if self:NeedsTrackingData() then
			if self:IsTracking() then
				self.label = NS:Colorize("Green", self.label)
			else
				self.label = NS:Colorize("Red", self.label)
			end
		else
			self.label = NS:Colorize("White", self.label)
		end
	else	
		self.label = NS:Colorize("GrayOut", self.label)
	end
	
	if self.label ~= old and self.host then
		self.host:RequestUpdatePluginLabel()
	end
end

-- implement plugin interface
function BRFForwardingTracker:GetPluginName()
	return PLUGIN
end

function BRFForwardingTracker:GetPluginDescription()
	return L["Plug-in keeps track of messages forwarded by LFGForwarder and TradeForwarder and feeds them to the addon."]
end

-- keep it short (1-2 chars) - this is additional to the label text of the host
function BRFForwardingTracker:GetLabelText()	
	return self.label
end

function BRFForwardingTracker:GetTooltipMessages()
	local messages = {}
	
	if self:IsActive() then
		if self:NeedsTrackingData() then
			if self:IsTracking() then
				if self.is_tracking_lfg then
					tinsert(messages, NS:Colorize("Green", L["LFGForwarder tracking in progress."]))
				end
				if self.is_tracking_trade then
					tinsert(messages, NS:Colorize("Green", L["TradeForwarder tracking in progress."]))
				end
			else
				tinsert(messages, NS:Colorize("Red", L["Cannot track LFG/TradeForwarder. Channel(s) not found."]))
			end
		else
			tinsert(messages, NS:Colorize("White", L["Tracking paused in major city."]))
		end
	end
	
	return messages
end

function BRFForwardingTracker:SetActive(active)
	if active ~= self.active then
		self.active = active

		self:UpdateSetup()
		self:UpdateLabelText()
	end
end

function BRFForwardingTracker:IsActive()
	return self.active
end

-- we do not handle events provided by the main addon
function BRFForwardingTracker:HandleEvent(event, data)
	-- void
end

-- testing
function BRFForwardingTracker:Debug(msg)
	if self.debug then
		if ( msg ~= nil and DEFAULT_CHAT_FRAME ) then
			DEFAULT_CHAT_FRAME:AddMessage(self.MODNAME .. " (dbg): " .. msg, 1.0, 0.37, 0.37)
		end		
	end
end

-- event handlers
function BRFForwardingTracker:CHAT_MSG_CHANNEL_NOTICE(event, message, sender, language, channelString, target, flags, unknown, channelNumber, channelName)
	self:Debug("CHAT_MSG_CHANNEL_NOTICE: sender " .. tostring(sender) .." msg " .. tostring(message) .. " channelName " .. tostring(channelName) .. " channelNumber " .. tostring(channelNumber) .. " channelString >" .. tostring(channelString) .. "<" )
	
	if message == "YOU_JOINED" or message == "YOU_LEFT" or message == "SUSPENDED" then
		self:CheckChannelStates()
	end
end

function BRFForwardingTracker:CHAT_MSG_CHANNEL(event, message, author, arg3, arg4, arg5, arg6, arg7, id, channel_name)
	if channel_name == LFW_CHANNEL_NAME or channel_name == TFW_CHANNEL_NAME then
		self:HandleChannelMessage(message, author)
	end
end

-- message handling
function BRFForwardingTracker:HandleChannelMessage(msg, sender)
	self:Debug("HandleChannelMessage: by sender " .. tostring(sender))
	
	if not self:IsActive() then
		self:Debug("HandleChannelMessage: plugin not active")
		return
	end
	
	if sender == self.PlayerName then
		self:Debug("HandleChannelMessage: no need to handle self")
		return
	end

	self:ProcessMessage(msg, sender)
end

function BRFForwardingTracker:ProcessMessage(rawmsg, sender)
	self:Debug("ProcessMessage")
	
	-- we read can read the chat anyway
	if not self:NeedsTrackingData() then
		self:Debug("ProcessMessage: dont need tracking data")
		return
	end
	
	if not self.host then
		self:Debug("ProcessMessage: host missing")
		return
	end

	-- get data from raw message
	local _, _, idx, author, message, color = strfind(rawmsg, LFW_PATTERN_R);

	self:Debug("ProcessMessage: ".. tostring(author) .. ": " .. tostring(message))
	
	-- process message when not in town
	if author and message then
		self.host:ProcessMessage(message, author, sender)
	end
end

-- user functions
function BRFForwardingTracker:PrintVersionInfo()
    self:Output(L["Version"] .. " " .. NS:Colorize("White", GetAddOnMetadata(ADDON, "Version")))
end

-- utilities
function BRFForwardingTracker:Output(msg)
	if ( msg ~= nil and DEFAULT_CHAT_FRAME ) then
		DEFAULT_CHAT_FRAME:AddMessage(self.MODNAME..": "..msg, 0.6, 1.0, 1.0)
	end
end

function BRFForwardingTracker:HostRequestUpdateLabel()
	if not self.host then
		return
	end
	
	self.host:PluginRequestsLabelUpdate()
end

-- settings
function BRFForwardingTracker:CheckChannelStates()
	self:Debug("CheckChannelStates")
	self.is_tracking_lfg     = false
	self.is_tracking_trade   = false
	self.needs_tracking_data = true
	
	if self.host then
		local channels = {GetChannelList()}
		
		for i=1, #channels, 2 do
			-- check if we have joined the usual channels in a major city
			if self.host:IsMonitoredChannel(channels[i]) then
				-- if monitored channel is not just general chat
				if channels[i] > 1 then
					self.needs_tracking_data = false
				end
			end
			
			-- check if we are present in the LFGForwarder channel
			if channels[i+1] == LFW_CHANNEL_NAME then
				self.is_tracking_lfg = true
			elseif channels[i+1] == TFW_CHANNEL_NAME then
				self.is_tracking_trade = true
			end
		end		
	end
	
	self:UpdateLabelText()
end

function BRFForwardingTracker:IsTracking()
	return self.is_tracking_lfg or self.is_tracking_trade
end

function BRFForwardingTracker:NeedsTrackingData()
	return self.needs_tracking_data
end
