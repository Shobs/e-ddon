local _G = _G

-- addon name and namespace
local ADDON, NS = ...

local BrokerRaidFinder = _G.BrokerRaidFinder

-- get translations
local L             = LibStub:GetLibrary("AceLocale-3.0"):GetLocale(ADDON)
local LibBabbleZone = LibStub:GetLibrary("LibBabble-Zone-3.0"):GetLookupTable()

-- tooltip library
local QT = LibStub:GetLibrary("LibQTip-1.0")

-- coloring tools
local Crayon	= LibStub:GetLibrary("LibCrayon-3.0")

-- local functions
local string_format     = string.format
local pairs             = pairs
local next              = next
local floor             = floor

-- utilities
local function format_time(stamp)
	local days    = floor(stamp/86400)
	local hours   = floor((stamp - days * 86400) / 3600)
	local minutes = floor((stamp - days * 86400 - hours * 3600) / 60)
	local seconds = floor((stamp - days * 86400 - hours * 3600 - minutes * 60))

	return string_format("%02d:%02d:%02d", hours, minutes, seconds)
end

local function BRF_ToggleInstance(cell, instance, button)
	BrokerRaidFinder:ToggleInstance(instance)
	BrokerRaidFinder:DrawTooltip()
	tooltip:Show()
end

local tooltip

function BrokerRaidFinder:CreateTooltip( obj )
	tooltip = QT:Acquire( ADDON.."TT", 3 )
	tooltip:Hide()
	tooltip:Clear()
	tooltip:SetScale(1)
		
	self:DrawTooltip()

	tooltip:SetAutoHideDelay( .1, obj )
	tooltip:EnableMouse()
	tooltip:SmartAnchorTo( obj )
	tooltip:Show()
end

function BrokerRaidFinder:RemoveTooltip()
	if tooltip then
		tooltip:Hide()
		QT:Release(tooltip)
		tooltip = nil
	end
end

-- tooltip
function BrokerRaidFinder:DrawTooltip()
	tooltip:Hide()
	tooltip:Clear()

	local now = time()
	
	-- addon header
	local lineNum = tooltip:AddHeader( " " )
	tooltip:SetCell( lineNum, 1, NS:Colorize("White", self.FULLNAME), "CENTER", tooltip:GetColumnCount() )
	
	local ctrlKeyPressed = IsControlKeyDown()
	
	-- monitored raids
	if ctrlKeyPressed or self.db.profile.monitoringActive then
		-- for all extensions
		for extension, instances in pairs(brf_Instances) do
			local header_present = false
			
			-- for all instances
			for _, instance in pairs(instances) do
				local monitored = self:IsMonitored(instance)
				
				if ctrlKeyPressed or (self:IsMonitored(instance) and not self:ExcludeAsSaved(instance)) then 
					local saved = self:IsSaved(instance)
				
					if not header_present then
						-- set extension name as header
						tooltip:AddLine( " " )
						lineNum = tooltip:AddLine( " " )
						tooltip:SetCell( lineNum, 1, NS:Colorize("Orange", L[brf_Extensions[extension]]), "LEFT", tooltip:GetColumnCount() )
						
						header_present = true
					end

					lineNum = tooltip:AddLine( " " )
					
					if self.matches_latest[instance] then
						-- instance
						if saved then
							tooltip:SetCell( lineNum, 1, NS:Colorize("Red", LibBabbleZone[instance]) .. " ", "LEFT")
						else
							tooltip:SetCell( lineNum, 1, NS:Colorize("Green", LibBabbleZone[instance]) .. " ", "LEFT")
						end

						local match = self.matches_latest[instance]
						
						-- last player posting
						tooltip:SetCell( lineNum, 2, self:ColorizeChar( match.player ) .. NS:Colorize("White", " (of " .. tostring(match.players) .. ") ") , "LEFT")
						
						-- time since posting
						local timestamp = now - match.timestamp
						local timestring = ""
						if Crayon then
							local timeframe = self.db.profile.timeFrame * 60
							timestring = "|cff"..Crayon:GetThresholdHexColor(timestamp, timeframe, timeframe * 0.75, timeframe * 0.5, timeframe * 0.25, 1) .. format_time(timestamp) .. "|r"
						else
							timestring = format_time(timestamp)
						end				
						
						tooltip:SetCell( lineNum, 3, timestring, "RIGHT")
					else
						-- instance
						if saved then
							tooltip:SetCell( lineNum, 1, NS:Colorize("Red", LibBabbleZone[instance]) .. " ", "LEFT")
						elseif monitored then
							tooltip:SetCell( lineNum, 1, NS:Colorize("Blueish", LibBabbleZone[instance]) .. " ", "LEFT")
						else
							tooltip:SetCell( lineNum, 1, NS:Colorize("GrayOut", LibBabbleZone[instance]) .. " ", "LEFT")
						end
						
						-- no player
						tooltip:SetCell( lineNum, 2, NS:Colorize("GrayOut", "--"), "LEFT")
						
						-- no time
						tooltip:SetCell( lineNum, 3, NS:Colorize("GrayOut", "--"), "RIGHT")
					end
					
					tooltip:SetCellScript( lineNum, 1, "OnMouseDown", BRF_ToggleInstance, instance)					
				end			
			end	
		end
		
		if self.server then
			tooltip:AddLine( " " )
			lineNum = tooltip:AddLine( " " )
			tooltip:SetCell( lineNum, 1, NS:Colorize("Green", L["Remote client is monitoring."]), "LEFT", tooltip:GetColumnCount() )
		end
	else
		lineNum = tooltip:AddLine( " " )
		tooltip:SetCell( lineNum, 1, NS:Colorize("Red", L["Monitoring is switched off."]), "LEFT", tooltip:GetColumnCount() )
	end
	
	-- plugins
	for name, plugin in pairs(self.plugins) do
		if self:ShowPluginTooltip(name) and plugin:IsActive() then
			local messages = plugin:GetTooltipMessages() or {}
			
			if #messages > 0 then
				tooltip:AddLine( " " )
				lineNum = tooltip:AddLine( " " )
				tooltip:SetCell( lineNum, 1, NS:Colorize("Brownish", plugin:GetPluginName() .. " " .. L["Plugin"] .. ":"), "LEFT", tooltip:GetColumnCount() )
			end
			
			for idx, msg in ipairs(messages) do
				lineNum = tooltip:AddLine( " " )
				tooltip:SetCell( lineNum, 1, msg, "LEFT", tooltip:GetColumnCount() )
			end
		end
	end
	
	-- hint to show options
	if not self.db.profile.hideHint then
		tooltip:AddLine( " " )
		lineNum = tooltip:AddLine( " " )
		tooltip:SetCell( lineNum, 1, NS:Colorize("Brownish", L["Left-Click"] .. ":") .. " " .. NS:Colorize("Yellow", L["Show logging window."]), "LEFT", tooltip:GetColumnCount() )
		lineNum = tooltip:AddLine( " " )
		tooltip:SetCell( lineNum, 1, NS:Colorize("Brownish", L["Alt-Click"] .. ":") .. " " .. NS:Colorize("Yellow", L["Enable/disable monitoring."]), "LEFT", tooltip:GetColumnCount() )
		lineNum = tooltip:AddLine( " " )
		tooltip:SetCell( lineNum, 1, NS:Colorize("Brownish", L["Right-Click"] .. ":") .. " " .. NS:Colorize("Yellow", L["Open option menu."]), "LEFT", tooltip:GetColumnCount() )
		lineNum = tooltip:AddLine( " " )
		tooltip:SetCell( lineNum, 1, NS:Colorize("Brownish", L["Left-Click Tip"] .. ":") .. " " .. NS:Colorize("Yellow", L["Click on instance name to toggle monitoring."]), "LEFT", tooltip:GetColumnCount() )
		lineNum = tooltip:AddLine( " " )
		tooltip:SetCell( lineNum, 1, NS:Colorize("Brownish", L["Ctrl-Hover Tip"] .. ":") .. " " .. NS:Colorize("Yellow", L["Press Ctrl while opening tooltip shows all instances."]), "LEFT", tooltip:GetColumnCount() )
	end
	
end

