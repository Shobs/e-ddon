local _G = _G

-- addon name and namespace
local ADDON, NS = ...

local BrokerRaidFinder = _G.BrokerRaidFinder

-- local functions
local string_format     = string.format
local tinsert           = table.insert
local table_sort        = table.sort
local pairs             = pairs

-- get translations
local L             = LibStub:GetLibrary("AceLocale-3.0"):GetLocale(ADDON)
local LibBabbleZone = LibStub:GetLibrary("LibBabble-Zone-3.0"):GetLookupTable()

-- utilities
local function format_time(stamp)
	local days    = floor(stamp/86400)
	local hours   = floor((stamp - days * 86400) / 3600)
	local minutes = floor((stamp - days * 86400 - hours * 3600) / 60)
	local seconds = floor((stamp - days * 86400 - hours * 3600 - minutes * 60))

	return string_format("%02d:%02d:%02d", hours, minutes, seconds)
end

-- local constants
local MAX_LIST_SIZE       = 10
local LISTENTRYHEIGHT     = 20

local FILTERINSTOPT_ALL   = "Show All"

local FILTERSRCOPT_ALL    = 0
local FILTERSRCOPT_SELF   = 1
local FILTERSRCOPT_ALTS   = 2
local FILTERSRCOPT_REMOTE = 3

local filterInstanceBtnInfo = { func = function(self) BrokerRaidFinder:HandleInstanceFilter(self.value); UIDropDownMenu_SetSelectedValue(BrokerRaidFinder.logfilterinstance, self.value) end } 
local filterSourceBtnInfo   = { func = function(self) BrokerRaidFinder:HandleSourceFilter(self.value); UIDropDownMenu_SetSelectedValue(BrokerRaidFinder.logfiltersource, self.value) end }

local function InitInstanceFilter()
	if BrokerRaidFinder.in_combat then
		return
	end
	
	filterInstanceBtnInfo.text = L["Show All"]
	filterInstanceBtnInfo.value = FILTERINSTOPT_ALL
	filterInstanceBtnInfo.checked = BrokerRaidFinder.instancefilter == FILTERINSTOPT_ALL
	UIDropDownMenu_AddButton(filterInstanceBtnInfo)
	
	-- populate with currently monitored instances
	local monitored = {}
	
	for instance, _ in pairs(BrokerRaidFinder.db.profile.monitored) do
		tinsert(monitored, instance)
	end
	
	table_sort(monitored, function(a, b) return LibBabbleZone[a] < LibBabbleZone[b]; end)
	
	for i = 1, #monitored do
		filterInstanceBtnInfo.text =  LibBabbleZone[monitored[i]]
		filterInstanceBtnInfo.value = monitored[i]
		filterInstanceBtnInfo.checked = BrokerRaidFinder.instancefilter == monitored[i]
		UIDropDownMenu_AddButton(filterInstanceBtnInfo)
	end

	UIDropDownMenu_SetSelectedValue(BrokerRaidFinder.logfilterinstance, BrokerRaidFinder.instancefilter)
end

local function InitSourceFilter()
	if BrokerRaidFinder.in_combat then
		return
	end
	
	filterSourceBtnInfo.text = L["Show All"]
	filterSourceBtnInfo.value = FILTERSRCOPT_ALL
	filterSourceBtnInfo.checked = BrokerRaidFinder.sourcefilter == FILTERSRCOPT_ALL
	UIDropDownMenu_AddButton(filterSourceBtnInfo)
	
	filterSourceBtnInfo.text = L["Self"]
	filterSourceBtnInfo.value = FILTERSRCOPT_SELF
	filterSourceBtnInfo.checked = BrokerRaidFinder.sourcefilter == FILTERSRCOPT_SELF
	UIDropDownMenu_AddButton(filterSourceBtnInfo)
	
	filterSourceBtnInfo.text = L["Alts"]
	filterSourceBtnInfo.value = FILTERSRCOPT_ALTS
	filterSourceBtnInfo.checked = BrokerRaidFinder.sourcefilter == FILTERSRCOPT_ALTS
	UIDropDownMenu_AddButton(filterSourceBtnInfo)
	
	filterSourceBtnInfo.text = L["Remote"]
	filterSourceBtnInfo.value = FILTERSRCOPT_REMOTE
	filterSourceBtnInfo.checked = BrokerRaidFinder.sourcefilter == FILTERSRCOPT_REMOTE
	UIDropDownMenu_AddButton(filterSourceBtnInfo)
	
	UIDropDownMenu_SetSelectedValue(BrokerRaidFinder.logfiltersource, BrokerRaidFinder.sourcefilter)
end

local function MatchListUpdate()
	local frame = BrokerRaidFinder.matchlistframe
	local entries = frame.entries
	local numEntries = #BrokerRaidFinder.filtered_matches
	local listSize = min(numEntries, MAX_LIST_SIZE)

	local scrollFrame = frame.scrollFrame
	
	local offset = FauxScrollFrame_GetOffset(scrollFrame)
	FauxScrollFrame_Update(scrollFrame, numEntries, listSize, LISTENTRYHEIGHT)

	-- if the list gets shortened so much that all entries are below the current offset then adjust the offset
	if offset + MAX_LIST_SIZE > numEntries then
		offset = numEntries - MAX_LIST_SIZE
		if offset < 0 then
			offset = 0
		end
		FauxScrollFrame_SetOffset(scrollFrame, offset)
	end	
	
	for i = 1, MAX_LIST_SIZE do
		local index = i + offset
		local entry = entries[i]

		if index <= numEntries then
			local data = BrokerRaidFinder.filtered_matches[index]
			entry.timeframe.text:SetText(format_time(data.timestamp+BrokerRaidFinder.time_offset))
			entry.authorframe.text:SetText(BrokerRaidFinder:ColorizeChar(tostring(data.player)))
			entry.msgframe.text:SetText(LibBabbleZone[data.instance])
			
			entry.data = data
			
			if BrokerRaidFinder.selected_match == data then
				entry:SetBackdropColor(1, 1, 1, 1)
			else
				entry:SetBackdropColor(0, 0, 0, .33)
			end
			
			entry:Show()
		else
			entry:Hide()
		end
		
		if scrollFrame:IsShown() then
			entry:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -20, -1*(i-1)*LISTENTRYHEIGHT - 3)
		else
			entry:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -3, -1*(i-1)*LISTENTRYHEIGHT - 3)
		end		
	end
end

-- log window
function BrokerRaidFinder:SetupInterface()
	-- log window setup
	local backdrop = {
		-- path to the background texture
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", 
		-- path to the border texture
		edgeFile = "Interface\\TutorialFrame\\TutorialFrameBorder",
		-- true to repeat the background texture to fill the frame, false to scale it
		tile = true,
		-- size (width or height) of the square repeating background tiles (in pixels)
		tileSize = 32,
		-- thickness of edge segments and square size of edge corners (in pixels)
		edgeSize = 28,
		-- distance from the edges of the frame to those of the background texture (in pixels)
		insets = {
			left   = 5,
			right  = 2,
			top    = 20,
			bottom = 5
		}
	}
	
	self.logwindow = CreateFrame("Frame", ADDON.."LogWindow", UIParent)
	self.logwindow:SetFrameStrata("DIALOG")
	self.logwindow:CreateTitleRegion():SetAllPoints()
	self.logwindow:SetToplevel(true)
	self.logwindow:EnableMouse(true)
	self.logwindow:SetMovable(true)
	self.logwindow:SetUserPlaced(true)
	self.logwindow:SetHeight(370)
	self.logwindow:SetWidth(500)
	self.logwindow:SetBackdrop(backdrop)
	self.logwindow:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
	self.logwindow:RegisterForDrag("LeftButton")
	
	tinsert(UISpecialFrames, self.logwindow:GetName())
	
	local titlebar = self.logwindow:CreateTitleRegion()
	titlebar:SetPoint("TOPRIGHT", -5, 0)
	titlebar:SetPoint("TOPLEFT", 5, 0)
	titlebar:SetHeight(28)

	self.logwindow.title = self.logwindow:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	self.logwindow.title:SetPoint("CENTER", titlebar, "CENTER", 0, 8)
	self.logwindow.title:SetText(self.FULLNAME .. " - " .. L["Log Window"])
	
	local button = CreateFrame("Button", nil, self.logwindow, "UIPanelCloseButton")
	button:SetPoint("TOPRIGHT", 5, 6)
	
	-- label for instance filter
	local frame = CreateFrame("Frame", nil, self.logwindow)
	frame:SetHeight(20)
	frame:SetWidth(85)
	frame:SetPoint("TOPLEFT", self.logwindow, "TOPLEFT", 15, -35)
	
	local text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	text:SetPoint("LEFT", frame, "LEFT")
	text:SetText(L["Show Instance:"])
	
	-- combobox for instance filter
	self.instancefilter = FILTERINSTOPT_ALL
	
	self.logfilterinstance = CreateFrame("Frame", ADDON.."InstanceFilter", self.logwindow, "UIDropDownMenuTemplate")
	
	self.logfilterinstance:ClearAllPoints()
	self.logfilterinstance:SetPoint("TOPLEFT", self.logwindow, "TOPLEFT", 100, -30)
	
	UIDropDownMenu_Initialize(self.logfilterinstance, InitInstanceFilter)
	UIDropDownMenu_SetWidth(self.logfilterinstance, 100);
	UIDropDownMenu_SetButtonWidth(self.logfilterinstance, 124)
	UIDropDownMenu_JustifyText(self.logfilterinstance, "LEFT")
 
	-- label for source filter
	local frame = CreateFrame("Frame", nil, self.logwindow)
	frame:SetHeight(20)
	frame:SetWidth(85)
	frame:SetPoint("TOPLEFT", self.logwindow, "TOPLEFT", 260, -35)
	
	local text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	text:SetPoint("LEFT", frame, "LEFT")
	text:SetText(L["Show Source:"])

	-- combobox for source filter
	self.sourcefilter = FILTERSRCOPT_ALL
	
	self.logfiltersource = CreateFrame("Frame", ADDON.."SourceFilter", self.logwindow, "UIDropDownMenuTemplate")
	
	self.logfiltersource:ClearAllPoints()
	self.logfiltersource:SetPoint("TOPLEFT", self.logwindow, "TOPLEFT", 355, -30)
	
	UIDropDownMenu_Initialize(self.logfiltersource, InitSourceFilter)
	UIDropDownMenu_SetWidth(self.logfiltersource, 100);
	UIDropDownMenu_SetButtonWidth(self.logfiltersource, 124)
	UIDropDownMenu_JustifyText(self.logfiltersource, "LEFT")
	
	-- THE list
	backdrop = {
		-- path to the background texture
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark", 
		-- path to the border texture
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		-- true to repeat the background texture to fill the frame, false to scale it
		tile = true,
		-- size (width or height) of the square repeating background tiles (in pixels)
		tileSize = 16,
		-- thickness of edge segments and square size of edge corners (in pixels)
		edgeSize = 16,
		-- distance from the edges of the frame to those of the background texture (in pixels)
		insets = {
			left   = 5,
			right  = 5,
			top    = 5,
			bottom = 5
		}
	}
	frame = CreateFrame('Frame', self.logwindow:GetName() .. 'FSList', self.logwindow)
	frame:SetHeight(MAX_LIST_SIZE*LISTENTRYHEIGHT+6)
	frame:SetWidth(480)
	frame:SetBackdrop(backdrop)
	frame:SetPoint("TOPLEFT", self.logwindow, "TOPLEFT", 10, -70)

	-- list entries
	frame.entries = {}

	backdrop = {
		-- path to the background texture
		bgFile = "Interface\\QuestFrame\\UI-QuestTitleHighlight", 
		-- true to repeat the background texture to fill the frame, false to scale it
		tile = false,
		-- distance from the edges of the frame to those of the background texture (in pixels)
		insets = {
			left   = 1,
			right  = 1,
			top    = 1,
			bottom = 1
		}
	}
	
	for i=1, MAX_LIST_SIZE do
		local entry = CreateFrame('Button', frame:GetName() .. 'Entry' .. tostring(i), frame)
		entry:SetHeight(LISTENTRYHEIGHT)
		entry:SetPoint("TOPLEFT",  frame, "TOPLEFT",   3, -1*(i-1)*LISTENTRYHEIGHT - 3)
		entry:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -3, -1*(i-1)*LISTENTRYHEIGHT - 3)
		entry:SetBackdrop(backdrop)
		entry:SetBackdropColor(0, 0, 0, .33)
		-- entry:EnableMouse(true)
		entry:SetScript('OnEnter', function(self) self:SetBackdropColor(1, 1, 1, 1); if self.data then GameTooltip:SetOwner(self, 'ANCHOR_CURSOR'); GameTooltip:SetText(self.data.message); end; end)
		entry:SetScript('OnLeave', function(self) if self.data ~= BrokerRaidFinder.selected_match then self:SetBackdropColor(0, 0, 0, .33); end; GameTooltip:Hide(); end)
		entry:SetScript('OnClick', function(self, button, down) BrokerRaidFinder:SetSelectedEntry(self) end)
		
		frame.entries[i] = entry
		
		-- subframes holding text for time, author and message
		entry.timeframe = CreateFrame('Frame', entry:GetName() .. '1', entry)
		entry.timeframe:SetHeight(LISTENTRYHEIGHT)
		entry.timeframe:SetWidth(60)
		entry.timeframe:SetPoint("TOPLEFT", entry, "TOPLEFT", 5, 0)
		entry.timeframe.text = entry.timeframe:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		entry.timeframe.text:SetAllPoints()
		entry.timeframe.text:SetJustifyH("LEFT")
		
		entry.authorframe = CreateFrame('Frame', entry:GetName() .. '1', entry)
		entry.authorframe:SetHeight(LISTENTRYHEIGHT)
		entry.authorframe:SetWidth(100)
		entry.authorframe:SetPoint("TOPLEFT", entry.timeframe, "TOPRIGHT", 5, 0)
		entry.authorframe.text = entry.authorframe:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		entry.authorframe.text:SetAllPoints()
		entry.authorframe.text:SetJustifyH("LEFT")
		
		entry.msgframe = CreateFrame('Frame', entry:GetName() .. '1', entry)
		entry.msgframe:SetHeight(LISTENTRYHEIGHT)
		entry.msgframe:SetPoint("TOPLEFT", entry.authorframe, "TOPRIGHT", 5, 0)
		entry.msgframe:SetPoint("TOPRIGHT", entry, "TOPRIGHT")
		entry.msgframe.text = entry.msgframe:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		entry.msgframe.text:SetAllPoints()
		entry.msgframe.text:SetJustifyH("LEFT")
	end
	
	-- the scrollframe
	local scroll = CreateFrame('ScrollFrame', frame:GetName() .. 'ScrollFrame', frame, 'FauxScrollFrameTemplate')
	scroll:SetPoint('TOPLEFT', 5, -4)
	scroll:SetPoint('BOTTOMRIGHT', -26, 3)
	scroll:SetScript('OnVerticalScroll', function(self, arg1)
		FauxScrollFrame_OnVerticalScroll(self, arg1, LISTENTRYHEIGHT, function() MatchListUpdate() end)
	end)
	frame.scrollFrame = scroll

	frame:SetScript('OnShow', function(self) MatchListUpdate() end)
	
	self.matchlistframe = frame
	
	-- frame for the whole entry including message
	backdrop = {
		-- path to the background texture
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark", 
		-- path to the border texture
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		-- true to repeat the background texture to fill the frame, false to scale it
		tile = true,
		-- size (width or height) of the square repeating background tiles (in pixels)
		tileSize = 16,
		-- thickness of edge segments and square size of edge corners (in pixels)
		edgeSize = 16,
		-- distance from the edges of the frame to those of the background texture (in pixels)
		insets = {
			left   = 5,
			right  = 5,
			top    = 5,
			bottom = 5
		}
	}
	local frame2 = CreateFrame('Frame', self.logwindow:GetName() .. 'Message', self.logwindow)
	frame2:SetHeight(40)
	frame2:SetWidth(480)
	frame2:SetBackdrop(backdrop)
	frame2:SetPoint("TOPLEFT", self.logwindow, "TOPLEFT", 10, -285)
	
	frame2.text = frame2:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	frame2.text:SetAllPoints()
	frame2.text:SetPoint("TOPLEFT",     frame2, "TOPLEFT",      5, -5)
	frame2.text:SetPoint("BOTTOMRIGHT", frame2, "BOTTOMRIGHT", -5,  5)
	frame2.text:SetJustifyH("LEFT")
	frame2.text:SetJustifyV("TOP")
	frame2.text:SetWordWrap(true)
	frame2.text:SetNonSpaceWrap(false) 
	
	self.messageframe = frame2
	
	-- whisper button
	local button = CreateFrame("Button", nil, self.logwindow, "UIPanelButtonTemplate")
	button:SetHeight(20)
	button:SetWidth(80)
	button:SetText("Whisper")
	button:SetScript("OnClick", function(self, button, down) BrokerRaidFinder:WhisperAuthor() end)
	button:SetPoint("TOPLEFT", self.logwindow, "TOPLEFT", 210, -335)
	
	self.whisperbutton = button
end

function BrokerRaidFinder:ShowLogWindow()
	if not self.logwindow:IsShown() then
		self.logwindow:Show()
	end
end

function BrokerRaidFinder:HandleInstanceFilter(value)
	if not value or value == self.instancefilter then
		return
	end
	
	self.instancefilter = value
		
	self:UpdateLogList()
end

function BrokerRaidFinder:HandleSourceFilter(value)
	if not value or value == self.sourcefilter then
		return
	end
	
	self.sourcefilter = value
	
	self:UpdateLogList()
end

function BrokerRaidFinder:SetSelectedEntry(selected)
	if not selected then
		return
	end
	
	-- deselect old match
	for i=1, MAX_LIST_SIZE do
		local entry = self.matchlistframe.entries[i]

		if entry.data == self.selected_match then
			entry:SetBackdropColor(0, 0, 0, .33)
		end
	end
	
	-- really needed? if we click the frame OnEnter should have colored it properly before anyway
	selected:SetBackdropColor(1, 1, 1, 1)
	
	self.selected_match = selected.data
	
	self:DisplaySelectedMessage()
end

function BrokerRaidFinder:DisplaySelectedMessage()
	if self.selected_match then
		local match = self.selected_match
		local text = LibBabbleZone[match.instance] .. " - [" .. format_time(match.timestamp + self.time_offset) .. "] " .. self:ColorizeChar(match.player) .. ": " .. match.message
		
		self.messageframe.text:SetText(text)
		
		-- enable whisper button
		self.whisperbutton:Enable()		
	else
		self.messageframe.text:SetText("")
		
		-- disable whisper button
		self.whisperbutton:Disable()		
	end
end

function BrokerRaidFinder:UpdateLogList()
	self.filtered_matches = {}

	local now   = time()
	local found = false 
	
	for _, match in pairs(self.db.factionrealm.matches) do
		-- only show if within specified timeframe
		if match.timestamp + self.db.profile.timeFrame*60 < now then
			break
		end
				
		-- check source filter
		local validSource = false
		
		if self.sourcefilter == FILTERSRCOPT_ALL then
			validSource = true
		elseif self.sourcefilter == FILTERSRCOPT_SELF then
			if not match.source and match.char == self.PlayerName then
				validSource = true
			end
		elseif self.sourcefilter == FILTERSRCOPT_ALTS then
			if not match.source and match.char ~= self.PlayerName then
				validSource = true
			end
		elseif self.sourcefilter == FILTERSRCOPT_REMOTE then
			if match.source then
				validSource = true
			end
		end
		
		-- check instance filter
		local validInstance = false

		if self.instancefilter == FILTERINSTOPT_ALL then
			validInstance = true
		elseif match.instance == self.instancefilter then
			validInstance = true
		end
		
		-- insert into filtered matches
		if validSource and validInstance then
			tinsert(self.filtered_matches, match)
			
			if not self.classCache[match.player] and match.class then
				self.classCache[match.player] = match.class
			end
			
			if match == self.selected_match then
				found = true
			end
		end
	end
	
	if not found then
		-- reset selection
		self.selected_match = nil

		self:DisplaySelectedMessage()
	end
	
	MatchListUpdate()
end

