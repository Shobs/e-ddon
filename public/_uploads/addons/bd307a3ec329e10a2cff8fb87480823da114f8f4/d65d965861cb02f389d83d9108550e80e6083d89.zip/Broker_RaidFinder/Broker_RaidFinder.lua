local _G = _G

-- addon name and namespace
local ADDON, NS = ...

-- local functions
local strlower          = strlower
local strfind           = strfind
local strupper          = strupper
local string_format     = string.format
local tinsert           = table.insert
local table_sort        = table.sort
local pairs             = pairs
local time              = time
local floor             = floor
local gsub              = gsub

local GetNumPartyMembers  = _G.GetNumPartyMembers
local GetNumRaidMembers   = _G.GetNumRaidMembers
local GetPlayerInfoByGUID = _G.GetPlayerInfoByGUID
local InCombatLockdown    = _G.InCombatLockdown
local IsControlKeyDown    = _G.IsControlKeyDown
local IsShiftKeyDown      = _G.IsShiftKeyDown
local RequestRaidInfo     = _G.RequestRaidInfo
local UnitName            = _G.UnitName
local ChatFrame_GetMessageEventFilters = _G.ChatFrame_GetMessageEventFilters

-- setup libs
local LibStub   = LibStub
local LDB       = LibStub:GetLibrary("LibDataBroker-1.1")

-- coloring tools
local Crayon	= LibStub:GetLibrary("LibCrayon-3.0")

-- get translations
local L             = LibStub:GetLibrary("AceLocale-3.0"):GetLocale(ADDON)
local LibBabbleZone = LibStub:GetLibrary("LibBabble-Zone-3.0"):GetLookupTable()

-- config libraries
local AceConfig 		= LibStub:GetLibrary("AceConfig-3.0")
local AceConfigReg 		= LibStub:GetLibrary("AceConfigRegistry-3.0")
local AceConfigDialog	= LibStub:GetLibrary("AceConfigDialog-3.0")

local function GetArgs(str, pattern)
   local ret = {}
   local pos=0
   
   while true do
     local word
     _, pos, word=string.find(str, pattern, pos+1)
	 
     if not word then
       break
     end
	 
     --word = string.lower(word)
     table.insert(ret, word)
   end
   
   return ret
end

-- for sorted keyword list we only care that the shortest keywords (which are more likely to produce a match) are first
local function keyword_lt(a, b) 
	return a:len() < b:len() 
end

-- addon and locals
BrokerRaidFinder = LibStub:GetLibrary("AceAddon-3.0"):NewAddon(ADDON, "AceEvent-3.0", "AceConsole-3.0", "AceTimer-3.0")
local BrokerRaidFinder = _G.BrokerRaidFinder

-- constants
BrokerRaidFinder.MODNAME   = "BrokerRaidFinder"
BrokerRaidFinder.FULLNAME  = "Broker: Raid Finder"
BrokerRaidFinder.SHORTNAME = "Raid Finder"

local ICON          = "Interface\\Addons\\"..ADDON.."\\icon.tga"
local ICON_DISABLED = "Interface\\Addons\\"..ADDON.."\\icondisabled.tga"

LibStub:GetLibrary('LibWho-2.0'):Embed(BrokerRaidFinder)

-- colors
NS.HexColors = {
	Blueish  = "04adcb",
	Brownish = "eda55f",
	GrayOut  = "888888",
	Green    = "00ff00",
	Magenta  = "ff00ff",
	Orange   = "e54100",
	Red      = "ff0000",
	White    = "ffffff",
	Yellow   = "ffff00",
}

function NS:Colorize(color, text) return NS.HexColors[color] and ("|cff" .. NS.HexColors[color] .. tostring(text) .. "|r") or tostring(text) end

local ldbObj  = LDB:NewDataObject(ADDON, {
	type	= "data source",
	icon	= ICON,
	label	= BrokerRaidFinder.MODNAME,
	text	= BrokerRaidFinder.SHORTNAME,
	OnClick = function(clickedframe, button) 
		BrokerRaidFinder:OnClick(button) 
	end,
	OnEnter = function ( self )
		BrokerRaidFinder:CreateTooltip(self)
	end,
	OnLeave = function()
		-- BrokerRaidFinder:RemoveTooltip()
		return
	end,
})

--  minimap button
do
	local dragMode = nil
	
	local function moveButton(self)
		if dragMode == "free" then
			local centerX, centerY = Minimap:GetCenter()
			local x, y = GetCursorPosition()
			x, y = x / self:GetEffectiveScale() - centerX, y / self:GetEffectiveScale() - centerY
			self:ClearAllPoints()
			self:SetPoint("CENTER", x, y)
		else
			local centerX, centerY = Minimap:GetCenter()
			local x, y = GetCursorPosition()
			x, y = x / self:GetEffectiveScale() - centerX, y / self:GetEffectiveScale() - centerY
			centerX, centerY = abs(x), abs(y)
			centerX, centerY = (centerX / sqrt(centerX^2 + centerY^2)) * 80, (centerY / sqrt(centerX^2 + centerY^2)) * 80
			centerX = x < 0 and -centerX or centerX
			centerY = y < 0 and -centerY or centerY
			self:ClearAllPoints()
			self:SetPoint("CENTER", centerX, centerY)
		end
	end

	local mm_button = CreateFrame("Button", ADDON .. "_MinimapButton", Minimap)
	mm_button:SetHeight(32)
	mm_button:SetWidth(32)
	mm_button:SetFrameStrata("HIGH")
	mm_button:SetPoint("CENTER", -77.44, -20.06)
	mm_button:SetMovable(true)
	mm_button:SetUserPlaced(true)
	mm_button:EnableMouse(true)
	mm_button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	mm_button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
	
	local icon = mm_button:CreateTexture(mm_button:GetName() .. "Icon", "HIGH")
	icon:SetTexture(ICON)
	icon:SetTexCoord(0, 1, 0, 1)
	icon:SetWidth(16)
	icon:SetHeight(16)
	icon:SetPoint("TOPLEFT", mm_button, "TOPLEFT", 8, -7)
	
	mm_button.icon = icon
	
	local overlay = mm_button:CreateTexture(mm_button:GetName() .. "Overlay", "OVERLAY")
	overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
	overlay:SetWidth(53)
	overlay:SetHeight(53)
	overlay:SetPoint("TOPLEFT", mm_button, "TOPLEFT")
	
	mm_button:SetScript("OnClick", function(self, button)
		BrokerRaidFinder:OnClick(button)
	end)
	
	mm_button:SetScript("OnMouseDown", function(self, button)
		if IsShiftKeyDown() and IsControlKeyDown() then
			dragMode = "free"
			self:SetScript("OnUpdate", moveButton)
		elseif IsShiftKeyDown() then
			dragMode = nil
			self:SetScript("OnUpdate", moveButton)
		end
	end)
	
	mm_button:SetScript("OnMouseUp", function(self)
		self:SetScript("OnUpdate", nil)
	end)

	mm_button:SetScript("OnEnter", function(self)
		BrokerRaidFinder:CreateTooltip(self)
	end)
	
	mm_button:SetScript("OnLeave", function(self)
		BrokerRaidFinder:RemoveTooltip()
	end)
	
	mm_button:Hide()

	function BrokerRaidFinder:ShowMinimapButton(show)
		if show then
			mm_button:Show()
		else
			mm_button:Hide()
		end
	end

	function BrokerRaidFinder:SetMinimapIcon(active)
		if active then
			mm_button.icon:SetTexture(ICON)
		else
			mm_button.icon:SetTexture(ICON_DISABLED)
		end
	end
end
	
-- local variables
local defaults = {
	profile = {
		monitoringActive	= true,
		monitorGuild		= true,
		excludeSavedRaids	= false,
		notifyText			= true,
		notifySound			= false,
		notificationSound	= 0,
		notificationTimeout	= 5,
		timeFrame			= 60,
		addonCommunication	= false,
		hideHint			= false,
        minimap				= false,
        messageFilters		= false,
        filterMatches		= false,
		monitored           = {},
		plugins				= {},
	},
	factionrealm = {
		matches = {},
	},
	global = {
		lfgKeywords      = brf_DefaultLFGKeywords,
		instanceKeywords = {},
	}
}

-- blizzard channels to monitor
local monitored_channels = {
	[1] =  true, -- General
	[2] =  true, -- Trade
	[4] =  true, -- LFG
}

-- chat event filter
local function MessageEventFilterByMatch(self, event, ...)
	local message, author, arg3, arg4, arg5, arg6, arg7, id = ...

	-- under these criteria no matching will be performed by BrokerRaidFinder
	if BrokerRaidFinder.db.profile.monitoringActive == false or
	   author == BrokerRaidFinder.PlayerName or  
	   BrokerRaidFinder:IsInRaid(author) or
	   not BrokerRaidFinder:IsMonitoredChannel(id) then
		return
	end
	
	local match, instance, keyword = BrokerRaidFinder:FindInstanceMatch(message)

	-- if message is matched for an instance then we can filter it
	if match and instance then
		return true
	end
end

-- infrastcructure
function BrokerRaidFinder:OnInitialize()
	-- addon constants
	self.GTIMERANGE = 120	
	
	-- addon variables
	
	-- options
	self.options = {}
	
	-- aux vars 
	self.player_saved_raids = {}
	self.notification_timeouts = {}
	
	-- track combat 
	self.in_combat = false
	
	-- debugging
	self.debug = false
	
	-- unit information
	self.raidNames   = {}
	self.PlayerName  = UnitName("player")
	self.playerName  = strlower(self.PlayerName)

	self.classCache  = {}
	
	-- offset to local time
	local gHour = GetGameTime()
	self.time_offset = (tonumber(gHour) - date("!%H")) * 3600
	
	-- processed data
	self.tainted_data      = true
	self.matched_players   = 0
	self.matched_instances = 0
	self.matches_latest    = {}
	self.filtered_matches  = {}
	
	-- keyword data
	self.lfgKeywordList       = {}
	self.instanceKeywordLists = {}
	
	-- insert default keywords
	self:SetDefaultInstanceKeywords(true)
	
	-- register text colors and shortcuts
	self.text_colors = {}
		
	-- options
	self.db = LibStub:GetLibrary("AceDB-3.0"):New(self.MODNAME.."_DB", defaults, "Default")
	
	self:SetupOptions()

	self:SetupForPlugins()
	
	-- profile support
	self.options.args.profile = LibStub:GetLibrary("AceDBOptions-3.0"):GetOptionsTable(self.db)
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied",  "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset",   "OnProfileChanged")

	AceConfigReg:RegisterOptionsTable(self.FULLNAME, self.options)
	AceConfigDialog:AddToBlizOptions(self.FULLNAME)

	self:RegisterChatCommand("braidfinder", "ChatCommand")
    self:RegisterChatCommand("brfind",      "ChatCommand")
	
	-- interface
	self:SetupInterface()		
end

function BrokerRaidFinder:OnEnable()
	-- redo: offset to local time
	-- seems on initialize the game time is not always set properly
	local gHour = GetGameTime()
	self.time_offset = (tonumber(gHour) - date("!%H")) * 3600
	
	self:SetupEventHandlers()
	
	-- register raid info events
	self:RegisterEvent("UPDATE_INSTANCE_INFO")
	self:RegisterEvent("RAID_INSTANCE_WELCOME")
	self:RegisterEvent("CHAT_MSG_SYSTEM")
	
	-- register raid unit events
	self:RegisterEvent("PARTY_CONVERTED_TO_RAID", "UpdateRaidUnits")
	self:RegisterEvent("PARTY_MEMBERS_CHANGED", "UpdateRaidUnits")

	-- register events to track combat
	self:RegisterEvent("PLAYER_REGEN_ENABLED",  "UpdateCombatState", false)
	self:RegisterEvent("PLAYER_REGEN_DISABLED", "UpdateCombatState", true)
	
	-- wholib query callback
	-- self:RegisterCallback('WHOLIB_QUERY_RESULT', 'UnitInfoCallback')
	
	-- timer for cyclic cleaning up of history
	self.timer = self:ScheduleRepeatingTimer("ManageHistory", 60)
	
	-- update keyword data
	self:UpdateAllKeywords()
	
	-- update cached unit data
	self:UpdateRaidUnits()

	-- set initial combat state
	self:UpdateCombatState()
	
	-- setup message event filter
	self:ActivateMessageEventFilter(self.db.profile.filterMatches)

	self:ShowMinimapButton(self.db.profile.minimap)
	
	self:UpdateIcon()
	self:Update()
	
	-- request info about saved instances
	RequestRaidInfo()
	
	-- setup comm
	self:SetupCommunication()
end

function BrokerRaidFinder:OnDisable()
	-- shut down comm
	self:ShutdownCommunication()

	-- unregister chat events
	self:UnregisterEvent("CHAT_MSG_CHANNEL")
	self:UnregisterEvent("CHAT_MSG_GUILD")
	self:UnregisterEvent("CHAT_MSG_OFFICER")	
	
	-- unregister raid info events
	self:UnregisterEvent("UPDATE_INSTANCE_INFO")
	self:UnregisterEvent("RAID_INSTANCE_WELCOME")
	self:UnregisterEvent("CHAT_MSG_SYSTEM")

	-- unregister raid unit events
	self:UnregisterEvent("PARTY_CONVERTED_TO_RAID")
	self:UnregisterEvent("PARTY_MEMBERS_CHANGED")
	
	-- register events to track combat
	self:UnregisterEvent("PLAYER_REGEN_ENABLED")
	self:UnregisterEvent("PLAYER_REGEN_DISABLED")
	
	self:ShowMinimapButton(false)
	
	-- remove message event filter
	self:ActivateMessageEventFilter(false)
	
	-- cancel timer for cyclic cleaning up of history
	self:CancelTimer(self.timer)
end

function BrokerRaidFinder:OnProfileChanged(event, database, newProfileKey)
	self.db.profile = database.profile
	
	self:SetupEventHandlers()
	
	self.tainted_data = true

	self:UpdateIcon()
	self:Update()
end

function BrokerRaidFinder:ChatCommand(input)
    if input then  
		args = GetArgs(input, "^ *([^%s]+) *")
		
		BrokerRaidFinder:TriggerAction(args[1], args)
	else
		BrokerRaidFinder:TriggerAction("help")
	end
end

function BrokerRaidFinder:OnClick(button)
	if ( button == "RightButton" ) then 
		if IsShiftKeyDown() then
			-- unused
		elseif IsControlKeyDown() then
			-- unused
		elseif IsAltKeyDown() then
			-- unused
		else
			-- open options menu
			BrokerRaidFinder:TriggerAction("menu")
		end
	elseif ( button == "LeftButton" ) then 
		if IsShiftKeyDown() then
			-- unused
		elseif IsControlKeyDown() then
			-- unused
		elseif IsAltKeyDown() then
			-- toggle monitoring
			BrokerRaidFinder:TriggerAction("toggle")
		else
			-- show finder log
			BrokerRaidFinder:TriggerAction("show")
		end
	end
end

function BrokerRaidFinder:TriggerAction(action, args)
	if action == "menu" then
		-- open options menu
		InterfaceOptionsFrame_OpenToCategory(self.FULLNAME)
	elseif action == "version" then
		-- print version information
		self:PrintVersionInfo()
	elseif action == "debug" then
		if args[2] == "on" then
			self:Output("debug mode turned on")
			self.debug = true
		end
		if args[2] == "off" then
			self:Output("debug mode turned off")
			self.debug = false
		end
	elseif action == "toggle" then
		self:ToggleMonitoring()
		self:Output(L["Monitoring is "] .. (self.db.profile.monitoringActive and L["on"] or L["off"]))
	elseif action == "on" then
		self:ActivateMonitoring(true)
		self:Output(L["Monitoring is "] .. (self.db.profile.monitoringActive and L["on"] or L["off"]))
	elseif action == "off" then
		self:ActivateMonitoring(false)
		self:Output(L["Monitoring is "] .. (self.db.profile.monitoringActive and L["on"] or L["off"]))
	elseif action == "show" then
		self:ShowLogWindow()
	elseif action == "friends" then
		if next(self.comm_friends) then
			for player, _ in pairs(self.comm_friends) do
				self:Output("Friend: " .. player)
			end
		else
			self:Output("No friends.")
		end
		if next(self.comm_bnetfriends) then
			for player, _ in pairs(self.comm_bnetfriends) do
				self:Output("BNetFriend: " .. player)
			end
		else
			self:Output("No bnetfriends.")
		end
	elseif action == "remote" then
		self:Output("Partners:")
		for partner, _ in pairs(self.partners) do
			self:Output(tostring(partner))
		end
		self:Output("Clients:")
		for client, _ in pairs(self.clients) do
			self:Output(tostring(client))
			self:Output("Instances:")
			for instance, clients in pairs(self.comm_clientconfig) do
				for c, _ in pairs(clients) do
					if c == client then
						self:Output(instance)
					end
				end
			end
		end
		if self.server then
			self:Output("Server: " .. tostring(self.server))
		else
			self:Output("Server: none")
		end
		self:Output("Blacklisted:")
		for blacklisted, _ in pairs(self.comm_blacklist) do
			self:Output(tostring(blacklisted))
		end
		self:Output("Comm quality: " .. tostring(self.comm_quality))
		self:Output("Comm numclients: " .. tostring(self.comm_numclients))
		self:Output("Numclients: " .. tostring(self.numclients))
	elseif action == "saved" then
		if next(self.player_saved_raids) then
			for instance, _ in pairs(self.player_saved_raids) do
				self:Output(instance)
			end
		else
			self:Output("No saved raids.")
		end
	elseif action == "plugin" then
		self:HandlePluginAction(args[2], args, 3)
	else -- if action == "help" then
		-- display help
		self:Output(L["Usage:"])
		self:Output(L["/braidfinder arg"])
		self:Output(L["/brfind arg"])
		self:Output(L["Args:"])
		self:Output(L["version - display version information"])
		self:Output(L["menu - display options menu"])
		self:Output(L["on - activate monitoring"])
		self:Output(L["off - deactivate monitoring"])
		self:Output(L["show - show log window"])
		self:Output(L["help - display this help"])
	end
end

function BrokerRaidFinder:ActivateMessageEventFilter(activate)
	if activate then
		ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL", MessageEventFilterByMatch)
	else
		ChatFrame_RemoveMessageEventFilter("CHAT_MSG_CHANNEL", MessageEventFilterByMatch)
	end
end

-- update functions
function BrokerRaidFinder:Update()
	self:UpdateData()
	self:UpdateLabel()
end

-- aggregate some meaningful data from the list of matches for display on label/tooltip and internal processing
-- match_oldest:
-- 		used to determine when the next data update is needed because match is older than allowed by configured the time frame
-- matched_players/_instances:
-- 		aggregates the total number of players/instances from valid matches 
-- matches_latest:
-- 		for every instance the time and author of the most recent match is stored along with the total number of matches for that instance
function BrokerRaidFinder:UpdateData()
	self:UpdateLogList()

	if self.tainted_data == false then
		return
	end

	local players = {}
	local instances = {}
	
	local now = time()
		
	self.matches_latest = {}
	self.match_oldest   = nil
	
	for _, match in pairs(self.db.factionrealm.matches) do
		if match.timestamp + self.db.profile.timeFrame*60 < now then
			break
		end

		if self:IsMonitored(match.instance) and not self:ExcludeAsSaved(match.instance) then
			players[match.player] = true
			instances[match.instance] = true

			if not self.matches_latest[match.instance] then
				local last = {
					player    = match.player,
					timestamp = match.timestamp,
					players   = { }
				}
				self.matches_latest[match.instance] = last
			end

			self.matches_latest[match.instance].players[match.player] = true
			
			self.match_oldest = match
		end
	end
	
	self.matched_players   = 0
	
	for _ in pairs(players) do
		self.matched_players = self.matched_players + 1
	end

	self.matched_instances = 0
	
	for _ in pairs(instances) do
		self.matched_instances = self.matched_instances + 1
	end	

	for _, match in pairs(self.matches_latest) do
		local count = 0
		
		for _ in pairs(match.players) do
			count = count + 1
		end
		
		match.players = count
	end
		
	self.tainted_data = false
end

function BrokerRaidFinder:UpdateLabel()
	local text = L["I: "] .. tostring(self.matched_instances) .. " / " .. L["P: "] .. tostring(self.matched_players)
	
	if not self.db.profile.monitoringActive or not next(self.db.profile.monitored) then
		text = NS:Colorize("GrayOut", text)
	elseif self.matched_instances == 0 then
		text = NS:Colorize("Red", text)
	else
		text = NS:Colorize("Green", text)
	end
	
	if self.server then
		text = text .. " " .. NS:Colorize("Green", "!")
	end

	-- append plugin texts
	for name, plugin in pairs(self.plugins) do
		if self:ShowPluginLabel(name) and plugin:IsActive() then
			local ptext = plugin:GetLabelText()
			
			if ptext then
				text = text .. " " .. ptext
			end
		end
	end
	
	ldbObj.text = text
end

function BrokerRaidFinder:UpdateIcon()
    if self.db.profile.monitoringActive then
		ldbObj.icon = ICON
    else
		ldbObj.icon = ICON_DISABLED
    end
	
	self:SetMinimapIcon(self.db.profile.monitoringActive)
end

-- update cached data function
function BrokerRaidFinder:UpdateRaidInfo()
	self.player_saved_raids = {}

	local numSaved = GetNumSavedInstances()
	
	-- we do not distinguish between different difficulties
	for i = 1, numSaved do
		local instanceName, instanceID, instanceReset, instanceDifficulty, locked, extended, instanceIDMostSig, isRaid, maxPlayers, difficultyName, maxBosses, defeatedBosses = GetSavedInstanceInfo(i)
		
		if isRaid and locked then
			instance = self:FuzzySearchInstance(instanceName)

			if instance then
				self.player_saved_raids[instance] = true
			end
		end
	end
end

-- since we need to map the localized name returned by GetSavedInstanceInfo to our internal non-localized instance name
-- we perform a very simple matching algorithm to do the task
-- if pattern contains all of the significant words (longer than 3 chars) we assume we found the match
function BrokerRaidFinder:FuzzySearchInstance(pattern)
	if not pattern then
		return
	end
	
	pattern = strlower(pattern)

	for name, _ in pairs(brf_DefaultInstanceKeywords) do
		local localized = LibBabbleZone[name]
		localized = strlower(localized)
		
		local matched = true
		
		for word in string.gmatch(localized, "[^%s%p%c]+") do
		    -- significant length of a word is 4 characters
			-- not sure if that works well with all possible localizations
			if string.len(word) > 3 then
				matched = matched and strfind(pattern, word)
			end
		end
		
		if matched then
			return name
		end
	end
	
	return 
end

function BrokerRaidFinder:UpdateRaidUnits()
	self.raidNames = {}
	
	if GetNumRaidMembers() > 0 then
		for i = 1, 40, 1 do
			local unit = "raid"..i
			local name = UnitName(unit)
			
			if name then
				self.raidNames[name] = true
			end
		end
	elseif GetNumPartyMembers() > 0 then
		for i = 1, 4, 1 do
			local unit = "party"..i
			local name = UnitName(unit)
			
			if name then
				self.raidNames[name] = true
			end
		end
	end
end

function BrokerRaidFinder:UpdateCombatState(in_combat)
	if in_combat == nil then
		self.in_combat = InCombatLockdown()
	else
		self.in_combat = in_combat
	end
	
	self:Debug("UpdateCombatState: now " .. tostring(self.in_combat))
end

-- update keyword lists
function BrokerRaidFinder:SetDefaultInstanceKeywords(init)
	for instance, _ in pairs(brf_DefaultInstanceKeywords) do
		self:SetDefaultKeywords(instance, init)
	end
end

function BrokerRaidFinder:SetDefaultKeywords(instance, init)
	if init then
		defaults.global.instanceKeywords[instance] = brf_DefaultInstanceKeywords[instance]
	else
		self.db.global.instanceKeywords[instance] = brf_DefaultInstanceKeywords[instance]
	end
end

function BrokerRaidFinder:UpdateAllKeywords()
	self:UpdateLFGKeywords()

	for instance, _ in pairs(self.db.global.instanceKeywords) do
		self:UpdateInstanceKeywords(instance)
	end
end

function BrokerRaidFinder:UpdateLFGKeywords()
	self.lfgKeywordList = self:GetKeywordList(self.db.global.lfgKeywords)
end

function BrokerRaidFinder:UpdateInstanceKeywords(instance)
	if not instance then
		return
	end
	
	self.instanceKeywordLists[instance] = self:GetKeywordList(self.db.global.instanceKeywords[instance])	
end

function BrokerRaidFinder:GetKeywordList(keywords)
	if not keywords then
		return {}
	end

	local list =  {}
	
	-- get all words separated by comma and trim left and right
	for word in string.gmatch(keywords, "[^,]+") do 
		word = word:gsub("^%s*(.-)%s*$", "%1")
		if word ~= "" then
			list[#list+1] = strlower(word)
		end
	end
	
	-- sort list by keyword length, shortest first
	table_sort(list, keyword_lt)
	
	return list
end

-- event handlers
function BrokerRaidFinder:SetupEventHandlers()
	if self.db.profile.monitoringActive == true then
		self:RegisterEvent("CHAT_MSG_CHANNEL")
	else
		self:UnregisterEvent("CHAT_MSG_CHANNEL")	
	end

	self:SetupGuildChatEventHandlers()
end

function BrokerRaidFinder:SetupGuildChatEventHandlers()
	if self.db.profile.monitoringActive == true and self.db.profile.monitorGuild == true then
		self:RegisterEvent("CHAT_MSG_GUILD")
		self:RegisterEvent("CHAT_MSG_OFFICER")	
	else
		self:UnregisterEvent("CHAT_MSG_GUILD")
		self:UnregisterEvent("CHAT_MSG_OFFICER")	
	end
end

function BrokerRaidFinder:CHAT_MSG_CHANNEL(event, ...)
	local message, author, _, _, _, _, _, id, _, _, _, guid = ...
	
	if self:IsMonitoredChannel(id) then
		-- apply chat filter to sort out spam
		if self.db.profile.messageFilters and self:IsFilteredByMessageEventFilters(event, ...) then
			-- message is filtered out
			return
		end
		
		-- get authors class
		self:AddToClassCache(author, guid)	
	
		-- proceed with original data (ignore any changes made by event filter functions)
		self:HandleMessage(message, author)
	end
end

function BrokerRaidFinder:CHAT_MSG_GUILD(event, ...)
	local message, author, _, _, _, _, _, id, _, _, _, guid = ...
	
	-- get authors class
	self:AddToClassCache(author, guid)	
	
	-- guild messages are for local use only
	self:HandleMessage(message, author, true)
end

function BrokerRaidFinder:CHAT_MSG_OFFICER(event, ...)
	local message, author, _, _, _, _, _, id, _, _, _, guid = ...
	
	-- get authors class
	self:AddToClassCache(author, guid)	
	
	-- officer messages are for local use only
	self:HandleMessage(message, author, true)
end

-- saved raid info events
function BrokerRaidFinder:UPDATE_INSTANCE_INFO()
	self:UpdateRaidInfo()
end

function BrokerRaidFinder:RAID_INSTANCE_WELCOME()
	RequestRaidInfo()
end

function BrokerRaidFinder:CHAT_MSG_SYSTEM(msg)
	if tostring(msg) == _G["INSTANCE_SAVED"] then
		RequestRaidInfo()
	end
end

-- user functions
function BrokerRaidFinder:PrintVersionInfo()
    self:Output(L["Version"] .. " " .. NS:Colorize("White", GetAddOnMetadata(ADDON, "Version")))
end

-- utilities
function BrokerRaidFinder:Output(msg)
	if ( msg ~= nil and DEFAULT_CHAT_FRAME ) then
		DEFAULT_CHAT_FRAME:AddMessage( self.MODNAME..": "..msg, 0.6, 1.0, 1.0 )
	end
end

function BrokerRaidFinder:IsMonitoredChannel(id)
	return monitored_channels[id] == true
end

function BrokerRaidFinder:AddToClassCache(name, guid)
	if not guid or type(guid) ~= "string" or guid:len() == 0 then
		return
	end
	
	if name and not self.classCache[name] then
		local _, class = GetPlayerInfoByGUID(guid)
		
		if class then
			self.classCache[name] = class
		end
	end
end

function BrokerRaidFinder:ColorizeChar(name)
	if not name then
		return
	end
	
	local class = self.classCache[name]
	
	if not class then
		local result = self:UserInfo(name, {queue = self.WHOLIB_QUEUE_QUIET,	timeout = -1, callback = 'UnitInfoCallback'}) --flags = self.WHOLIB_FLAG_ALWAYS_CALLBACK, 
		
		if result then
			self:UnitInfoCallback(result)
			
			class = self.classCache[name]
		end
	end
	
	if class then
		local colortable = _G["CUSTOM_CLASS_COLORS"] or _G["RAID_CLASS_COLORS"]
		local color = colortable[class]
		return "|cff" .. string.format("%02x%02x%02x", color.r*255, color.g*255, color.b*255) .. name .. "|r"
	else
		return NS:Colorize("GrayOut", name)
	end
end

function BrokerRaidFinder:UnitInfoCallback(user, time)
	if user and user.Class then
		self.classCache[user.Name] = gsub(strupper(user.Class), " ", "")
	end		
end

function BrokerRaidFinder:IsMonitored(instance)
	return self.db.profile.monitored[instance] == true
end

function BrokerRaidFinder:IsSaved(instance)
	return self.player_saved_raids[instance] == true
end

function BrokerRaidFinder:ExcludeAsSaved(instance)
	if self.db.profile.excludeSavedRaids then
		return self.player_saved_raids[instance] == true
	else
		return false
	end
end

function BrokerRaidFinder:PlaySoundFile()
	local sound = self:GetSoundFile(self.db.profile.notificationSound)

	if ((string.sub(sound, -4) == ".wav") or (string.sub(sound, -4) == ".mp3")) then
		PlaySoundFile(sound)
	else
		PlaySound(sound)
	end
end

function BrokerRaidFinder:IsInRaid(name)
	return self.raidNames[name] ~= nil
end

function BrokerRaidFinder:WhisperAuthor()
	if not self.selected_match then
		return
	end

	DEFAULT_CHAT_FRAME.editBox:Show()
	DEFAULT_CHAT_FRAME.editBox:SetText("/whisper " .. self.selected_match.player .. " ")
end

-- testing
function BrokerRaidFinder:Debug(msg)
	if self.debug then
		if ( msg ~= nil and DEFAULT_CHAT_FRAME ) then
			DEFAULT_CHAT_FRAME:AddMessage( self.MODNAME .. " (dbg): " .. msg, 1.0, 0.37, 0.37 )
		end
	end
end

-- data handling

-- NOTE: the filters are applied for message display anyway, but in order to sort out the spam for our purposes we have to execute it once more
-- NOTE: auto-reporting of spam done in filter functions will probably executed again as well
function BrokerRaidFinder:IsFilteredByMessageEventFilters(event, ...)
	local chatFilters = ChatFrame_GetMessageEventFilters(event)
	
	if chatFilters then
		for _, filterFunc in next, chatFilters do
			-- check all filters but our own
			-- NOTE: we dont care about any changes made to the args, we just want to know if the original message is filtered or not
			if filterFunc ~= MessageEventFilterByMatch and filterFunc(self.logwindow, event, ...) then 
				return true
			end
		end 
	end 
	
	return false
end

function BrokerRaidFinder:HandleMessage(msg, author, restricted)
	local instance, keyword = self:ProcessMessage(msg, author, nil, restricted)
	
	if not restricted then
		self:ProcessMessageForClients(msg, author, keyword, instance)
	end
end

function BrokerRaidFinder:ProcessMessage(msg, author, source, restricted)
	if self.db.profile.monitoringActive == false or
	   author == self.PlayerName or  
	   self:IsInRaid(author) then
		return
	end

	local match, instance, keyword = self:FindInstanceMatch(msg)
	
	if not match then
		return
	end
	
	-- setup event and data for plugin notification
	local event = self.EVENT_MATCH_LFG
	
	local data = {
		message    = msg,
		author     = author,
		instance   = instance,
		keyword    = keyword,
		source     = source,
		restricted = restricted,
	}
	
	-- process matched instance
	if instance then
		-- update class cache if necessary
		if not self.classCache[author] then
			-- request user info (negative timeout means we always prefer the cache, which is sufficiant for retrieving the class info only)
			local result = self:UserInfo(author, {queue = self.WHOLIB_QUEUE_QUIET,	timeout = -1, callback = 'UnitInfoCallback'}) --flags = self.WHOLIB_FLAG_ALWAYS_CALLBACK, 
			
			if result then
				self:UnitInfoCallback(result)
			end
		end
		
		-- insert match into list
		local match = self:InsertMatch(author, msg, instance, source)
		
		-- trigger notification
		self:NotifyMatch(match)
		
		-- notify plugins
		if source then
			event = self.EVENT_MATCH_REMOTE
		else
			event = self.EVENT_MATCH_LOCAL
		end

		self:Update()						
	end
	
	-- notify plugins about lfg match
	self:PluginsHandleEvent(event, data)
	
	return instance, keyword
end

function BrokerRaidFinder:FindInstanceMatch(msg)
	local lmsg = strlower(msg)
	
	-- check for 'looking for' keywords
	if not self:IsLFGMessage(lmsg, true) then
		return false
	end

	-- after 'looking for' match we need to find an instance match
	local matched_keyword  = nil
	local matched_instance = nil
	
	-- for all extensions
	for extension, instances in pairs(brf_Instances) do
		-- for all instances
		for _, instance in pairs(instances) do
		
			if self:IsMonitored(instance) then 
				-- for all keywords
				local keywords = self.instanceKeywordLists[instance] or {}
				
				for _, keyword in pairs(keywords) do
					if strfind(lmsg, keyword) then
						matched_keyword  = keyword
						matched_instance = instance
						
						break
					end
				end
			end
		end
	end
	
	return true, matched_instance, matched_keyword
end

function BrokerRaidFinder:IsLFGMessage(msg, is_lower)
	if not is_lower then
		msg = strlower(msg)
	end
	
	-- check for 'looking for' keywords
	for _, keyword in pairs(self.lfgKeywordList) do
		if strfind(msg, keyword) then
			return true
		end
	end
	
	return false
end

function BrokerRaidFinder:InsertMatch(author, msg, instance, source)
	if not author or not msg or not instance then
		return nil
	end
	
	local match = {
		timestamp = time(),
		char      = self.PlayerName,
		instance  = instance,
		player    = author,
		class     = self.classCache[author],
		message   = msg,
		source    = source,
	}
						
	-- remove last entry by author to the very same instance	
	for index, entry in pairs(self.db.factionrealm.matches) do
		if entry.instance == match.instance and
		   entry.player == match.player then
			tremove(self.db.factionrealm.matches, index)
			
			break
		end
	end
	
	-- insert at the beginning
	tinsert(self.db.factionrealm.matches, 1, match)

	self.tainted_data = true
	
	return match
end					

function BrokerRaidFinder:NotifyMatch(match)
	local author   = match.player
	local instance = match.instance
	
	if not author or not instance then
		return
	end

	-- check notification timeout
	local donotify = true
	
	if not self.notification_timeouts[author] then
		self.notification_timeouts[author] = {}
	end
	
	if self.notification_timeouts[author][instance] and self.notification_timeouts[author][instance] + self.db.profile.notificationTimeout*60 > match.timestamp then
		donotify = false
	end						

	-- notification only if last match wasn't by same player to prevent spamming					
	if donotify then
		if self.db.profile.notifyText then
			self:Output("Found new match for " .. instance .." by player " .. author .. ".")
		end

		if self.db.profile.notifySound then
			self:PlaySoundFile()
		end
		
		-- update notification timeout timestamp
		self.notification_timeouts[author][instance] = match.timestamp
	end
end

function BrokerRaidFinder:ManageHistory()
	local now           = time()
	local oldestvalid   = now - self.GTIMERANGE*60
	local oldestframe   = now - self.db.profile.timeFrame*60
	
	-- remove all matches outside global maximum time range
	while #self.db.factionrealm.matches ~= 0 and self.db.factionrealm.matches[#self.db.factionrealm.matches].timestamp < oldestvalid do
		tremove(self.db.factionrealm.matches)
	end
	
	-- currently stored oldest match is out of the timeframe now, so we need
	if self.match_oldest and self.match_oldest.timestamp < oldestframe then
		self.tainted_data = true
	end

	if self.tainted_data then
		self:Update()
	end
end
