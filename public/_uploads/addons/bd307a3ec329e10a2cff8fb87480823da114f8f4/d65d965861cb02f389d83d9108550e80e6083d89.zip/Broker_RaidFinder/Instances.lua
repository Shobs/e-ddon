-- addon name and namespace
local ADDON, NS = ...

-- get translations
local L = LibStub:GetLibrary("AceLocale-3.0"):GetLocale(ADDON)

brf_Extensions = {
	[1] = "Classic",
	[2] = "The Burning Crusade",
	[3] = "Wrath of the Lich King",
	[4] = "Cataclysm",
}

brf_Instances = {
	-- Classic
	[1] = {
		"Blackwing Lair",
		"Blackrock Spire",
		"Molten Core",
		"Ruins of Ahn'Qiraj",
		"Temple of Ahn'Qiraj",
	},
	-- The Burning Crusade
	[2] = {
		"Black Temple",
		"Gruul's Lair",
		"Karazhan",
		"Magtheridon's Lair",
		"Mount Hyjal",
		"Serpentshrine Cavern",
		"Sunwell Plateau",
		"Tempest Keep",
		"Zul'Aman",
	},
	-- Wrath of the Lich King
	[3] = {
		"The Eye of Eternity",
		"Icecrown Citadel",
		"Naxxramas",
		"The Nexus",
		"The Obsidian Sanctum",
		"Onyxia's Lair",
		"The Ruby Sanctum",
		"Ulduar",
		"Vault of Archavon",
	},
	-- Cataclysm
	[4] = {
		"Baradin Hold",
		"The Bastion of Twilight",
		"Blackwing Descent",
		"Dragon Soul",
		"Firelands",
		"Throne of the Four Winds",
	},
}

brf_DefaultLFGKeywords = L["LFGDefaultKeywords"]

brf_DefaultInstanceKeywords = {
	-- Classic
	["Blackwing Lair"]           = L["DefaultKeywords-Blackwing Lair"],
	["Blackrock Spire"]          = L["DefaultKeywords-Blackrock Spire"],
	["Molten Core"]              = L["DefaultKeywords-Molten Core"],
	["Ruins of Ahn'Qiraj"]       = L["DefaultKeywords-Ruins of Ahn'Qiraj"],
	["Temple of Ahn'Qiraj"]      = L["DefaultKeywords-Temple of Ahn'Qiraj"],
	-- The Burning Crusade
	["Black Temple"]             = L["DefaultKeywords-Black Temple"],
	["Gruul's Lair"]             = L["DefaultKeywords-Gruul's Lair"],
	["Karazhan"]                 = L["DefaultKeywords-Karazhan"],
	["Magtheridon's Lair"]       = L["DefaultKeywords-Magtheridon's Lair"],
	["Mount Hyjal"]              = L["DefaultKeywords-Mount Hyjal"],
	["Serpentshrine Cavern"]     = L["DefaultKeywords-Serpentshrine Cavern"],
	["Sunwell Plateau"]          = L["DefaultKeywords-Sunwell Plateau"],
	["Tempest Keep"]             = L["DefaultKeywords-Tempest Keep"],
	["Zul'Aman"]                 = L["DefaultKeywords-Zul'Aman"],
	-- Wrath of the Lich King
	["The Eye of Eternity"]      = L["DefaultKeywords-The Eye of Eternity"],
	["Icecrown Citadel"]         = L["DefaultKeywords-Icecrown Citadel"],
	["Naxxramas"]                = L["DefaultKeywords-Naxxramas"],
	["The Nexus"]                = L["DefaultKeywords-The Nexus"],
	["The Obsidian Sanctum"]     = L["DefaultKeywords-The Obsidian Sanctum"],
	["Onyxia's Lair"]            = L["DefaultKeywords-Onyxia's Lair"],
	["The Ruby Sanctum"]         = L["DefaultKeywords-The Ruby Sanctum"],
	["Ulduar"]                   = L["DefaultKeywords-Ulduar"],
	["Vault of Archavon"]        = L["DefaultKeywords-Vault of Archavon"],
	-- Cataclysm
	["Baradin Hold"]             = L["DefaultKeywords-Baradin Hold"],
	["The Bastion of Twilight"]  = L["DefaultKeywords-The Bastion of Twilight"],
	["Blackwing Descent"]        = L["DefaultKeywords-Blackwing Descent"],
	["Dragon Soul"]              = L["DefaultKeywords-Dragon Soul"],
	["Firelands"]                = L["DefaultKeywords-Firelands"],
	["Throne of the Four Winds"] = L["DefaultKeywords-Throne of the Four Winds"],
}
