local _G = _G

-- addon name and namespace
local ADDON, NS = ...

local BrokerRaidFinder = _G.BrokerRaidFinder

-- addon constants
local MODNAME   = "BrokerRaidFinder"

-- local functions
local tinsert           = table.insert
local pairs             = pairs

-- get translations
local L             = LibStub:GetLibrary("AceLocale-3.0"):GetLocale(ADDON)

-- plugin handling
function BrokerRaidFinder:SetupForPlugins()
	self.EVENT_MATCH_LFG    = 1
	self.EVENT_MATCH_LOCAL  = 2
	self.EVENT_MATCH_REMOTE = 3

	self.plugins = {}
	
	self.options.args["plugins"] = {
		type = 'group',
		name = L["Plugins"],
		desc = L["Manage plugins."],
		order = 100,
		args = {
			-- filled dynamically
		},
	}
	
	-- decouple refresh requests by plugins
	self.plugin_label_needs_refresh = false
	self.plugin_label_update_timer = self:ScheduleRepeatingTimer("RefreshPluginLabel", 1)
end

function BrokerRaidFinder:RegisterPlugin(plugin)
	if not plugin then 
		self:Debug("RegisterPlugin: no plugin provided")
		return false
	end
	
	-- check interface
	if not plugin.GetPluginName or
		not plugin.GetPluginDescription or
		not plugin.IsActive or
		not plugin.SetActive or
		not plugin.GetLabelText or
		not plugin.GetTooltipMessages or
		not plugin.HandleEvent
	then
		self:Debug("RegisterPlugin: plugin doesn't implement interface")
		return false
	end
	
	local name = plugin:GetPluginName()
	
	if not name or name == "" then
		self:Debug("RegisterPlugin: plugin doesn't provide name")
		return false
	end
	
	-- already registered
	if self.plugins[name] then
		self:Debug("RegisterPlugin: plugin '" .. tostring(name) .. "' already registered")
		return false
	end
	
	-- register options
	self:RegisterPluginOptions(plugin)
	
	-- register plugin
	self.plugins[name] = plugin
	
	-- set active
	plugin:SetActive(self:IsPluginActive(name))
	
	return true
end

function BrokerRaidFinder:UnregisterPlugin(plugin)
	if not plugin or not plugin.GetPluginName or not self:HasPlugin(plugin:GetPluginName()) then 
		return
	end
	
	-- unregister options
	self:UnregisterPluginOptions(plugin)
	
	-- unregister plugin
	self.plugins[plugin:GetPluginName()] = nil
end

function BrokerRaidFinder:RegisterPluginOptions(plugin)
	local name = plugin:GetPluginName()

	if self:HasPlugin(name) then
		return
	end

	local plugin_db = self.db.profile.plugins[name]
	
	if not plugin_db then
		plugin_db = {}
		
		plugin_db.active  = false
		plugin_db.label   = true
		plugin_db.tooltip = true		
		
		self.db.profile.plugins[name] = plugin_db
	end
	
	local order = 0
	
	for k, v in pairs(self.plugins) do
		order = order + 10
	end
	
	-- description
	self.options.args.plugins.args[name.."-description"] = {
		type = "description",
		name = NS:Colorize("Yellow", name) .. ": " .. plugin:GetPluginDescription(),
		order = order + 1,
	}	
	
	-- active
	self.options.args.plugins.args[name.."-active"] = {
		type = 'toggle',
		name = L["Active"],
		desc = L["Activate/Deactivate plugin."],
		order = order + 2,
		get = function() 
			return plugin_db.active
		end,
		set = function()
			plugin_db.active = not plugin_db.active
			plugin:SetActive(plugin_db.active)
		end,	
	}
	
	-- label
	self.options.args.plugins.args[name.."-label"] = {
		type = 'toggle',
		name = L["Label"],
		desc = L["Append plugin label text to label."],
		order = order + 3,
		get = function() 
			return plugin_db.label
		end,
		set = function()
			plugin_db.label = not plugin_db.label
			self:UpdateLabel()
		end,	
	}
	
	-- tooltip
	self.options.args.plugins.args[name.."-tooltip"] = {
		type = 'toggle',
		name = L["Tooltip"],
		desc = L["Append plugin messages to tooltip."],
		order = order + 4,
		get = function() 
			return plugin_db.tooltip
		end,
		set = function()
			plugin_db.tooltip = not plugin_db.tooltip
		end,	
	}
end

function BrokerRaidFinder:UnregisterPluginOptions(plugin)
	local name = plugin:GetPluginName()
	
	-- remove plugin active checkbox to plugin page
	self.options.args.plugins.args[name.."-description"] = nil
	self.options.args.plugins.args[name.."-active"]      = nil
	self.options.args.plugins.args[name.."-label"]       = nil
	self.options.args.plugins.args[name.."-tooltip"]     = nil
end

function BrokerRaidFinder:HasPlugin(name)
	return self.plugins[name] ~= nil
end

function BrokerRaidFinder:PluginsHandleEvent(event, data)
	for name, plugin in pairs(self.plugins) do
		if plugin:IsActive() then
			plugin:HandleEvent(event, data)
		end
	end
end

function BrokerRaidFinder:HandlePluginAction(action, args, index)
	if not action or action == "list" then
		self:Output("Registered plugins:")
		for name, plugin in pairs(self.plugins) do
			self:Output(name .. ": " .. (plugin:IsActive() and "activated" or "deactivated"))
		end
		
		return
	end
		
	local name = args and args[index] or nil
	
	if not name then
		self:Output("Missing plugin name.")
		
		return
	end

	if not self:HasPlugin(name) then
		self:Output("Plugin '" .. name .. "' not found.")
		
		return
	end
	
	local plugin = self.plugins[name]
	
	if action == "status" then
		self:Output(name .. ": " .. (plugin:IsActive() and "activated" or "deactivated"))
	elseif action == "activate" then
		plugin:SetActive(true)
	elseif action == "deactivate" then
		plugin:SetActive(false)
	elseif action == "exec" then
		if plugin.TriggerAction then
			local plugin_args = {}
			
			for i = index + 1, #args, 1 do
				tinsert(plugin_args, args[i])
			end
			
			local cmd = plugin_args[1]
			
			plugin:TriggerAction(cmd, plugin_args)
		else
			self:Output("Plugin '" .. name .. "' cannot execute commands.")
		end
	end
	
end

function BrokerRaidFinder:RequestUpdatePluginLabel()
	self.plugin_label_needs_refresh = true
end

function BrokerRaidFinder:RefreshPluginLabel()
	if self.plugin_label_needs_refresh then
		self:UpdateLabel()
		self.plugin_label_needs_refresh = false
	end
end

function BrokerRaidFinder:ShowPluginLabel(name)
	return self.db.profile.plugins[name] and self.db.profile.plugins[name].label or false
end

function BrokerRaidFinder:ShowPluginTooltip(name)
	return self.db.profile.plugins[name] and self.db.profile.plugins[name].tooltip or false
end

function BrokerRaidFinder:IsPluginActive(name)
	return self.db.profile.plugins[name] and self.db.profile.plugins[name].active or false
end