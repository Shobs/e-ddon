local _G = _G

-- addon name and namespace
local ADDON, NS = ...

local BrokerRaidFinder = _G.BrokerRaidFinder

-- local functions
local pairs             = pairs

-- translations
local L             = LibStub:GetLibrary("AceLocale-3.0"):GetLocale(ADDON)
local LibBabbleZone = LibStub:GetLibrary("LibBabble-Zone-3.0"):GetLookupTable()

-- local variables
local soundFiles = {
	[0] = "Sound\\interface\\iTellMessage.wav",
	[1] = "Sound\\Spells\\BeastCall.wav",
	[2] = "Sound\\Doodad\\BellTollAlliance.wav",
	[3] = "Sound\\Doodad\\BellTollHorde.wav",
	[4] = "Sound\\Doodad\\BellTollNightElf.wav",
	[5] = "Sound\\Doodad\\BellTollTribal.wav",
	[6] = "Sound\\Doodad\\BlastedLandsLightningbolt01Stand-Bolt.wav",
	[7] = "Sound\\Spells\\Bonk1.wav",
	[8] = "Sound\\Spells\\Bonk2.wav",
	[9] = "Sound\\Spells\\Bonk3.wav",
	[10] = "Sound\\Doodad\\TK_Control_Consoles.wav",
	[11] = "Sound\\interface\\DropOnGround.wav",
	[12] = "Sound\\interface\\DwarfExploration.wav",
	[13] = "Sound\\Doodad\\DwarfHorn.wav",
	[14] = "Sound\\interface\\Error.wav",
	[15] = "Sound\\Doodad\\Firecrackers_ThrownExplode.wav",
	[16] = "Sound\\Doodad\\G_GongTroll01.wav",
	[17] = "Sound\\Events\\GuldanCheers.wav",
	[18] = "Sound\\Doodad\\KharazahnBellToll.wav",
	[19] = "Sound\\Spells\\KillCommand.wav",
	[20] = "Sound\\interface\\MapPing.wav",
	[21] = "Sound\\Doodad\\G_Mortar.wav",
	[22] = "Sound\\interface\\RaidWarning.wav",
	[23] = "Sound\\interface\\ReadyCheck.wav",
	[24] = "Sound\\Doodad\\BE_ScryingOrb_Explode.wav",
	[25] = "Sound\\Doodad\\Sizzle.wav",
	[26] = "Sound\\Spells\\ThrowWater.wav",
	[27] = "Sound\\interface\\UnsheathMetal.wav",
	[28] = "Sound\\interface\\UnsheathShield.wav",
	[29] = "Sound\\Event Sounds\\Wisp\\WispPissed1.wav",
	[30] = "Sound\\Event Sounds\\Wisp\\WispReady1.wav",
	[31] = "Sound\\Event Sounds\\Wisp\\WispWhat1.wav",
	[32] = "Sound\\Event Sounds\\Wisp\\WispYes1.wav",
}

local soundNames = {
	[0] = L["Default"].." (Tell Message)",
	[1] = "Beast Call",
	[2] = "Bell Toll Alliance",
	[3] = "Bell Toll Horde",
	[4] = "Bell Toll Night Elf",
	[5] = "Bell Toll Tribal",
	[6] = "Bolt",
	[7] = "Bonk 1",
	[8] = "Bonk 2",
	[9] = "Bonk 3",
	[10] = "Control Consoles",
	[11] = "Drop On Ground",
	[12] = "Dwarf Exploration",
	[13] = "Dwarf Horn",
	[14] = "Error",
	[15] = "Firecrackers",
	[16] = "Gong Troll",
	[17] = "Guldan Cheers",
	[18] = "Kharazahn Bell Toll",
	[19] = "Kill Command",
	[20] = "Map Ping",
	[21] = "Mortar",
	[22] = "Raid Warning",
	[23] = "Ready Check",
	[24] = "ScryingOrb Explode",
	[25] = "Sizzle",
	[26] = "ThrowWater",
	[27] = "Unsheath Metal",
	[28] = "Unsheath Shield",
	[29] = "Wisp Pissed",
	[30] = "Wisp Ready",
	[31] = "Wisp What",
	[32] = "Wisp Yes",
}

-- setup
function BrokerRaidFinder:SetupOptions()	
    self.options = {
		handler = BrokerRaidFinder,
		type = 'group',
		args = {
			raids = {
				type = 'group',
				name = L["Raids"],
				desc = L["Set up which raids you will monitor."],
				order = 10,
				args = {
					-- filled dynamically
				},
			},			
			keywords = {
				type = 'group',
				name = L["Keywords"],
				desc = L["Set up keywords for each instance."],
				order = 20,
				args = {
					lfgkeywords = {
						type = "input",
						name = L["LFG Keywords"],
						desc = L["Comma separated list of keywords indicating someone is looking for players for a raid."],
						order = 1,
						multiline = 4,
						get = function()
								return self.db.global.lfgKeywords
							end,
						set = function(info, key)
							self.db.global.lfgKeywords = key
							self:UpdateLFGKeywords()
						end,
					},
					-- restore default keywords button
					defaultlfgkeywords = {
						type = "execute",
						name = L["Default"],
						desc = L["Revert to default LFG keywords"],
						order = 2,
						func = function()
							self.db.global.lfgKeywords = L["LFGDefaultKeywords"]
							self:UpdateLFGKeywords()
						end,	
					}
					-- raid keywords filled dynamically
				},
			},			
			monitoring = {
				type = 'group',
				name = L["Monitoring"],
				desc = L["Set up monitoring parmaters for addon."],
				order = 30,
				args = {
					guild = {
						type = 'toggle',
						name = L["Guild Chat"],
						desc = L["Monitor guild chat."],
						order = 1,
						get = function() return self.db.profile.monitorGuild end,
						set = function() 
							self:ToggleMonitorGuild()
						end,
					},
					saved = {
						type = 'toggle',
						name = L["Exclude Saved Raids"],
						desc = L["Exclude raids you are currently saved to."],
						order = 2,
						get = function() return self.db.profile.excludeSavedRaids end,
						set = function() 
							self:ToggleSavedRaids()
						end,
					},
					timeframe = {
						type = 'range',
						name = L["Time Frame"],
						desc = L["Set up how many minutes the log will reach back."],
						order = 3,
						get = function() return self.db.profile.timeFrame end,
						set = function(info, v) 
							self.db.profile.timeFrame = v
							self:ManageHistory()
						end,
						min = 0,
						max = self.GTIMERANGE,
						step = 1,
					},
				},
			},			
			notifications = {
				type = 'group',
				name = L["Notifications"],
				order = 40,
				desc = L["Set up notifications when addon finds a match."],
				args = {
					text = {
						type = 'toggle',
						name = L["Text Alert"],
						desc = L["Show text message when addon finds a match."],
						order = 1,
						get = function() return self.db.profile.notifyText end,
						set = function() 
							self.db.profile.notifyText = not self.db.profile.notifyText
						end,
					},
					sound = {
						type = 'toggle',
						name = L["Sound Alert"],
						desc = L["Play sound when addon finds a match."],
						order = 2,
						get = function() return self.db.profile.notifySound end,
						set = function() 
							self.db.profile.notifySound = not self.db.profile.notifySound
						end,
					},
					notificationSound = { 
						type = 'select',
						name = L["Notification Sound"],
						desc = L["Choose sound to be played on notifications."],
						order = 3,
						get = function() return self.db.profile.notificationSound end,	
						set = function(info, key) 
							self.db.profile.notificationSound = key
						end,
						values = soundNames,
					},
					playSound = { 
						type = 'execute',
						name = L["Play Sound"],
						desc = L["Play selected notification sound."],
						order = 4,
						func = function() self:PlaySoundFile() end,	
					},
					timeout = {
						type = 'range',
						name = L["Timeout"],
						desc = L["Set notification timeout. You will not be notified about matches of a single player for the same instance more than once during the timeout duration."],
						order = 5,
						get = function() return self.db.profile.notificationTimeout end,
						set = function(info, v) 
							self.db.profile.notificationTimeout = v
						end,
						min = 0,
						max = self.GTIMERANGE,
						step = 1,
						order = 1
					},
				},
			},
			extras = {
				type = 'group',
				name = L["Extras"],
				order = 50,
				desc = L["Some of the more exotic settings."],
				args = {
					msg_filter = {
						type = 'toggle',
						name = L["Message Filter"],
						desc = L["Applies registered message filters before message processing. If you are using a plugin for forwarding messages it is recommended to run a spam filtering addon and check this option to avoid being reported for spam forwarding by other peoples spam filter addons."],
						order = 1,
						get = function() return self.db.profile.messageFilters end,
						set = function() 
							self.db.profile.messageFilters = not self.db.profile.messageFilters
						end,
					},
					filter_matches = {
						type = 'toggle',
						name = L["Filter Matches"],
						desc = L["If enabled removes matched messages from chat windows."],
						order = 2,
						get = function() return self.db.profile.filterMatches end,
						set = function() 
							self.db.profile.filterMatches = not self.db.profile.filterMatches
							
							self:ActivateMessageEventFilter(self.db.profile.filterMatches)
						end,
					},
				},
			},
			active = { 
				type = "toggle",
				name = L["Monitoring Active"],
				desc = L["Activate/Deactivate the monitoring."],
	            order = 1,
				get = function() return self.db.profile.monitoringActive end,	
				set = function(info, key)
					self:ToggleMonitoring()
				end,
			},
			addonComm  = {
				type = "toggle",
				name = L["Addon Communication"],
				desc = L["Toggle whether or not the addon shall sync with addons of other players. This is restricted to (mutual) friends and guild members."],
				order = 2,
				get = function() return self.db.profile.addonCommunication end,
				set = function() 
					self:ToggleAddonCommunication()
				end,
			},
			minimap = {
				type = 'toggle',
				name = L["Minimap Button"],
				desc = L["Show Minimap Button."],
				order = 3,
				get  = function() return self.db.profile.minimap end,
				set  = function()
					self.db.profile.minimap = not self.db.profile.minimap
					
					BrokerRaidFinder:ShowMinimapButton(self.db.profile.minimap)
				end,
			},
			hint = {
				type = 'toggle',
				name = L["Hide Hint"],
				desc = L["Hide usage hint in tooltip."],
				order = 4,
				get  = function() return self.db.profile.hideHint end,
				set  = function()
					self.db.profile.hideHint = not self.db.profile.hideHint; 
				end,
			},
		},
	}
	
	self:InsertRaidOptions()
end

function BrokerRaidFinder:InsertRaidOptions()
	for extension, instances in pairs(brf_Instances) do
		
		-- preface raids by extension name
		self.options.args.raids.args[brf_Extensions[extension]] = {
			type = "description",
			name = NS:Colorize("Orange", L[brf_Extensions[extension]]),
			order = extension*100,
		}
		
		self.options.args.keywords.args[brf_Extensions[extension]] = {
			type = "description",
			name = NS:Colorize("Orange", L[brf_Extensions[extension]]),
			order = extension*100,
		}
		
		for index, instance in pairs(instances) do
			-- raid monitoring
			self.options.args.raids.args[instance] = {
				type = 'toggle',
				name = LibBabbleZone[instance],
				desc = L["Monitor chat for "] .. LibBabbleZone[instance] .. ".",
				order = extension*100+10*index,
				get = function() return self.db.profile.monitored[instance] == true end,
				set = function() 
					self:ToggleInstance(instance)
				end,
			}
			-- raid keywords
			self.options.args.keywords.args[instance] = {
				type = "input",
				name = LibBabbleZone[instance],
				desc = L["Keywords for "] .. LibBabbleZone[instance] .. ".",
				order = extension*100+10*index,
				multiline = 4,
				get = function() return self.db.global.instanceKeywords[instance] end,
				set = function(info, key)
					self.db.global.instanceKeywords[instance] = key
					self:UpdateInstanceKeywords(instance)
				end,
			}
			
			-- restore default keywords button
			self.options.args.keywords.args[instance.."-default"] = {
				type = "execute",
				name = L["Default"],
				desc = L["Revert to default keywords for "] .. LibBabbleZone[instance] .. ".",
				order = extension*100+10*index+1,
				func = function()
					self:SetDefaultKeywords(instance)
					self:UpdateInstanceKeywords(instance)
				end,	
			}
		end
	end	
end

-- settings
function BrokerRaidFinder:ActivateMonitoring(activate)
	if not activate then
		activate = false
	end

	if self.db.profile.monitoringActive ~= activate then
		self:ToggleMonitoring()
		self:UpdateLabel()
	end
end

function BrokerRaidFinder:ToggleMonitoring()
	self.db.profile.monitoringActive = not self.db.profile.monitoringActive
	
	-- setup event handlers
	self:SetupEventHandlers()
	
	self:UpdateIcon()
	self:Update()	
end

function BrokerRaidFinder:ToggleMonitorGuild()
	self.db.profile.monitorGuild = not self.db.profile.monitorGuild
	
	-- setup event handlers
	self:SetupGuildChatEventHandlers()
end

function BrokerRaidFinder:ToggleSavedRaids()
	self.db.profile.excludeSavedRaids = not self.db.profile.excludeSavedRaids
	
	self.tainted_data = true
	
	self:Update()
end

function BrokerRaidFinder:ToggleAddonCommunication()
	self.db.profile.addonCommunication = not self.db.profile.addonCommunication
	
	-- handle comm
	self:PrepareCommunication()
end

function BrokerRaidFinder:ToggleInstance(instance)
	if not brf_DefaultInstanceKeywords[instance] then
		return
	end

	if self.db.profile.monitored[instance] == true then
		self.db.profile.monitored[instance] = nil
	else
		self.db.profile.monitored[instance] = true
	end
	
	self.tainted_data = true
	
	self:UpdateConfigData()

	self:Update()
end

-- utility
function BrokerRaidFinder:GetSoundFile(id)
	return soundFiles[id] or soundFiles[0]
end
