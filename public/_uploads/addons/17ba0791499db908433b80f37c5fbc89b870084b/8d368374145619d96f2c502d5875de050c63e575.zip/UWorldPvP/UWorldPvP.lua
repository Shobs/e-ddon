--print"|cFFC41F3B hi"

local ToolTip = CreateFrame("Frame")
local playerList = {{"Feather of Lead?","0","100",.75,.75,"Somewhere",0,"Unknown",0,"Unknown"}}
local MainFrame = CreateFrame("Frame")
local focusmanager = {}
AlliedMouseoverEnabled = 1
local focusmanagertest = ""
local spec = "none"
local gearRating = "none"
local playerClass = "none"
local allClassSpecs = {{"Death Knight","Blood","Frost","Unholy"},{"Paladin","Holy","Protection","Retribution"},{"Druid","Balance","Feral Combat","Restoration"},{"Hunter","Beast Mastery","Marksmanship","Survival"},{"Mage","Arcane","Fire","Frost"},{"Priest","Discipline","Holy","Shadow"},{"Rogue","Assassination","Combat","Subtlety"},{"Shaman","Elemental","Enhancement","Restoration"},{"Warlock","Affliction","Demonology","Destruction"},{"Warrior","Arms","Fury","Protection"}}
local classColors = {["Death Knight"]="|cFFC41F3B ",["Paladin"]="|cFFF58CBA ",["Druid"]="|cFFFF7D0A ",["Hunter"]="|cFFABD473",["Mage"]="|cFF69CCF0 ",["Priest"]="|cFFFFFFFF ",["Rogue"]="|cFFFFF569 ",["Shaman"]="|cFF0070DE ",["Warlock"]="|cFF9482C9 ",["Warrior"]="|cFFC79C6E ",["none"]="|cFFAAAAAA "}
local allClasses = {"Death Knight","Paladin","Druid","Hunter","Mage","Priest","Rogue","Shaman","Warlock","Warrior"}
local playerName = ""
local focusmanagertemp = {}
local CheckPlayerAvailability = 0
local tempHour,tempMinute = GetGameTime()
local LastMinute = tempHour..tempMinute
local StartOfMinSeconds = GetTime()
UWorldPvPChannel = nil
lastFocusTarget = ""
local BattlegroundMapNames = {"WarsongGulch","ArathiBasin","AlteracValley","StrandoftheAncients","NetherstormArena","IsleofCounquest","TolBarad","TwinPeaks","GilneasBattleground2"}
local mapFileName, textureHeight, textureWidth = GetMapInfo()
local playerLanguage = "Orcish"
local classBaseHealth = {["Hunter"]=54500,["Mage"]=52500,["Death Knight"]=60500,["Paladin"]=61000,["Warrior"]="62000",["Rogue"]=58500,["Priest"]=57500,["Druid"]=59000,["Shaman"]=53500,["Warlock"]=57000} 
local currentTime
local bgPlayers = {} 



local DeathKnightBlood = {"Blood","Heart Strike","Blood-Caked Strike","Bone Shield","Abomination's Might","Vampiric Blood","Rune Tap","Dancing Rune Weapon","Blood Swarm","Blood Shield","Sanguine Fortitude","Will of the Necropolis"}
local DeathKnightBlood1 = {"Blood","Blood Swarm","Blood Shield","Sanguine Fortitude","Vampiric Blood","Will of the Necropolis","Bone Shield"}
local DeathKnightFrost = {"Frost","Frost Strike", "Killing Machine","Pillar of Frost","Hungering Cold","Improved Icy Talons","Howling Blast","Freezing Fog"}
local DeathKnightFrost1 = {"Frost","Killing Machine","Pillar of Frost","Freezing Fog"}
local DeathKnightUnholy = {"Unholy","Scourge Strike","Anti-Magic Zone","Unholy Blight","Ebon Plague","Summon Gargoyle","Sudden Doom","Unholy Might"}
local DeathKnightUnholy1 = {"Unholy","Sudden Doom","Unholy Might"}

local DruidBalance = {"Balance","Starsurge","Typhoon","Moonkin Form","Solar Beam","Sunfire","Force of Nature","Starfall","Earth and Moon","Eclipse (Solar)","Eclipse (Lunar)","Lunar Shower","Owlkin Frenzy","Shooting Stars"}
local DruidBalance1 = {"Balance","Moonkin Form","Earth and Moon","Force of Nature","Eclipse (Solar)","Eclipse (Lunar)","Lunar Shower","Owlkin Frenzy","Shooting Stars"}
local DruidFeralCombat = {"Feral Combat","Mangle","Feral Charge","Leader of the Pack","Survival instincts","Pulverize","Berserk","Blood in the Water","Natural Reaction","Primal Madness"}
local DruidFeralCombat1 = {"Feral Combat","Berserk","Blood in the Water","Feral Charge","Natural Reaction","Primal Madness"}
local DruidRestoration = {"Restoration","Swiftmend","Nature's Swiftness","Wild Growth","Tree of Life","Efflorescence","Natural Perfection","Revitalize"}
local DruidRestoration1 = {"Restoration","Efflorescence","Tree of Life","Natural Perfection","Nature's Swiftness","Revitalize"}

local HunterBeastMastery = {"Beast Mastery","Intimidation","Focus Fire","Fervor","Bestial Wrath", "Ferocious Inspiration","The Beast Within","Cobra Strikes","Killing Streak"}
local HunterBeastMastery1 = {"Beast Mastery","The Beast Within","Cobra Strikes","Killing Streak"}
local HunterMarksmanship = {"Marksmanship","Aimed Shot","Silencing Shot","Trueshot Aura","Readiness","Chimera Shot","Bombardment","Improved Steady Shot","Ready, Set, Aim...","Posthaste","Rapid Recuperation Effect"}
local HunterMarksmanship1 = {"Marksmanship","Bombardment","Improved Steady Shot","Ready, Set, Aim...","Posthaste","Rapid Recuperation Effect"}
local HunterSurvival = {"Survival","Explosive Shot","Lock and Load","Counterattack","Hunting Party","Wyvern Sting","Sniper Training","Black Arrow","Mirrored Blades"}
local HunterSurvival1 = {"Survival","Mirrored Blades","Lock and Load","Sniper Training"}

local MageArcane = {"Arcane","Arcane Barrage","Presence of Mind","Arcane Tactics","Slow","Focus Magic","Arcane Power","Arcane Potency","Incanter's Absorbtion"}
local MageArcane1 = {"Arcane","Arcane Power","Arcane Potency","Incanter's Absorbtion","Presence of Mind"}
local MageFire = {"Fire","Pyroblast","Blast Wave","Combustion","Dragon's Breath","Living Bomb","Pyromaniac","Firestarter","Hot Streak","Cauterize"}
local MageFire1 = {"Fire","Pyromaniac","Firestarter","Hot Streak","Cauterize"}
local MageFrost = {"Frost","Summon Water Elemental","Icy Veins","Cold Snap","Ice Barrier","Deep Freeze","Fingers of Frost"}
local MageFrost1 = {"Frost","Ice Barrier","Cold Snap","Icy Veins","Fingers of Frost"}

local PaladinHoly = {"Holy","Holy Shock","Divine Favor","Beacon of Light","Aura Mastery","Light of Dawn","Blessed Life","Tower of Radiance","Conviction","Speed of Light","Denounce","Daybreak","Infusion of Light"}
local PaladinHoly1 = {"Holy","Blessed Life","Tower of Radiance","Conviction","Speed of Light","Denounce","Divine Favor","Daybreak","Infusion of Light"}
local PaladinProtection = {"Protection","Avenger's Shield","Hammer of the Righteous","Shield of the Righteous","Divine Guardian","Ardent Defender","Sacred Duty","Guarded by the Light","Holy Shield","Grand Crusader","Sanctuary"}
local PaladinProtection1 = {"Protection","Ardent Defender","Sacred Duty","Guarded by the Light","Holy Shield","Grand Crusader","Sanctuary"}
local PaladinRetribution = {"Retribution","Templar's Verdict","Divine Storm","Rebuke","Repentance","Zealotry","Divine Purpose","Selfless Healer","Long Arm of the Law","The Art of War"}
local PaladinRetribution1 = {"Retribution","Zealotry","Divine Purpose","Selfless Healer","Long Arm of the Law","The Art of War"}

local PriestDiscipline = {"Discipline","Penance","Inner Focus","Power Infusion","Pain Suppression","Power Word: Barrier","Focused Will","Train of Thought","Borrowed Time","Rapture","Inner Focus"}
local PriestDiscipline1 = {"Discipline","Focused Will","Train of Thought","Borrowed Time","Rapture","Inner Focus"}
local PriestHoly = {"Holy","Holy Word: Chastise","Lightwell","Chakra","Circle of Healing","Guardian Spirit","Blessed Resilience","Spirit of Redemption","Serendipity"}
local PriestHoly1 = {"Holy","Blessed Resilience","Chakra","Spirit of Redemption","Serendipity"}
local PriestShadow = {"Shadow","Mind Flay","Shadowform","Silence","Vampiric Embrace","Vampiric Touch","Psychic Horror","Dispersion","Pain and Suffering","Mind Melt","Masochism","Harnessed Shadows"}
local PriestShadow1 = {"Shadow","Dispersion","Pain and Suffering","Mind Melt","Masochism","Shadowform","Harnessed Shadows"}

local RogueAssassination={"Assassination","Mutilate","Cold Blood","Vendetta","Cut to the Chase","Venomous Wounds","Overkill","Seal Fate"}
local RogueAssassination1={"Assassination","Cut to the Chase","Venomous Wounds","Overkill","Cold Blood","Seal Fate"}
local RogueCombat={"Combat","Blade Flurry","Revealing Strike","Adrenaline Rush","Killing Spree","Restless Blades","Bandit's Guile","Combat Potency"}
local RogueCombat1={"Combat","Killing Spree","Restless Blades","Bandit's Guile","Adrenaline Rush","Combat Potency"}
local RogueSubtlety={"Subtlety","Shadowstep","Hemorrhage","Premeditation","Shadow Dance","Serrated Blades","Cheat Death","Energetic Recovery"}
local RogueSubtlety1={"Subtlety","Shadow Dance","Serrated Blades","Cheat Death","Premeditation","Energetic Recovery"}

local ShamanElemental={"Elemental","Thunderstorm","Elemental Mastery","Earthquake","Lava Surge","Feedback","Lava Floes","Rolling Thunder"}
local ShamanElemental1={"Elemental","Lava Surge","Feedback","Elemental Mastery","Lava Floes","Rolling Thunder"}
local ShamanEnhancement={"Enhancement","Lava Lash","Stormstrike","Shamanistic Rage","Feral Spirit","Maelstrom Weapon"}
local ShamanEnhancement1={"Enhancement","Feral Spirit","Maelstrom Weapon","Shamanistic Rage"}
local ShamanRestoration={"Restoration","Earth Shield","Nature's Swiftness","Mana Tide Totem","Riptide","Tidal Waves","Telluric Currents"}
local ShamanRestoration1={"Restoration","Tidal Waves","Telluric Currents","Nature's Swiftness"}

local WarlockAffliction={"Affliction","Unstable Affliction","Curse of Exhaustion","Soul Swap","Haunt","Pandemic","Everlasting Affliction","Death's Embrace","Eradication"}
local WarlockAffliction1={"Affliction","Pandemic","Everlasting Affliction","Death's Embrace","Eradication"}
local WarlockDemonology={"Demonology","Summon Felguard","Demonic Empowerment","Hand of Gul'dan","Metamorphosis","Cremation","Inferno","Decimation","Molten Core","Impending Doom","Improved Health Funnel"}
local WarlockDemonology1={"Demonology","Metamorphisis","Cremation","Inferno","Decimation","Molten Core","Impending Doom","Improved Health Funnel"}
local WarlockDestruction={"Destruction","Conflagrate","Shadowburn","Nether Ward","Shadowfury","Bane of Havoc","Chaos Bolt","Empowered Imp","Fire and Brimstone","Nether Protection","Backlash","Backdraft"}
local WarlockDestruction1={"Destruction","Empowered Imp","Fire and Brimstone","Nether Protection","Nether Ward","Backlash","Backdraft"}

local WarriorArms={"Arms","Slaughter","Mortal Strike","Sweeping Strikes","Deadly Calm","Sudden Death","Throwdown","Bladestorm","Wrecking Crew","Lanbs to the Slaughter","Taste for Blood"}
local WarriorArms1={"Arms","Slaughter","Bladestorm","Wrecking Crew","Sudden Death","Lanbs to the Slaughter","Deadly Calm","Sweeping Strikes","Taste for Blood"}
local WarriorFury={"Fury","Bloodthirst","Death Wish","Raging Blow","Rampage","Heroic Fury","Bloodsurge","Meat Cleaver","Die by the Sword","Flurry","Enrage"}
local WarriorFury1={"Fury","Bloodsurge","Meat Cleaver","Heroic Fury","Die by the Sword","Flurry","Death Wish","Enrage"}
local WarriorProtection={"Protection","Shield Slam","Concussion Blow","Last Stand","Devastate","Vigilance","Shockwave","Sword and Board","Thunderstruck","Impending Victory","Bastion of Defense"}
local WarriorProtection1={"Protection","Sword and Board","Thunderstruck","Impending Victory","Bastion of Defense","Last Stand"}

local allEnemySpecs={DeathKnightBlood,DeathKnightFrost,DeathKnightUnholy,DruidBalance,DruidFeralCombat,DruidRestoration,HunterBeastMastery,HunterMarksmanship,HunterSurvival,MageArcane,MageFire,MageFrost,PaladinHoly,PaladinProtection,PaladinRetribution,PriestDiscipline,PriestHoly,PriestShadow,RogueAssassination,RogueCombat,RogueSubtlety,ShamanElemental,ShamanEnhancement,ShamanRestoration,WarlockAffliction,WarlockDemonology,WarlockDestruction,WarriorArms,WarriorFury,WarriorProtection}

local allEnemySpecs1={DeathKnightBlood1,DeathKnightFrost1,DeathKnightUnholy1,DruidBalance1,DruidFeralCombat1,DruidRestoration1,HunterBeastMastery1,HunterMarksmanship1,HunterSurvival1,MageArcane1,MageFire1,MageFrost1,PaladinHoly1,PaladinProtection1,PaladinRetribution1,PriestDiscipline1,PriestHoly1,PriestShadow1,RogueAssassination1,RogueCombat1,RogueSubtlety1,ShamanElemental1,ShamanEnhancement1,ShamanRestoration1,WarlockAffliction1,WarlockDemonology1,WarlockDestruction1,WarriorArms1,WarriorFury1,WarriorProtection1}

local allEnemySpecSkills={"Heart Strike","Blood-Caked Strike","Bone Shield","Abomination's Might","Vampiric Blood","Rune Tap","Dancing Rune Weapon","Blood Swarm","Blood Shield","Sanguine Fortitude","Will of the Necropolis","Frost Strike", "Killing Machine","Pillar of Frost","Hungering Cold","Improved Icy Talons","Howling Blast","Freezing Fog","Scourge Strike","Anti-Magic Zone","Unholy Blight","Ebon Plague","Summon Gargoyle","Sudden Doom","Unholy Might","Starsurge","Typhoon","Moonkin Form","Solar Beam","Sunfire","Force of Nature","Starfall","Earth and Moon","Eclipse (Solar)","Eclipse (Lunar)","Lunar Shower","Owlkin Frenzy","Shooting Stars","Mangle","Feral Charge","Leader of the Pack","Survival instincts","Pulverize","Berserk","Blood in the Water","Natural Reaction","Primal Madness","Swiftmend","Nature's Swiftness","Wild Growth","Tree of Life","Efflorescence","Natural Perfection","Revitalize","Intimidation","Focus Fire","Fervor","Bestial Wrath", "Ferocious Inspiration","The Beast Within","Cobra Strikes","Killing Streak","Aimed Shot","Silencing Shot","Trueshot Aura","Readiness","Chimera Shot","Bombardment","Improved Steady Shot","Ready, Set, Aim...","Posthaste","Rapid Recuperation Effect","Explosive Shot","Lock and Load","Counterattack","Hunting Party","Wyvern Sting","Sniper Training","Black Arrow","Mirrored Blades","Arcane Barrage","Presence of Mind","Arcane Tactics","Slow","Focus Magic","Arcane Power","Arcane Potency","Incanter's Absorbtion","Pyroblast","Blast Wave","Combustion","Dragon's Breath","Living Bomb","Pyromaniac","Firestarter","Hot Streak","Cauterize","Summon Water Elemental","Icy Veins","Cold Snap","Ice Barrier","Deep Freeze","Fingers of Frost","Holy Shock","Divine Favor","Beacon of Light","Aura Mastery","Light of Dawn","Blessed Life","Tower of Radiance","Conviction","Speed of Light","Denounce","Daybreak","Infusion of Light","Avenger's Shield","Hammer of the Righteous","Shield of the Righteous","Divine Guardian","Ardent Defender","Sacred Duty","Guarded by the Light","Holy Shield","Grand Crusader","Sanctuary","Templar's Verdict","Divine Storm","Rebuke","Repentance","Zealotry","Divine Purpose","Selfless Healer","Long Arm of the Law","The Art of War","Penance","Inner Focus","Power Infusion","Pain Suppression","Power Word: Barrier","Focused Will","Train of Thought","Borrowed Time","Rapture","Inner Focus","Holy","Holy Word: Chastise","Lightwell","Chakra","Circle of Healing","Guardian Spirit","Blessed Resilience","Spirit of Redemption","Serendipity","Mind Flay","Shadowform","Silence","Vampiric Embrace","Vampiric Touch","Psychic Horror","Dispersion","Pain and Suffering","Mind Melt","Masochism","Harnessed Shadows","Mutilate","Cold Blood","Vendetta","Cut to the Chase","Venomous Wounds","Overkill","Seal Fate","Blade Flurry","Revealing Strike","Adrenaline Rush","Killing Spree","Restless Blades","Bandit's Guile","Combat Potency","Shadowstep","Hemorrhage","Premeditation","Preparation","Shadow Dance","Serrated Blades","Cheat Death","Energetic Recovery","Thunderstorm","Elemental Mastery","Earthquake","Lava Surge","Feedback","Lava Floes","Rolling Thunder","Lava Lash","Stormstrike","Shamanistic Rage","Feral Spirit","Maelstrom Weapon","Earth Shield","Nature's Swiftness","Mana Tide Totem","Riptide","Tidal Waves","Telluric Currents","Unstable Affliction","Curse of Exhaustion","Soul Swap","Haunt","Pandemic","Everlasting Affliction","Death's Embrace","Eradication","Summon Felguard","Demonic Empowerment","Hand of Gul'dan","Metamorphosis","Cremation","Inferno","Decimation","Molten Core","Impending Doom","Improved Health Funnel","Conflagrate","Shadowburn","Nether Ward","Shadowfury","Bane of Havoc","Chaos Bolt","Empowered Imp","Fire and Brimstone","Nether Protection","Backlash","Backdraft","Mortal Strike","Sweeping Strikes","Deadly Calm","Sudden Death","Throwdown","Bladestorm","Wrecking Crew","Lanbs to the Slaughter","Taste for Blood","Bloodthirst","Death Wish","Raging Blow","Rampage","Heroic Fury","Bloodsurge","Meat Cleaver","Die by the Sword","Flurry","Enrage","Shield Slam","Concussion Blow","Last Stand","Devastate","Vigilance","Shockwave","Sword and Board","Thunderstruck","Impending Victory","Bastion of Defense"}

local allEnemySpecSkills1 = {"Blood Swarm","Blood Shield","Bone Shield","Sanguine Fortitude","Vampiric Blood","Will of the Necropolis","Killing Machine","Pillar of Frost","Freezing Fog","Sudden Doom","Unholy Might","Moonkin Form","Earth and Moon","Force of Nature","Eclipse (Solar)","Eclipse (Lunar)", "Lunar Shower","Owlkin Frenzy","Shooting Stars","Berserk","Blood in the Water","Feral Charge","Natural Reaction","Primal Madness","Efflorescence","Tree of Life","Natural Perfection","Nature's Swiftness","Revitalize","The Beast Within","Cobra Strikes","Killing Streak","Bombardment","Improved Steady Shot","Ready, Set, Aim...","Posthaste","Rapid Recuperation Effect","Mirrored Blades","Lock and Load","Sniper Training","Arcane Power","Arcane Potency","Incanter's Absorbtion","Presence of Mind","Pyromaniac","Firestarter","Hot Streak","Cauterize","Ice Barrier","Cold Snap","Icy Veins","Fingers of Frost","Blessed Life","Tower of Radiance","Conviction","Speed of Light","Denounce","Divine Favor","Daybreak","Infusion of Light","Ardent Defender","Sacred Duty","Guarded by the Light","Holy Shield","Grand Crusader","Sanctuary","Zealotry","Divine Purpose","Selfless Healer","Long Arm of the Law","The Art of War","Focused Will","Train of Thought","Borrowed Time","Rapture","Inner Focus","Blessed Resilience","Chakra","Spirit of Redemption","Serendipity","Dispersion","Pain and Suffering","Mind Melt","Masochism","Shadowform","Harnessed Shadows","Cut to the Chase","Venomous Wounds","Overkill","Cold Blood","Seal Fate","Killing Spree","Restless Blades","Bandit's Guile","Adrenaline Rush","Combat Potency","Shadow Dance","Serrated Blades","Preparation","Cheat Death","Premeditation","Energetic Recovery","Lava Surge","Feedback","Elemental Mastery","Lava Floes","Rolling Thunder","Feral Spirit","Maelstrom Weapon","Shamanistic Rage","Tidal Waves","Telluric Currents","Nature's Swiftness","Pandemic","Everlasting Affliction","Death's Embrace","Eradication","Metamorphisis","Cremation","Inferno","Decimation","Molten Core","Impending Doom","Improved Health Funnel","Empowered Imp","Fire and Brimstone","Nether Protection","Nether Ward","Backlash","Backdraft","Bladestorm","Wrecking Crew","Sudden Death","Lanbs to the Slaughter","Deadly Calm","Sweeping Strikes","Taste for Blood","Bloodsurge","Meat Cleaver","Heroic Fury","Die by the Sword","Flurry","Death Wish","Enrage","Sword and Board","Thunderstruck","Impending Victory","Bastion of Defense","Last Stand"}

local petAbilities = {"Acid Spit","Ancient Hysteria","Ankle Crack","Axe Toss","Bite","Blood Pact","Burrow Ability","Claw","Clench","Consume Shadows","Cower","Demoralizing Roar","Demoralizing Screech","Devour Magic","Dust Cloud","Fel Intelligence","Felstorm","Ferocious Inspiration","Fire Breath","Firebolt","Flee","Frost Breath","Froststorm Ability","Furious Howl","Gnaw","Gore","Growl","Horn Toss","Huddle","Kindred Spirits","Lash of Pain","Lava Breath","Leap","Legion Strike","Lesser Invisibility","Lightning Breath","Monstrous Bite","Monstrous Blow","Nether Shock","Pin","Prowl","Pummel","Pursuit","Putrid Bulwark","Qiraji Fortitude","Ravage","Rest","Roar of Courage","Sacrifice","Seduction","Serenity Dust","Shadow Bite","Shambling Rush","Shell Shield","Singe Magic","Smack","Snatch","Sonic Blast","Spell Lock","Spirit Mend","Spirit Walk","Spore Cloud","Stampede","Sting","Suffering","Sweeping Claws","Tear Armor","Tendon Rip","Terrifyng Roar","Time Warp","Torment","Trick","Venom Web Spray","Web, Whiplash","Kill Command"}

local meleePlayerAbilities = {"Blood Boil","Blood Strike","Blood-Caked Strike","Death Strike","Pestilence","Heart Strike","Festering Strike","Frost Strike","Mind Freeze","Obliterate","Rune Strike","Necrotic Strike","Plague Strike","Scourge Strike","Bash","Ferocious Bite","Lacerate","Maim","Mangle","Maul","Pounce","Pulverize","Rake","Ravage","Rip","Shred","Swipe","Thrash","Counterattack","Raptor Strike","Wing Clip","Arcane Explosion","Dragon's Breath","Molten Armor","Cone of Cold","Frost Nova","Consecration","Holy Wrath","Hammer of Justice","Hammer of the Righteous","Crusader Strike","Divine Storm","Rebuke","Templar's Verdict","Psychic Scream","Ambush","Cheap Shot","Dismantle","Envenom","Eviscerate","Expose Armor","Garrote","Kidney Shot","Mutilate","Rupture","Backstab","Blade Twisting","Fan of Knives","Gouge","Kick","Revealing Strike","Shiv","Sinister Strike","Hemorrhage","Sap","Thunderstorm","Flametongue Weapon","Lava Lash","Lightning Shield","Primal Strike","Stormstrike","Howl of Terror","Hellfire","Shadowflame","Collosus Smash","Hamstring","Heroic Strike","Mortal Strike","Overpower","Rend","Throwdown","Thunder Clap","Bloodthirst","Cleave","Execute","Intimidating Shout","Piercing Howl","Raging Blow","Slam","Victory Rush","Whirlwind","Concussion Blow","Devastate","Disarm","Revenge","Shield Bash","Shield Slam","Shockwave"}          

local rangedPlayerAbilities = {"Dark Command","Dark Simulacrum","Strangulate","Chains of Ice","Howling Blast","Death Coil","Death Grip","Death and Decay","Outbreak","Summon Gargoyle","Cyclone","Entangling Roots","Faerie Fire","Hibernate","Hurricane","Insect Swarm","Moonfire","Solar Beam","Soothe","Starfall","Starfire","Starsurge","Sunfire","Typhoon","Wrath","Faerie Fire (Cat)","Faerie Fire (Feral)","Feral Charge","Skull Bash","Scare Beast","Scorpid Venom","Viper Venom","Widow Venom","Aimed Shot","Arcane Shot","Chimera Shot","Concussive Shot","Distracting Shot","Multi-Shot","Silencing Shot","Steady Shot","Tranquilizing Shot","Volley","Wild Quiver Auto Shot","Black Arrow","Cobra Shot","Explosive Shot","Explosive Trap","Freezing Trap","Ice Trap","Immolation Trap","Scatter Shot","Serpent Sting","Snake Trap","Wyvern Sting","Arcane Barrage","Arcane Blast","Arcane Missiles","Counterspell","Polymorph","Slow","Spellsteal","Blast Wave","Combustion","Fire Blast","Fireball","Flame Orb","Flamestrike","Frostfire Bolt","Living Bomb","Pyroblast","Scorch","Blizzard","Deep Freeze","Frostbolt","Frostfire Orb","Ice Lance","Exorcism","Avenger's Shield","Hammer of Wrath","Repentance","Mana Burn","Penance","Devouring Plague","Mind Blast","Mind Control","Mind Flay","Mind Seer","Mind Spike","Psychic Horror","Shadow Word: Death","Shadow Word: Pain","Shadowfiend","Silence","Vampiric Touch","Deadly Throw","Vendetta","Blind","Shadowstep","Chain Lightning","Earth Shock","Earthquake","Fire Nova","Flame Shock","Frost Shock","Hex","Lava Burst","Lightning Bolt","Purge","Wind Shear","Bane of Agony","Bane of Doom","Corruption","Curse of Exhaustion","Curse of Tongues","Curse of Weakness","Curse of Elements","Death Coil","Drain Life","Drain Mana","Drain Soul","Fear","Haunt","Seed of Corruption","Unstable Affliction","Hand of Gul'dan","Immolation","Bane of Havoc","Burning Embers","Chaos Bolt","Conflagrate","Fel Flame","Immolate","Incinerate","Rain of Fire","Searing Pain","Shadow Bolt","Shadowburn","Shadowfury","Soul Fire","Charge","Heroic Throw","Shattering Throw","Heroic Leap","Intercept"}    

local alwaysWarnAbilities= {"Stealth","Vanish","Prowl","Invisibility"}
--print(WorldMapDetailFrame:GetRect())
--print(WorldMapDetailFrame:GetTop())
--print(WorldMapDetailFrame:GetRight())


framelist = {}
for i=1,200 do
	table.insert(framelist, CreateFrame("Frame"))
	local veryVeryTempFrame = framelist[i]
	veryVeryTempFrame:SetFrameStrata("FULLSCREEN")
	veryVeryTempFrame:SetWidth(5)
	veryVeryTempFrame:SetHeight(5)
	veryVeryTempFrame:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
	veryVeryTempFrame:SetBackdropColor(.8,0,0,1)
end


local WarningFrames = CreateFrame("Frame")
WarningFrames:SetFrameStrata("LOW")
WarningFrames:SetWidth(400)
WarningFrames:SetHeight(25)
WarningFrames.Title=WarningFrames:CreateFontString(nil,"OVERLAY","SystemFont_Huge1")
WarningFrames.Title:SetText("")
WarningFrames.Title:SetPoint("TOP",WarningFrames,"TOP",0,0)
WarningFrames:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0}})
WarningFrames:SetBackdropColor(0,0,0,0)
WarningFrames:SetPoint("CENTER",0,0)

WarningFrames:Show()

local playerSetSpellName = "Attack"
local warningPlayerName = ""

SLASH_SETSPELL1 = "/SetSpell"
SlashCmdList["SETSPELL"] = function(spellName)
	playerSetSpellName=spellName
end

--WarningFrameButton = CreateFrame("Button","myButton1", UIParent, "SecureActionButtonTemplate")
--WarningFrameButton:RegisterForClicks("LeftButtonDown")

--WarningFrameButton:SetWidth(400)
--WarningFrameButton:SetHeight(25)
--WarningFrameButton:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0}})
--WarningFrameButton:SetFrameStrata("MEDIUM")
--WarningFrameButton:SetPoint("LEFT",WarningFrames,"LEFT",0,0)
--WarningFrameButton.Body=WarningFrameButton:CreateFontString(nil,"OVERLAY","SystemFont_Huge1")
--WarningFrameButton.Body:SetText("")
--WarningFrameButton.Body:SetPoint("LEFT",WarningFrameButton,"LEFT",0,0)
--local warningFrameText = WarningFrameButton.Body:GetText()
--WarningFrameButton:SetAttribute("type1", "macro")
--WarningFrameButton:SetAttribute("macrotext","/target "..warningPlayerName.." /cast "..playerSetSpellName)
--WarningFrameButton:SetBackdropColor(1,1,1,0)
--WarningFrameButton:Disable()
--WarningFrameButton:Show()



local MouseOverFrame = CreateFrame("Frame")
MouseOverFrame:SetFrameStrata("MEDIUM")
MouseOverFrame:SetWidth(70)
MouseOverFrame:SetHeight(15)
MouseOverFrame:SetMovable(true)
MouseOverFrame:EnableMouse(true)
MouseOverFrame:RegisterForDrag("LeftButton")
MouseOverFrame:SetScript("OnDragStart", MouseOverFrame.StartMoving)
MouseOverFrame:SetScript("OnDragStop", MouseOverFrame.StopMovingOrSizing)
MouseOverFrame.Title1=MouseOverFrame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
MouseOverFrame.Title1:SetText("|cFFFFFFFFMouse Info")
MouseOverFrame.Title1:SetPoint("TOP",MouseOverFrame,"TOP",0,-2)
MouseOverFrame.Title=MouseOverFrame:CreateFontString(nil,"OVERLAY","SystemFont_Large")
MouseOverFrame.Title:SetText("")
MouseOverFrame.Title:SetPoint("TOP",MouseOverFrame,"TOP",0,-16)
MouseOverFrame:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0}})
MouseOverFrame:SetBackdropColor(0,0,0,1)
MouseOverFrame:SetPoint("TOP",0,-100)
MouseOverFrame:Show()


local TargetFrame = CreateFrame("Frame")
TargetFrame:SetFrameStrata("MEDIUM")
TargetFrame:SetWidth(70)
TargetFrame:SetHeight(15)
TargetFrame:SetMovable(true)
TargetFrame:EnableMouse(true)
TargetFrame:RegisterForDrag("LeftButton")
TargetFrame:SetScript("OnDragStart", TargetFrame.StartMoving)
TargetFrame:SetScript("OnDragStop", TargetFrame.StopMovingOrSizing)
TargetFrame.Title1=TargetFrame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
TargetFrame.Title1:SetText("|cFFFFFFFFTarget Info")
TargetFrame.Title1:SetPoint("TOP",TargetFrame,"TOP",0,-2)
TargetFrame.Title=TargetFrame:CreateFontString(nil,"OVERLAY","SystemFont_Large")
TargetFrame.Title:SetText("")
TargetFrame.Title:SetPoint("TOP",TargetFrame,"TOP",0,-16)
TargetFrame:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0}})
TargetFrame:SetBackdropColor(0,0,0,1)

TargetFrame:Show()

local warningPlayerName2a = ""
local warningPlayerName2b = ""
local warningPlayerName2c = ""
local warningPlayerName2d = ""
local warningPlayerName2e = ""
local warningPlayerName2f = ""
local warningPlayerName2g = ""

local tempframe = CreateFrame("Frame")
tempframe:SetFrameStrata("LOW")
tempframe:SetWidth(225)
tempframe:SetHeight(105)
tempframe:SetMovable(true)
tempframe:EnableMouse(true)
tempframe:RegisterForDrag("LeftButton")
tempframe:SetScript("OnDragStart", tempframe.StartMoving)
tempframe:SetScript("OnDragStop", tempframe.StopMovingOrSizing)

tempframeButton1 = CreateFrame("Button","myButton", UIParent, "SecureActionButtonTemplate")
tempframeButton1:RegisterForClicks("LeftButtonDown")
tempframeButton1:SetWidth(225)
tempframeButton1:SetHeight(13)
tempframeButton1:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempframeButton1:SetFrameStrata("MEDIUM")
tempframeButton1:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-13)
tempframeButton1:SetAttribute("type1", "macro")
tempframeButton1:SetAttribute("macrotext","/target "..warningPlayerName2a)
tempframeButton1:SetBackdropColor(1,1,1,0)
tempframeButton1:Disable()
tempframeButton1:Show()

tempframeButton2 = CreateFrame("Button","myButton", UIParent, "SecureActionButtonTemplate")
tempframeButton2:RegisterForClicks("LeftButtonDown")
tempframeButton2:SetWidth(225)
tempframeButton2:SetHeight(13)
tempframeButton2:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempframeButton2:SetFrameStrata("MEDIUM")
tempframeButton2:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-26)
tempframeButton2:SetAttribute("type1", "macro")
tempframeButton2:SetAttribute("macrotext","/target "..warningPlayerName2b)
tempframeButton2:SetBackdropColor(1,0,0,0)
tempframeButton2:Disable()
tempframeButton2:Show()

tempframeButton3 = CreateFrame("Button","myButton", UIParent, "SecureActionButtonTemplate")
tempframeButton3:RegisterForClicks("LeftButtonDown")
tempframeButton3:SetWidth(225)
tempframeButton3:SetHeight(13)
tempframeButton3:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempframeButton3:SetFrameStrata("MEDIUM")
tempframeButton3:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-39)
tempframeButton3:SetAttribute("type1", "macro")
tempframeButton3:SetAttribute("macrotext","/target "..warningPlayerName2c)
tempframeButton3:SetBackdropColor(1,0,0,0)
tempframeButton3:Disable()
tempframeButton3:Show()

tempframeButton4 = CreateFrame("Button","myButton", UIParent, "SecureActionButtonTemplate")
tempframeButton4:RegisterForClicks("LeftButtonDown")
tempframeButton4:SetWidth(225)
tempframeButton4:SetHeight(13)
tempframeButton4:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempframeButton4:SetFrameStrata("MEDIUM")
tempframeButton4:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-52)
tempframeButton4:SetAttribute("type1", "macro")
tempframeButton4:SetAttribute("macrotext","/target "..warningPlayerName2d)
tempframeButton4:SetBackdropColor(1,0,0,0)
tempframeButton4:Disable()
tempframeButton4:Show()

tempframeButton5 = CreateFrame("Button","myButton", UIParent, "SecureActionButtonTemplate")
tempframeButton5:RegisterForClicks("LeftButtonDown")
tempframeButton5:SetWidth(225)
tempframeButton5:SetHeight(13)
tempframeButton5:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempframeButton5:SetFrameStrata("MEDIUM")
tempframeButton5:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-65)
tempframeButton5:SetAttribute("type1", "macro")
tempframeButton5:SetAttribute("macrotext","/target "..warningPlayerName2e)
tempframeButton5:SetBackdropColor(1,0,0,0)
tempframeButton5:Disable()
tempframeButton5:Show()

tempframeButton6 = CreateFrame("Button","myButton", UIParent, "SecureActionButtonTemplate")
tempframeButton6:RegisterForClicks("LeftButtonDown")
tempframeButton6:SetWidth(225)
tempframeButton6:SetHeight(13)
tempframeButton6:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempframeButton6:SetFrameStrata("MEDIUM")
tempframeButton6:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-78)
tempframeButton6:SetAttribute("type1", "macro")
tempframeButton6:SetAttribute("macrotext","/target "..warningPlayerName2f)
tempframeButton6:SetBackdropColor(1,0,0,0)
tempframeButton6:Disable()
tempframeButton6:Show()

tempframeButton7 = CreateFrame("Button","myButton", UIParent, "SecureActionButtonTemplate")
tempframeButton7:RegisterForClicks("LeftButtonDown")
tempframeButton7:SetWidth(225)
tempframeButton7:SetHeight(13)
tempframeButton7:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempframeButton7:SetFrameStrata("MEDIUM")
tempframeButton7:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-91)
tempframeButton7:SetAttribute("type1", "macro")
tempframeButton7:SetAttribute("macrotext","/target "..warningPlayerName2g)
tempframeButton7:SetBackdropColor(1,0,0,0)
tempframeButton7:Disable()
tempframeButton7:Show()

tempframe:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempframe:SetBackdropColor(.2,.2,.2,.1)
tempframe:SetPoint("LEFT",40,-10)
--tempframe.Title=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
--tempframe.Title:SetText("|cFFFFFF00Nearby Enemies")
--tempframe.Title:SetPoint("TOP",tempframe,"TOP",0,-2)
tempframe.Body1=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body1:SetText("")
tempframe.Body1:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-13)
tempframe.Body1a=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body1a:SetText("")
tempframe.Body1a:SetPoint("TOPLEFT",tempframe,"TOPLEFT",69,-13)
tempframe.Body1b=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body1b:SetText("")
tempframe.Body1b:SetPoint("TOPLEFT",tempframe,"TOPLEFT",140,-13)
tempframe.Body2=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body2:SetText("")
tempframe.Body2:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-26)
tempframe.Body2a=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body2a:SetText("")
tempframe.Body2a:SetPoint("TOPLEFT",tempframe,"TOPLEFT",69,-26)
tempframe.Body2b=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body2b:SetText("")
tempframe.Body2b:SetPoint("TOPLEFT",tempframe,"TOPLEFT",140,-26)
tempframe.Body3=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body3:SetText("")
tempframe.Body3:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-39)
tempframe.Body3a=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body3a:SetText("")
tempframe.Body3a:SetPoint("TOPLEFT",tempframe,"TOPLEFT",69,-39)
tempframe.Body3b=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body3b:SetText("")
tempframe.Body3b:SetPoint("TOPLEFT",tempframe,"TOPLEFT",140,-39)

tempframe.Body4=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body4:SetText("")
tempframe.Body4:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-52)
tempframe.Body4a=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body4a:SetText("")
tempframe.Body4a:SetPoint("TOPLEFT",tempframe,"TOPLEFT",69,-52)
tempframe.Body4b=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body4b:SetText("")
tempframe.Body4b:SetPoint("TOPLEFT",tempframe,"TOPLEFT",140,-52)

tempframe.Body5=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body5:SetText("")
tempframe.Body5:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-65)
tempframe.Body5a=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body5a:SetText("")
tempframe.Body5a:SetPoint("TOPLEFT",tempframe,"TOPLEFT",69,-65)
tempframe.Body5b=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body5b:SetText("")
tempframe.Body5b:SetPoint("TOPLEFT",tempframe,"TOPLEFT",140,-65)

tempframe.Body6=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body6:SetText("")
tempframe.Body6:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-78)
tempframe.Body6a=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body6a:SetText("")
tempframe.Body6a:SetPoint("TOPLEFT",tempframe,"TOPLEFT",69,-78)
tempframe.Body6b=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body6b:SetText("")
tempframe.Body6b:SetPoint("TOPLEFT",tempframe,"TOPLEFT",140,-78)

tempframe.Body7=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body7:SetText("")
tempframe.Body7:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-91)
tempframe.Body7a=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body7a:SetText("")
tempframe.Body7a:SetPoint("TOPLEFT",tempframe,"TOPLEFT",69,-91)
tempframe.Body7b=tempframe:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempframe.Body7b:SetText("")
tempframe.Body7b:SetPoint("TOPLEFT",tempframe,"TOPLEFT",140,-91)

local function HideNearby()
	tempFrameTitle:Hide()
	tempFrameTitle.Title:Hide()
	tempFrameTitle2.Title:Hide()
	tempFrameTitle2:Hide()
	tempframe:Hide()
	tempframe.Body1:Hide()
	tempframe.Body1a:Hide()
	tempframe.Body1b:Hide()
	tempframe.Body2:Hide()
	tempframe.Body2a:Hide()
	tempframe.Body2b:Hide()
	tempframe.Body3:Hide()
	tempframe.Body3a:Hide()
	tempframe.Body3b:Hide()
	tempframe.Body4:Hide()
	tempframe.Body4a:Hide()
	tempframe.Body4b:Hide()
	tempframe.Body5:Hide()
	tempframe.Body5a:Hide()
	tempframe.Body5b:Hide()
	tempframe.Body6:Hide()
	tempframe.Body6a:Hide()
	tempframe.Body6b:Hide()
	tempframe.Body7:Hide()
	tempframe.Body7a:Hide()
	tempframe.Body7b:Hide()
	tempFrameButton:Hide()
end	

tempFrameButton = CreateFrame("Button")
tempFrameButton:RegisterForClicks("LeftButtonDown")
tempFrameButton:SetScript("OnClick",HideNearby)
tempFrameButton:SetWidth(6)
tempFrameButton:SetHeight(6)
tempFrameButton:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempFrameButton:SetFrameStrata("MEDIUM")
tempFrameButton:SetPoint("TOPRIGHT",tempframe,"TOPRIGHT",0,0)
tempFrameButton.Body=tempFrameButton:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempFrameButton.Body:SetText("|cFFFFFFFFx")
tempFrameButton.Body:SetPoint("TOP",tempFrameButton,"TOP",0,3)

tempFrameButton:SetBackdropColor(1,1,1,1)

tempFrameButton:Show()

tempFrameTitle = CreateFrame("Frame")
tempFrameTitle:SetWidth(225)
tempFrameTitle:SetHeight(15)
tempFrameTitle.Title=tempFrameTitle:CreateFontString(nil,"OVERLAY","SystemFont_Small")
tempFrameTitle:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempFrameTitle:SetFrameStrata("LOW")
--tempFrameTitle:SetBackdropColor(0,0,1,0)
--tempFrameTitle.Title:SetText("|cFFFFFFFFPlayer Name")
tempFrameTitle.Title:SetPoint("TOPLEFT",tempFrameTitle,"TOPLEFT",0,0)
--tempFrameTitle:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,-13)
tempframe:SetResizable(true)
tempframe:SetMaxResize(500,500)
tempFrameTitle:Show()
tempframe:Show()
tempFrameTitle2 = CreateFrame("Frame")

tempFrameTitle2:SetWidth(225)
tempFrameTitle2:SetHeight(13)
tempFrameTitle2.Title=tempFrameTitle:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
tempFrameTitle2:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
tempFrameTitle2:SetFrameStrata("LOW")
tempFrameTitle2:SetBackdropColor(0,0,0,1)
tempFrameTitle2.Title:SetText("|cFFFFFFFF       Player      ||      Spec       ||   Gear Rating  ")
tempFrameTitle2.Title:SetPoint("TOPLEFT",tempFrameTitle2,"TOPLEFT",0,-1.5)
tempFrameTitle2:SetPoint("TOPLEFT",tempframe,"TOPLEFT",0,0)
tempFrameTitle2:Show()

TargetFrame:Hide()
TargetFrame.Title:Hide()
TargetFrame.Title1:Hide()

SLASH_MOVEFRAME_ON1 = "/AllyInfoOn"
SlashCmdList["MOVEFRAME_ON"] = function()
	AlliedMouseoverEnabled = 1
end

SLASH_UWORLDPVP_RESET1 = "/UWORLDPVPRESETALL"
SlashCmdList["UWORLDPVP_RESET"] = function()
	playerList = {{"Feather of Lead?","0","100",.75,.75,"Somewhere",0,"Unknown",0,"Unknown"}}
	targetInfo= nil
	targetInfo1= nil
	targetInfo2= nil
	mouseoverInfo=nil
	mouseoverInfo1=nil
	mouseoverInfo2=nil
	NearbyEnemyPosition=nil
	NearbyEnemyPosition1=nil
	NearbyEnemyPosition2=nil
end

SLASH_MOVEFRAME_OFF1 = "/AllyInfoOff"
SlashCmdList["MOVEFRAME_OFF"] = function()
	AlliedMouseoverEnabled = 0
end

SLASH_TARGET_HIDE1 = "/targethide"
SlashCmdList["TARGET_HIDE"] = function()
	TargetFrame:Hide()
	TargetFrame.Title:Hide()
	TargetFrame.Title1:Hide()
end

SLASH_TARGET_SHOW1 = "/targetshow"
SlashCmdList["TARGET_SHOW"] = function()
	TargetFrame:Show()
	TargetFrame.Title:Show()
	TargetFrame.Title1:Show()
end

SLASH_MOUSEOVER_HIDE1 = "/mousehide"
SlashCmdList["MOUSEOVER_HIDE"] = function()
	MouseOverFrame:Hide()
	MouseOverFrame.Title:Hide()
	MouseOverFrame.Title1:Hide()
end

SLASH_MOUSEOVER_SHOW1 = "/mouseshow"
SlashCmdList["MOUSEOVER_SHOW"] = function()
	MouseOverFrame:Show()
	MouseOverFrame.Title:Show()
	MouseOverFrame.Title1:Show()
end

SLASH_NEARBYENEMY_SHOW1 = "/UWshow"
SlashCmdList["NEARBYENEMY_SHOW"] = function()
	tempFrameTitle:Show()
	tempFrameTitle.Title:Show()
	tempFrameTitle2.Title:Show()
	tempFrameTitle2:Show()
	tempframe:Show()
	tempframe.Body1:Show()
	tempframe.Body1a:Show()
	tempframe.Body1b:Show()
	tempframe.Body2:Show()
	tempframe.Body2a:Show()
	tempframe.Body2b:Show()
	tempframe.Body3:Show()
	tempframe.Body3a:Show()
	tempframe.Body3b:Show()
	tempframe.Body4:Show()
	tempframe.Body4a:Show()
	tempframe.Body4b:Show()
	tempframe.Body5:Show()
	tempframe.Body5a:Show()
	tempframe.Body5b:Show()
	tempframe.Body6:Show()
	tempframe.Body6a:Show()
	tempframe.Body6b:Show()
	tempframe.Body7:Show()
	tempframe.Body7a:Show()
	tempframe.Body7b:Show()
	tempFrameButton:Show()
end

SLASH_NEARBYENEMY_HIDE1 = "/UWhide"
SlashCmdList["NEARBYENEMY_HIDE"] = function()
	tempFrameTitle:Hide()
	tempFrameTitle.Title:Hide()
	tempFrameTitle2.Title:Hide()
	tempFrameTitle2:Hide()
	tempframe:Hide()
	tempframe.Body1:Hide()
	tempframe.Body1a:Hide()
	tempframe.Body1b:Hide()
	tempframe.Body2:Hide()
	tempframe.Body2a:Hide()
	tempframe.Body2b:Hide()
	tempframe.Body3:Hide()
	tempframe.Body3a:Hide()
	tempframe.Body3b:Hide()
	tempframe.Body4:Hide()
	tempframe.Body4a:Hide()
	tempframe.Body4b:Hide()
	tempframe.Body5:Hide()
	tempframe.Body5a:Hide()
	tempframe.Body5b:Hide()
	tempframe.Body6:Hide()
	tempframe.Body6a:Hide()
	tempframe.Body6b:Hide()
	tempframe.Body7:Hide()
	tempframe.Body7a:Hide()
	tempframe.Body7b:Hide()
	tempFrameButton:Hide()
end

SLASH_UWORLDPVP1 = "/UWorldPvP"
SlashCmdList["UWORLDPVP"] = function()
	DEFAULT_CHAT_FRAME:AddMessage("UWorldPvP Help",.2,1,.2)
	DEFAULT_CHAT_FRAME:AddMessage("/AllyInfoOn or /AllyInfoOff -- Turns on and off mousover and target info display of allied players.",.4,.6,.4)
	DEFAULT_CHAT_FRAME:AddMessage("/SavePlayerlistOn or /SavePlayerlistOff -- Determines whether or not it saves the player database between sessions. This dramatically increases memory usage as data is stored on more and more players.",.4,.6,.4)
	DEFAULT_CHAT_FRAME:AddMessage("/enemyadd (name) -- Displays the enemy's last known zone and makes it so their name appears next to their marker on your map.",.4,.6,.4)
	DEFAULT_CHAT_FRAME:AddMessage("/enemylist -- Checks the database for the last known location of every player on your enemy list.",.4,.6,.4)
	DEFAULT_CHAT_FRAME:AddMessage("/enemyremove (name) -- Remove a player from your enemy list.",.4,.6,.4)
	DEFAULT_CHAT_FRAME:AddMessage("/targetshow or /targethide -- Shows or hides the Target Info window.",.4,.6,.4)
	DEFAULT_CHAT_FRAME:AddMessage("/mouseshow or /mousehide -- Shows or hides the Mouse Info window.",.4,.6,.4)
	DEFAULT_CHAT_FRAME:AddMessage("/UWshow or /UWhide -- Shows or hides the Mouse Info window.",.4,.6,.4)
--	DEFAULT_CHAT_FRAME:AddMessage("/SetSpell (spell name) -- Setup a spell to cast when clicking on the warning or nearby enemy frame to target that player.",.4,.6,.4)

end


local function tableSearch(tableInput,pattern)
	local foundPattern = "false"
	for i=1, # tableInput do
		
		if tableInput[i] == pattern and foundPattern == "false" then
			foundPattern = "true"
			return i
		end
	end
	
	if foundPattern == "false" then
		return nil
	end
end

local function deepTableSearch(tableInput,pattern,sublevelSlot)
	local foundPattern = "false"
	for i=1, # tableInput do
		tempTableInput = tableInput[i]
		if tempTableInput[sublevelSlot] == pattern and foundPattern == "false" then
			foundPattern = "true"
			return i
		end
	end
	
	if foundPattern == "false" then
		return nil
	end
end

local function tableSearch2(tableInput,pattern)
	local foundPatternReturns = {}
	for i=1, # tableInput do
		if tableInput[i] == pattern then
			table.insert(foundPatternReturns,tableInput[i])
		end
	end
	return foundPatternReturns
end

local function deepTableSearch2(tableInput,pattern,sublevelSlot)
	local foundPatternReturns = {}
	for i=1, # tableInput do
		local tempTableInput = tableInput[i]
		if tempTableInput[sublevelSlot] == pattern then
			table.insert(foundPatternReturns,tempTableInput)
		end
	end
	return foundPatternReturns
end

local tempEnemyName = ""
SLASH_ENEMY_ADD1 = "/enemyadd"
SlashCmdList["ENEMY_ADD"] = function(tempEnemyName)
	
	if tableSearch(enemyList,tempEnemyName) == nil then
		table.insert(enemyList,tempEnemyName)
	end
	
	if deepTableSearch(playerList,tempEnemyName,1) ~= nil then
		local tempEnemyPlayerPosition = deepTableSearch(playerList,tempEnemyName,1)
		local tempEnemyPlayerEntry = playerList[tempEnemyPlayerPosition]
		print(tempEnemyPlayerEntry[1].." was last seen in "..tempEnemyPlayerEntry[6])
	else
		print(tempEnemyName.." has not been seen since you logged in.")
	end
end

SLASH_ENEMY_REMOVE1 = "/enemyremove"
SlashCmdList["ENEMY_REMOVE"] = function(tempEnemyName)
	
	if tableSearch(enemyList,tempEnemyName) == nil then
		print(tempEnemyName.." is not in your enemy list.")
	else
		local temporaryPosition = table.search(enemyList,tempEnemyName)
		table.remove(enemyList,temporaryPosition)
		print(tempEnemyName.." has been successfully removed from your enemy list.")
	end

end

SLASH_ENEMY_LIST1 = "/enemylist"
SlashCmdList["ENEMY_LIST"] = function()
	for i=1, # enemyList do
		local temporaryEnemyName = enemyList[i]
		if deepTableSearch(playerList,tempEnemyName,1) ~= nil then
			local tempEnemyPlayerPosition = deepTableSearch(playerList,temporaryEnemyName,1)
			local tempEnemyPlayerEntry = playerList[tempEnemyPlayerPosition]
			print(tempEnemyPlayerEntry[1].." was last seen in "..tempEnemyPlayerEntry[6])
		else
			print(temporaryEnemyName.." has not been seen since you logged in.")
		end
	end
end

SLASH_SAVEPLAYERLIST_ON1 = "/savePlayerListOn"
SlashCmdList["SAVEPLAYERLIST_ON"] = function()
	savePlayerList = true
end

SLASH_PVPTEST1 = "/pvptest"
SlashCmdList["PVPTEST"] = function()
	local mapFileName, textureHeight, textureWidth = GetMapInfo()
	print(mapFileName)
	print( # focusmanager)
end


SLASH_SAVEPLAYERLIST_OFF1 = "/savePlayerListOff"
SlashCmdList["SAVEPLAYERLIST_OFF"] = function()
	savePlayerList = false
end
	
local theFuck
lastTimeStamp = 0
checkAvailTime = 0
warningFrameTime = 0
lastInspectTime = GetTime()
local startTime = GetTime()
local CombatWarningPlayers = {}
local CombatState = 0
local numWhos, totalCount
local hasTarget = 0
weekday, month, day, year = CalendarGetDate()



 

local function onEvent(self,event,...)
	local timestamp, type1, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, channelName, spellName, spellSchool = select(1, ...)
	local killCount = "0"
	local enemyPlayerRange = "100"
	mapFileName, textureHeight, textureWidth = GetMapInfo()
	local playerClass = "none"
	tempHour,tempMinute = GetGameTime()
	local playerX,playerY = GetPlayerMapPosition("player")
	local mouseoverSpec = "Unknown"
	
	if event == "ADDON_LOADED" and timestamp == "UWorldPvP" then
		theFuck = 0
		if playerList == nil then
			playerList = {{"Feather of Lead?","0","100",.75,.75,"Somewhere",0,"Unknown",0,"Unknown"}}
			
		end
		if enemyList == nil then
			enemyList = {}
		end
		if savePlayerList == nil then
			savePlayerList = false
		end
	end
	
	
	
	if tempHour..tempMinute ~= LastMinute then
		if tempHour<10 then
			tempHour = "0"..tempHour
		end
		
		if tempMinute<10 then
			tempMinute = "0"..tempMinute
		end
		
		if tonumber(day)<10 then
			day = "0"..day
		end
		
		if tonumber(month)<10 then
			month = "0"..month
		end
		
		LastMinute = year..month..day..tempHour..tempMinute
		if (GetTime() - StartOfMinSeconds) < 60 then
			StartOfMinSeconds = GetTime()
		else
			while (GetTime() - StartOfMinSeconds) >= 60 do
				StartOfMinSeconds = StartOfMinSeconds + 60
			end
		end
	end
	
	
	
	if (GetTime()-StartOfMinSeconds) < 10 then
		currentTime = LastMinute.."0"..(GetTime()-StartOfMinSeconds)
	else
		currentTime = LastMinute..(GetTime()-StartOfMinSeconds)
	end
	
	
	id1, name1, id2, name2, id3, name3, id4, name4, id5, name5, id6, name6, id7, name7, id8, name8, id9, name9, id10, name10, id11, name11, id12, name12, id13, name13 = GetChannelList()
	ChannelTable = {id1, name1, id2, name2, id3, name3, id4, name4, id5, name5, id6, name6, id7, name7, id8, name8, id9, name9, id10, name10, id11, name11, id12, name12, id13, name13}
	
	if theFuck == 0 and tableSearch(ChannelTable,"General") ~= nil and startTime+5<GetTime() then
		if UnitFactionGroup("player") == "Alliance" then
			JoinChannelByName("UWorldPvPAlliance")
			playerLanguage = "Common"
			theFuck = 1
		else
			JoinChannelByName("UWorldPvPHorde")
			playerLanguage = "Orcish"
			theFuck = 1
		end		
	end
	
	if UnitFactionGroup("player") == "Alliance" then
		tempVariableChannel = tableSearch(ChannelTable,"UWorldPvPAlliance")
	else
		tempVariableChannel = tableSearch(ChannelTable,"UWorldPvPHorde")
	end
	
	if tempVariableChannel ~= nil then
		UWorldPvPChannel = ChannelTable[tempVariableChannel-1]
	end
	

	
	if event == "CHAT_MSG_SYSTEM" and string.sub(timestamp,1,17) == "No player named '" then
		local tempPlayerName = string.sub(timestamp,18,string.find(timestamp,"' is currently playing." )-1)
		playerX, playerY = GetPlayerMapPosition("player")
		if deepTableSearch(playerList,tempPlayerName,1)~=nil then
			
			local locationInPlayerList = deepTableSearch(playerList,tempPlayerName,1)
			local playerEntry = playerList[locationInPlayerList]
			if tonumber(playerEntry[2]) > tonumber(currentTime) then
				
				if tonumber(playerEntry[2]) < tonumber(currentTime) then
					killCount = playerEntry[7]
					local spec = playerEntry[8]
					local gearRating = playerEntry[9]
					local playerClass2
					if playerEntry[10] ~= nil then
						playerClass2 = playerEntry[10]
					else
						playerClass2 ="none"
					end
					percentPvP = playerEntry[11]
					playerList[locationInPlayerlist] = {tempPlayerName,currentTime,enemyPlayerRange,playerX,playerY,mapFileName,killCount,spec,gearRating,playerClass2,percentPvP}
					if tableSearch(BattlegroundMapNames,mapFileName) == nil then
						SendChatMessage(sourceName.."_"..currentTime.."-"..enemyPlayerRange.."+"..playerX.."="..playerY.."#"..mapFileName.."!"..killCount.."@"..spec.."$"..gearRating.."&"..playerClass2..percentPvP,"CHANNEL",playerLanguage,UWorldPvPChannel)
						
					end
				
					if deepTableSearch(focusmanager,tempPlayerName,1) == nil then
						table.insert(focusmanager,{tempPlayerName,currentTime,killCount,playerClass,spec,gearRating})
					else
						local focusLocation = deepTableSearch(focusmanager,tempPlayerName,1)
						local focusEntry = focusmanager[focusLocation]
						focusEntry[2]=currentTime
						focusEntry[5]=spec
						focusEntry[6]=gearRating
						focusmanager[focusLocation]=focusEntry
					end
				end
			end
		else
			
			if tableSearch(BattlegroundMapNames,mapFileName) == nil then
				SendChatMessage(tempPlayerName.."_"..currentTime.."-"..enemyPlayerRange.."+"..playerX.."="..playerY.."#"..mapFileName.."!"..killCount.."@".."none".."$".."Unknown".."&".."Unknown".."^".."-1% PvP","CHANNEL",playerLanguage,UWorldPvPChannel)
				table.insert(playerList,{tempPlayerName,currentTime,enemyPlayerRange,playerX,playerY,mapFileName,killCount,spec,gearRating,playerClass2,"0% PvP"})
			else
				for i=1, # bgPlayers do
					SendAddonMessage("UWorldPvPDATA",tempPlayerName.."_"..currentTime.."-"..enemyPlayerRange.."+"..playerX.."="..playerY.."#"..mapFileName.."!"..killCount.."@".."none".."$".."Unknown".."&".."Unknown".."^".."-1% PvP","WHISPER",bgPlayers[i])
				end
			end
			if deepTableSearch(focusmanager,tempPlayerName,1) == nil then
				table.insert(focusmanager,{tempPlayerName,currentTime,killCount,"none","Unknown",0})
			end
			
		end
	end	
	
	if event == "PLAYER_REGEN_DISABLED" then
		CombatState = 1
		
	
	elseif event == "PLAYER_REGEN_ENABLED" then
		CombatState = 0
		CombatWarningPlayers = {}
	end
	
	if type(warningFrameTime) == "number" then
		if (GetTime() - 2.5) > warningFrameTime then
			WarningFrames.Title:SetText("")
			
			--WarningFrameButton:Disable()
			warningFrameTime = "Feathers or Lead?"
		end
	end
	
	if GetUnitName("mouseover") == nil or UnitFactionGroup("mouseover") == nil then
		MouseOverFrame.Title:SetText("")
	end
	
	if GetUnitName("target") == nil or UnitFactionGroup("target") == nil then
		TargetFrame.Title:SetText("")
		hasTarget = 0
	end
	
	if event == "COMBAT_LOG_EVENT_UNFILTERED" and string.sub(type1,1,18)=="SPELL_CAST_SUCCESS" and destName == GetUnitName("player") and sourceName ~= GetUnitName("focus") and UnitInParty(sourceName) == nil and UnitInRaid(sourceName)==nil and UnitInBattleground(sourceName) == nil and (tableSearch(rangedPlayerAbilities,spellName) ~= nil or tableSearch(meleePlayerAbilities,spellName) ~= nil) then
		
		if tableSearch(CombatWarningPlayers, sourceName) == nil then
			table.insert(CombatWarningPlayers,sourceName)
			if sourceName ~= GetUnitName("player") and sourceName ~= GetUnitName("target") then
				WarningFrames.Title:SetText("|cFFFFFFFFA nearby enemy named "..sourceName.." just cast "..spellName..".")
				warningPlayerName = sourceName
				
				--WarningFrameButton:Enable()
				warningFrameTime = GetTime()
			end
		end
		
		
	end
	
	if event == "COMBAT_LOG_EVENT_UNFILTERED" and tableSearch(allEnemySpecSkills,spellName) ~= nil and deepTableSearch(playerList,sourceName,1)~=nil then
		
		local enemySpec
		local enemyLocation = deepTableSearch(playerList,sourceName,1)
		local enemyEntry = playerList[enemyLocation]
		for i=1, # allEnemySpecs do
			local tempSpecTable = allEnemySpecs[i]
			if tableSearch(tempSpecTable,spellName)~=nil and enemySpec == nil then
				enemySpec=tempSpecTable[1]
				
			end
		end
		if enemySpec~=enemyEntry[8] and enemySpec ~= nil and enemySpec~= "Unknown" then
			enemyEntry[8]=enemySpec
			playerList[enemyLocation]=enemyEntry
			if deepTableSearch(focusmanager,tempPlayerName,1) ~= nil then
				local focusLocation = deepTableSearch(focusmanager,tempPlayerName,1)
				local focusEntry = focusmanager[focusLocation]
			
				focusEntry[5]=enemySpec
			
				focusmanager[focusLocation]=focusEntry
			end
		end
	end
	
	if event == "COMBAT_LOG_EVENT_UNFILTERED" and string.sub(type1,1,18)=="SPELL_CAST_SUCCESS" and tableSearch(alwaysWarnAbilities,spellName) ~= nil and sourceName ~= GetUnitName("player") and deepTableSearch(playerList,sourceName,1)~=nil and UnitInParty(sourceName) == nil and UnitInRaid(sourceName)==nil and UnitInBattleground(sourceName) == nil then
		WarningFrames.Title:SetText("|cFFFFFFFFA nearby enemy named "..sourceName.." just cast "..spellName..".")
		warningPlayerName = sourceName
			
			--WarningFrameButton:Enable()
		warningFrameTime = GetTime()
	end
	
	
	
		
	if event == "COMBAT_LOG_EVENT_UNFILTERED" and (string.sub(type1,1,18)=="SPELL_CAST_SUCCESS" or string.sub(type1,1,16)=="SPELL_CAST_START") and sourceName ~= GetUnitName("player") and sourceName ~= GetUnitName("focus") and sourceName ~= GetUnitName("target") and sourceName ~= nil and tableSearch(petAbilities,spellName) == nil and string.find(sourceName," ")==nil and UnitInParty(sourceName) == nil and UnitInRaid(sourceName)==nil and UnitInBattleground(sourceName) == nil then
		if tableSearch(BattlegroundMapNames,mapFileName) == nil then
			SendAddonMessage("FoL-WPvP","Feathers or Lead?","WHISPER",sourceName)
		end
		
		if tableSearch(meleePlayerAbilities,spellName) ~= nil and tableSearch(CombatWarningPlayers,sourceName)~=nil then
			local name, rank, icon, cost, isFunnel, powerType, castTime, minRange, maxRange = GetSpellInfo(spellName)
			enemyPlayerRange = maxRange
			local tempPlayerEntryPosition = deepTableSearch(playerList, sourceName, 1)
			if tempPlayerEntryPosition ~= nil then
				local playerEntry7 = playerList[tempPlayerEntryPosition]
				local Entry7 = playerEntry7[7]
				playerEntry7[7] = Entry7 + 1
			end
			if tableSearch(CombatWarningPlayers, sourceName) == nil then
				table.insert(CombatWarningPlayers,sourceName)
			end
		elseif tableSearch(rangedPlayerAbilities,spellName) ~= nil and tableSearch(CombatWarningPlayers,sourceName)~=nil then
			local name, rank, icon, cost, isFunnel, powerType, castTime, minRange, maxRange = GetSpellInfo(spellName)
			enemyPlayerRange = maxRange
			if tableSearch(CombatWarningPlayers, sourceName) == nil then
				table.insert(CombatWarningPlayers,sourceName)
			end
		elseif sourceName ~= GetUnitName("player") and string.sub(type1,1,16)=="SPELL_CAST_START" and sourceName ~= GetUnitName("target") and sourceName ~= GetUnitName("pet") and string.find(sourceName," ") == nil and tableSearch(CombatWarningPlayers, sourceName) ~= nil then
			WarningFrames.Title:SetText(sourceName.." is casting "..spellName.."!!")
			warningPlayerName = sourceName
			
			--WarningFrameButton:Enable()
			warningFrameTime = GetTime()
			
		end
	end
	
	
	if event == "UPDATE_MOUSEOVER_UNIT" and UnitIsPlayer("mouseover") and (UnitFactionGroup("player") ~= UnitFactionGroup("mouseover") or AlliedMouseoverEnabled == 1) then
		local mouseoverName = GetUnitName("mouseover")
		local mouseoverAuraTable = {}
		local mouseoverAuraTable1 = {}
		local mousoverSpec = "Unknown"
		local targetClass = UnitClass("mouseover")
		local mouseoverRace = UnitRace("mouseover")
		local mouseoverLevel = UnitLevel("mouseover")
		local enemyLocation = deepTableSearch(playerList,mouseoverName,1)
		local enemyEntry = playerList[enemyLocation]
		--print(mouseoverRace,mouseoverLevel)
		for i=1, 40 do
			local mouseoverAuras1 = UnitAura("mouseover", i)
			if mouseoverAuras1 ~= nil and tableSearch(allEnemySpecSkills1,mouseoverAuras1) ~= nil then
				
				for i=1, # allEnemySpecs1 do
					local tempSpecTable = allEnemySpecs1[i]
					if tableSearch(tempSpecTable,mouseoverAuras1)~=nil and mouseoverSpec == "Unknown" then
						mouseoverSpec=tempSpecTable[1]
						
					end
				end

			end
		end
		
		local gearRating = 0
		local pvpGearRating = 0	
		local targetSpecIndex = 0	
		if CheckInteractDistance("mouseover", 1) and CanInspect("mouseover") then
			--InspectUnit("mouseover") 
			UIErrorsFrame:UnregisterEvent("UI_ERROR_MESSAGE")		
			NotifyInspect("mouseover")
			UIErrorsFrame:RegisterEvent("UI_ERROR_MESSAGE")
			
						
			headItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("HeadSlot"))
			neckItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("NeckSlot"))
			shoulderItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("ShoulderSlot"))
			backItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("BackSlot"))
			chestItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("ChestSlot"))
			wristItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("WristSlot"))
			handsItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("HandsSlot"))
			waistItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("WaistSlot"))
			legsItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("LegsSlot"))
			feetItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("FeetSlot"))
			finger0ItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("Finger0Slot"))
			finger1ItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("Finger1Slot"))
			trinket0ItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("Trinket0Slot"))
			trinket1ItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("Trinket1Slot"))
			mainhandItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("MainHandSlot"))
			secondaryhandItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("SecondaryHandSlot"))
			rangedItemLink = GetInventoryItemLink("mouseover", GetInventorySlotInfo("RangedSlot"))
			
			if neckItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(neckItemLink)
				gearRating = gearRating + (itemLevel*.75)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.75)
				end
			end
			if headItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(headItemLink)
				gearRating = gearRating + (itemLevel*1.347)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*1.347)
				end
			end
			if shoulderItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(shoulderItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if backItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(backItemLink)
				gearRating = gearRating + (itemLevel*.75)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.75)
				end
			end
			if chestItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(chestItemLink)
				gearRating = gearRating + (itemLevel*1.347)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*1.347)
				end
			end
			if wristItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(wristItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if handsItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(handsItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if waistItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(waistItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if legsItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(legsItemLink)
				gearRating = gearRating + (itemLevel*1.347)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*1.347)
				end
			end
			if feetItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(feetItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if finger0ItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(finger0ItemLink)
				gearRating = gearRating + (itemLevel*.75)
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.75)
				end
			end
			if finger1ItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(finger1ItemLink)
				gearRating = gearRating + (itemLevel*.75)
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.75)
				end
			end
			if trinket0ItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(trinket0ItemLink)
				gearRating = gearRating + (itemLevel)
				if string.find(itemName,"of the Horde") ~= nil or string.find(itemName,"Battlemaster")~= nil or string.find(itemName,"of the Alliance") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel)
				end
			end
			if trinket1ItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(trinket1ItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"of the Horde") ~= nil or string.find(itemName,"Battlemaster")~= nil or string.find(itemName,"of the Alliance") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if mainhandItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(mainhandItemLink)
				gearRating = gearRating + (itemLevel*1.347)
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*1.347)
				end
			end
			if rangedItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(rangedItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			
			ClearInspectPlayer()
		elseif UnitFactionGroup("mouseover") ~= UnitFactionGroup("player") then
			
			local max_health = UnitHealthMax("mouseover")
			--print(max_health)
			for i=1, 40 do
				local mouseoverAuras1 = UnitAura("mouseover", i)
				if mouseoverAuras1 ~= nil then
					table.insert(mouseoverAuraTable,mouseoverAuras1)
					
				end
			end
			local buffPercent = 1
			if (deepTableSearch(playerList,mouseoverName,1)~=nil or tableSearch(BattlegroundMapNames,mapFileName) ~= nil) then
				local playerLocation = deepTableSearch(playerList,mouseoverName,1)
				local playerEntry = playerList[playerLocation]
				
				if mouseoverSpec == "Protection" then
					max_health = max_health/1.15
				end
				
				if mouseoverSpec == "Blood" then
					max_health = max_health-(max_health/11)
				end
				
				max_health = max_health - classBaseHealth[targetClass]
				
				if mouseoverSpec == "Survival" or mouseoverSpec == "Enhancement" or mouseoverSpec == "Survival" or mouseoverSpec == "Demonology" then
					max_health = max_health-(max_health/11)
				end
				
					
				if tableSearch(mouseoverAuraTable,"Mark of the Wild") ~= nil or tableSearch(mouseoverAuraTable,"Embrace of the Shale Spider") ~= nil or tableSearch(mouseoverAuraTable,"Blessing of Kings") then
					buffPercent = buffPercent+.05
				end
				
				if tableSearch(mouseoverAuraTable,"Blood Presence") ~= nil then
					buffPercent = buffPercent+.08
				end
				if tableSearch(mouseoverAuraTable,"Bear Form") ~= nil then
					buffPercent = buffPercent+.10
				end				
				if tableSearch(mouseoverAuraTable,"Vampiric Blood") ~= nil then
					buffPercent = buffPercent+.15
				end
				if tableSearch(mouseoverAuraTable,"Last Stand") ~= nil then
					buffPercent = buffPercent+.30
				end
				
				max_health=max_health/buffPercent
				
				if tableSearch(mouseoverAuraTable,"Power Word: Fortitude") ~= nil or tableSearch(mouseoverAuraTable,"Qiraji Fortitude") ~= nil or tableSearch(mouseoverAuraTable,"Blood Pact") ~= nil then
					max_health=max_health-5840
				end
				
				if mouseoverSpec == "Blood" or mouseoverSpec == "Protection" or mouseoverSpec == "Feral Combat" then
					max_health=max_health-6000
				end 
				
				max_health=max_health/10
				--print(max_health)
				if max_health < 2818 then
					gearRating="Bad"
				elseif max_health >= 2818 and max_health <=3585 then
					local stamValue=max_health-2818
					gearRating = 4539+(stamValue/1.1)
				elseif max_health >= 3586 and max_health <=4115 then
					local stamValue=max_health-3586
					gearRating = 5211+(stamValue/2.09)
				elseif max_health >= 4116 and max_health <=4651 then
					local stamValue=max_health-4116
					gearRating = 5457+(stamValue/2.43)
				elseif max_health >= 4652 and max_health <=4924 then
					local stamValue=max_health-4652
					gearRating = 5670+(stamValue/2.69)	
				elseif max_health >= 4925 and max_health <=5252 then
					local stamValue=max_health-4925
					gearRating = 5768+(stamValue/2.82)
				elseif max_health >= 5253 and max_health <=5548 then
					local stamValue=max_health-5253
					gearRating = 5881+(stamValue/3.01)
				elseif max_health >= 5549 then
					local stamValue=max_health-5549
					gearRating = 5976+(stamValue/3.058)
				end
				
			end
		end
		
		local tempPlayerName = GetUnitName("mouseover")
		local playerX, playerY = GetPlayerMapPosition("player")
		local locationInPlayerlist = deepTableSearch(playerList,tempPlayerName,1)
		local x = 0
		if UnitFactionGroup("mouseover") == UnitFactionGroup("player") and tableSearch(allClasses,mouseoverSpec) == nil and mouseoverSpec ~= nil and gearRating ~= 0 then
			if mouseoverSpec ~= "Unknown" then
				MouseOverFrame.Title:SetText(tempPlayerName.." || "..mouseoverSpec.." - "..targetClass.." || "..gearRating.." - "..string.sub(tostring((pvpGearRating/gearRating)*100),1,2).."% PvP")
			else
				MouseOverFrame.Title:SetText(tempPlayerName.." || "..targetClass.." || "..gearRating.." - "..string.sub(tostring((pvpGearRating/gearRating)*100),1,2).."% PvP")
			end
			
		elseif UnitFactionGroup("mouseover") == UnitFactionGroup("player") then
			if mouseoverSpec ~= "Unknown" then
				MouseOverFrame.Title:SetText(tempPlayerName.." || "..mouseoverSpec.." - "..targetClass.." || ".."Out of Range")
			else
				MouseOverFrame.Title:SetText(tempPlayerName.." || "..targetClass.." || ".."Out of Range")
			end
		end
		local spec = "Unknown"
		if mouseoverSpec ~= "Unknown" and tableSearch(allClasses,mouseoverSpec) == nil then 
			spec = mouseoverSpec
		end
		local pvpPercent = "0"
		if locationInPlayerlist ~= nil and UnitIsEnemy("mouseover","player") then
			local playerEntry = playerList[locationInPlayerlist]	
			x = playerEntry[7]
			if mouseoverSpec == "Unknown" or tableSearch(allClasses,mouseoverSpec) ~= nil then 
				spec = playerEntry[8]
			end
			if gearRating == 0 then
				gearRating = playerEntry[8]
			end
			local playerClass = playerEntry[10]
			MouseOverFrame.Title:SetText(tempPlayerName.."||"..spec.." - "..targetClass.." || "..string.sub(tostring(gearRating),1,4))
			if tonumber(playerEntry[2]) < (tonumber(currentTime) + 15) then
				playerList[locationInPlayerlist] = {tempPlayerName,currentTime,enemyPlayerRange,playerX,playerY,mapFileName,x,spec,string.sub(tostring(gearRating),1,4),targetClass,pvpPercent}
				if deepTableSearch(focusmanager,tempPlayerName,1) == nil then
					table.insert(focusmanager,{tempPlayerName,currentTime,x,targetClass,mouseoverSpec,string.sub(tostring(gearRating),1,4)})
				else
					local focusLocation = deepTableSearch(focusmanager,tempPlayerName,1)
					
					local focusEntry = focusmanager[focusLocation]
					
					focusEntry[2]=currentTime
					if spec~= "Unknown" then	
						focusEntry[5]=spec
					end
					focusEntry[6]=gearRating
					focusmanager[focusLocation]=focusEntry
				end
			end
		elseif UnitIsEnemy("mouseover","player") then 
			if tableSearch(BattlegroundMapNames,mapFileName) == nil then
				table.insert(playerList,{tempPlayerName,currentTime,enemyPlayerRange,playerX,playerY,mapFileName,x,spec,gearRating,targetClass,pvpPercent})
			end	
			MouseOverFrame.Title:SetText(tempPlayerName.."||"..spec.." - "..targetClass.." || "..string.sub(tostring(gearRating),1,4))
			if deepTableSearch(focusmanager,tempPlayerName,1) == nil then
				table.insert(focusmanager,{tempPlayerName,currentTime,x,targetClass,mouseoverSpec,string.sub(tostring(gearRating),1,4)})
				
			end
		end
		
	end
	
	if event == "COMBAT_LOG_EVENT_UNFILTERED" and string.sub(type1,1,18)=="SPELL_CAST_SUCCESS" and UnitIsPlayer("target") and (UnitIsEnemy("target","player") or AlliedMouseoverEnabled == 1) then
		local mouseoverName = GetUnitName("target")
		local mouseoverAuraTable={}
		
		local targetClass = UnitClass("target")
		local classSpecLocation = deepTableSearch(allClassSpecs,tagetClass,1)
		local classSpecs = allClassSpecs[classSpecLocation]
		local targetSpec = "Unknown"
		local targetSpecIndex = 0
		local gearRating = 0
		local pvpGearRating = 0	
			
			
		if CheckInteractDistance("target", 1) and (GetTime() - 2.5) > lastInspectTime and CanInspect("target") then
			UIErrorsFrame:UnregisterEvent("UI_ERROR_MESSAGE")		
			NotifyInspect("target")
			UIErrorsFrame:RegisterEvent("UI_ERROR_MESSAGE")
			headItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("HeadSlot"))
			neckItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("NeckSlot"))
			shoulderItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("ShoulderSlot"))
			backItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("BackSlot"))
			chestItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("ChestSlot"))
			wristItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("WristSlot"))
			handsItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("HandsSlot"))
			waistItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("WaistSlot"))
			legsItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("LegsSlot"))
			feetItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("FeetSlot"))
			finger0ItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("Finger0Slot"))
			finger1ItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("Finger1Slot"))
			trinket0ItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("Trinket0Slot"))
			trinket1ItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("Trinket1Slot"))
			mainhandItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("MainHandSlot"))
			secondaryhandItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("SecondaryHandSlot"))
			rangedItemLink = GetInventoryItemLink("target", GetInventorySlotInfo("RangedSlot"))
			if neckItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(neckItemLink)
				gearRating = gearRating + (itemLevel*.8)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.8)
				end
			end
			if headItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(headItemLink)
				gearRating = gearRating + (itemLevel*1.25)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*1.25)
				end
			end
			if shoulderItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(shoulderItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if backItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(backItemLink)
				gearRating = gearRating + (itemLevel*.8)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.8)
				end
			end
			if chestItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(chestItemLink)
				gearRating = gearRating + (itemLevel*1.25)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*1.25)
				end
			end
			if wristItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(wristItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if handsItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(handsItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if waistItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(waistItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if legsItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(legsItemLink)
				gearRating = gearRating + (itemLevel*1.25)
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*1.25)
				end
			end
			if feetItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(feetItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil or string.find(itemName,"Bloodied Pyrium") ~= nil or string.find(itemName,"Emberfire") ~= nil or string.find(itemName,"Fireweave") ~= nil or string.find(itemName,"Bloodied Leather") ~= nil or string.find(itemName,"Bloodied Dragonscale") ~= nil or string.find(itemName,"Bloodied Scale") ~= nil or string.find(itemName,"Bloodied Wyrmhide") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
			if finger0ItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(finger0ItemLink)
				gearRating = gearRating + (itemLevel*.8)
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.8)
				end
			end
			if finger1ItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(finger1ItemLink)
				gearRating = gearRating + (itemLevel*.8)
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.8)
				end
			end
			if trinket0ItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(trinket0ItemLink)
				gearRating = gearRating + (itemLevel*.8)
				if string.find(itemName,"of the Horde") ~= nil or string.find(itemName,"Battlemaster")~= nil or string.find(itemName,"of the Alliance") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.8)
				end
			end
			if trinket1ItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(trinket1ItemLink)
				gearRating = gearRating + (itemLevel*.8)
				if string.find(itemName,"of the Horde") ~= nil or string.find(itemName,"Battlemaster")~= nil or string.find(itemName,"of the Alliance") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*.8)
				end
			end
			if mainhandItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(mainhandItemLink)
				gearRating = gearRating + (itemLevel*1.4)
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + (itemLevel*1.4)
				end
			end
			if rangedItemLink ~= nil then
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(rangedItemLink)
				gearRating = gearRating + itemLevel
				if string.find(itemName,"Gladiator") ~= nil then
					pvpGearRating = pvpGearRating + itemLevel
				end
			end
		
			
			
			lastInspectTime = GetTime()
			ClearInspectPlayer()
			
		elseif UnitFactionGroup("target") ~= UnitFactionGroup("player") then
			local max_health = UnitHealthMax("target")
			for i=1, 40 do
				local mouseoverAuras1 = UnitAura("target", i)
				if mouseoverAuras1 ~= nil then
					table.insert(mouseoverAuraTable,mouseoverAuras1)
				end
			end
			local buffPercent = 1
			if deepTableSearch(playerList,mouseoverName,1)~=nil then
				local playerLocation = deepTableSearch(playerList,mouseoverName,1)
				local playerEntry = playerList[playerLocation]
				
				if playerEntry[8] == "Protection" then
					max_health = max_health/1.15
				end
				
				if playerEntry[8] == "Blood" then
					max_health = max_health-(max_health/11)
				end
				max_health = max_health - classBaseHealth[targetClass]
				
				if playerEntry[8] == "Survival" or playerEntry[8] == "Enhancement" or playerEntry[8] == "Survival" or playerEntry[8] == "Demonology" then
					max_health = max_health-(max_health/11)
				end
				
				if tableSearch(mouseoverAuraTable,"Mark of the Wild") ~= nil or tableSearch(mouseoverAuraTable,"Embrace of the Shale Spider") ~= nil or tableSearch(mouseoverAuraTable,"Blessing of Kings") then
					buffPercent = buffPercent+.05
				end
				
				if tableSearch(mouseoverAuraTable,"Blood Presence") ~= nil then
					buffPercent = buffPercent+.08
				end
				if tableSearch(mouseoverAuraTable,"Bear Form") ~= nil then
					buffPercent = buffPercent+.10
				end				
				if tableSearch(mouseoverAuraTable,"Vampiric Blood") ~= nil then
					buffPercent = buffPercent+.15
				end
				if tableSearch(mouseoverAuraTable,"Last Stand") ~= nil then
					buffPercent = buffPercent+.30
				end
				
				max_health=max_health/buffPercent
				
				if tableSearch(mouseoverAuraTable,"Power Word: Fortitude") ~= nil or tableSearch(mouseoverAuraTable,"Qiraji Fortitude") ~= nil or tableSearch(mouseoverAuraTable,"Blood Pact") ~= nil then
					max_health=max_health-5840
				end
				max_health=max_health/10
				
				if max_health < 2818 then
					gearRating="Bad"
				elseif max_health >= 2818 and max_health <=3585 then
					local stamValue=max_health-2818
					gearRating = 4539+(stamValue/1.1)
				elseif max_health >= 3586 and max_health <=4115 then
					local stamValue=max_health-3586
					gearRating = 5211+(stamValue/2.09)
				elseif max_health >= 4116 and max_health <=4651 then
					local stamValue=max_health-4116
					gearRating = 5457+(stamValue/2.43)
				elseif max_health >= 4652 and max_health <=4924 then
					local stamValue=max_health-4652
					gearRating = 5670+(stamValue/2.69)	
				elseif max_health >= 4925 and max_health <=5252 then
					local stamValue=max_health-4925
					gearRating = 5768+(stamValue/2.82)
				elseif max_health >= 5253 and max_health <=5548 then
					local stamValue=max_health-5253
					gearRating = 5881+(stamValue/3.01)
				elseif max_health >= 5549 then
					local stamValue=max_health-5549
					gearRating = 5976+(stamValue/3.058)
				end
				
			end
		
		end
		local tempPlayerName = GetUnitName("target")
		local playerX, playerY = GetPlayerMapPosition("player")
		local locationInPlayerlist = deepTableSearch(playerList,tempPlayerName,1)
		local x = 0
		if UnitFactionGroup("target") == UnitFactionGroup("player") and targetSpec ~= "Unknown" and tableSearch(allClasses,targetSpec) == nil and hasTarget == 0 and CheckInteractDistance("target", 1) then
			
			TargetFrame.Title:SetText(tempPlayerName.." || "..targetSpec.." - "..targetClass.." || "..gearRating.." - "..string.sub(tostring((pvpGearRating/gearRating)*100),1,2).."% PvP")
		elseif UnitFactionGroup("target") == UnitFactionGroup("player") and hasTarget == 0 and CheckInteractDistance("target", 1) then
			TargetFrame.Title:SetText(tempPlayerName.." || "..targetClass.." || "..gearRating.." - "..string.sub(tostring((pvpGearRating/gearRating)*100),1,2).."% PvP")
		end
		local spec = "Unknown"
		if targetSpec ~= "Unknown" and tableSearch(allClasses,targetSpec) == nil then 
			spec = targetSpec
		end
		pvpPercent = "0"
		if locationInPlayerlist ~= nil and UnitIsEnemy("target","player") then
			local playerEntry = playerList[locationInPlayerlist]	
			if tonumber(playerEntry[2]) < (tonumber(currentTime) + 15) then
				x = playerEntry[7]
				
				if targetSpec == "Unknown" or tableSearch(allClasses,targetSpec) ~= nil then 
					spec = playerEntry[8]
				end
				local gearRating = playerEntry[9]
				local playerClass = playerEntry[10]
				if hasTarget == 0 and CheckInteractDistance("target", 1) then
					if type(gearRating) == "number" then
						TargetFrame.Title:SetText(tempPlayerName.."||"..spec.." - "..targetClass.." || "..gearRating)
					else
						TargetFrame.Title:SetText(tempPlayerName.."||"..spec.." - "..targetClass.." || "..gearRating)
					end
				end
				playerList[locationInPlayerlist] = {tempPlayerName,currentTime,enemyPlayerRange,playerX,playerY,mapFileName,x,targetSpec,gearRating,targetClass,pvpPercent}
				if deepTableSearch(focusmanager,tempPlayerName,1) == nil then
					table.insert(focusmanager,{tempPlayerName,currentTime,x,targetClass,targetSpec,string.sub(tostring(gearRating),1,4)})
				else
					local focusLocation = deepTableSearch(focusmanager,tempPlayerName,1)
					local focusEntry = focusmanager[focusLocation]
					focusEntry[2]=currentTime
					focusEntry[5]=spec
					focusEntry[6]=gearRating
					focusmanager[focusLocation]=focusEntry	
					
				end
			end
		elseif UnitIsEnemy("target","player") then 
			if hasTarget == 0 and CheckInteractDistance("target", 1) then
				if type(gearRating) == "number" then
					TargetFrame.Title:SetText(tempPlayerName.."||"..spec.." - "..targetClass.." || "..string.sub(tostring(gearRating),1,4))
				else
					TargetFrame.Title:SetText(tempPlayerName.."||"..spec.." - "..targetClass.." || "..string.sub(tostring(gearRating),1,4))
				end
			end
			if tableSearch(BattlegroundMapNames,mapFileName) == nil then
				table.insert(playerList,{tempPlayerName,currentTime,enemyPlayerRange,playerX,playerY,mapFileName,x,targetSpec,string.sub(tostring(gearRating),1,4),targetClass,pvpPercent})
			end	
			if deepTableSearch(focusmanager,tempPlayerName,1) == nil then
				table.insert(focusmanager,{tempPlayerName,currentTime,x,targetClass,targetSpec,string.sub(tostring(gearRating),1,4)})
				
			end
		end
		hasTarget = 1
	end
	

	if event == "CHAT_MSG_CHANNEL" and channelName == "UWorldPvP" and timestamp ~= "active" and sourceFlags ~= GetUnitName("player") then
		--timestamp - msg
		--sourceFlags - sender
		
		local Break1 = string.find(timestamp,"_")
		local Break2 = string.find(timestamp,"-")
		local Break3 = string.find(timestamp,"+")
		local Break4 = string.find(timestamp,"=")
		local Break5 = string.find(timestamp,"#")
		local Break6 = string.find(timestamp,"!")
		local Break7 = string.find(timestamp,"@")
		local Break8 = string.find(timestamp,"$")
		local Break9 = string.find(timestamp,"&")
		local Break10 = string.find(timestamp,"^")
		local Data1 = string.sub(timestamp,1,Break1-1)
		local playerLocation = deepTableSearch(playerList,Data1,1)
		local playerEntry = playerList[playerLocation]
		local Data2 = string.sub(timestamp,Break1+1,Break2-1)
		local Data3 = string.sub(timestamp,Break2+1,Break3-1)
		local Data4 = string.sub(timestamp,Break3+1,Break4-1)
		local Data5 = string.sub(timestamp,Break4+1,Break5-1)
		local Data6 = string.sub(timestamp,Break5+1,Break6-1)
		local Data7 = string.sub(timestamp,Break6+1,Break7-1)
		if Data7 < playerEntry[7] then
			Data7 = playerEntry[7]
		end
		local Data8 = string.sub(timestamp,Break7+1,Break8-1)
		if Data8 == "Unknown" and playerEntry[8] ~= "Unknown" then
			Data8 = playerEntry[8]
		end
		
		local Data9 = string.sub(timestamp,Break8+1,Break9-1)
		if tonumber(Data9) == 0 and tonumber(playerEntry[9]) ~= 0 then
			Data8 = playerEntry[9]
		end
		local Data10 = string.sub(timestamp,Break9+1,Break10-1)
		if Data10 == "none" and playerEntry[10] ~= "none" then
			Data10 = playerEntry[10]
		end
		local Data11 = string.sub(timestamp,Break10+1, # timestamp)
		if Data11 == "0% PvP" and playerEntry[11] ~= "0% PvP" then
			Data10 = playerEntry[11]
		end
		local locationInPlayerlist = deepTableSearch(playerList,Data1,1)
		
		if locationInPlayerlist ~= nil then
			local playerEntry = playerList[locationInPlayerlist]	
			if tonumber(playerEntry[2]) < (tonumber(currentTime) + 15) then
				local x = playerEntry[7]
				if x > tonumber(Data7) then
					Data7 = x
				end
				
				playerList[locationInPlayerlist] = {Data1,Data2,Data3,Data4,Data5,Data6,Data7,Data8,Data9,Data10,Data11}
				
				--print "replace occurred"
			end
			if tonumber(playerEntry[2]) == tonumber(currentTime) then
				local rangeWeight1 = tonumber(playerEntry[2])/tonumber(playerEntry[3])
				local rangeWeight2 = tonumber(Data2)/tonumber(Data3)
				local rangeDivisor = rangeWeight1+rangeWeight2
				Data4 = ((tonumber(playerEntry[4])*rangeWeight1)+(tonumber(Data4)*rangeWeight2))/rangeDivisor
				Data5 = ((tonumber(playerEntry[5])*rangeWeight1)+(tonumber(Data5)*rangeWeight2))/rangeDivisor				
				playerList[locationInPlayerlist] = {Data1,Data2,Data3,Data4,Data5,Data6,Data7,Data8,Data9,Data10,Data11}
				
				--print "replace occurred"
			end
		else 
			
			table.insert(playerList,{Data1,Data2,Data3,Data4,Data5,Data6,Data7,Data8,Data9,Data10,Data11})
		end
		--SendChatMessage(tempPlayerName.."_"..currentTime.."-".."100".."+"..playerX.."="..playerY.."#"..mapFileName.."!active","CHANNEL","Orcish",UWorldPvPChannel)
	end
	
	if event == "CHAT_MSG_ADDON" and timestamp == "UWorldPvPDATA" and UnitInBattleground(sourceName) == true then
		--timestamp - msg
		--sourceFlags - sender
		
		local Break1 = string.find(type1,"_")
		local Break2 = string.find(type1,"-")
		local Break3 = string.find(type1,"+")
		local Break4 = string.find(type1,"=")
		local Break5 = string.find(type1,"#")
		local Break6 = string.find(type1,"!")
		local Break7 = string.find(type1,"@")
		local Break8 = string.find(type1,"$")
		local Break9 = string.find(type1,"&")
		local Break10 = string.find(type1,"^")
		local Data1 = string.sub(type1,1,Break1-1)
		local playerLocation = deepTableSearch(playerList,Data1,1)
		local playerEntry = playerList[playerLocation]
		local Data2 = string.sub(type1,Break1+1,Break2-1)
		local Data3 = string.sub(type1,Break2+1,Break3-1)
		local Data4 = string.sub(type1,Break3+1,Break4-1)
		local Data5 = string.sub(type1,Break4+1,Break5-1)
		local Data6 = string.sub(type1,Break5+1,Break6-1)
		local Data7 = string.sub(type1,Break6+1,Break7-1)
		if Data7 < playerEntry[7] then
			Data7 = playerEntry[7]
		end
		local Data8 = string.sub(type1,Break7+1,Break8-1)
		if Data8 == "Unknown" and playerEntry[8] ~= "Unknown" then
			Data8 = playerEntry[8]
		end
		
		local Data9 = string.sub(type1,Break8+1,Break9-1)
		if tonumber(Data9) == 0 and tonumber(playerEntry[9]) ~= 0 then
			Data8 = playerEntry[9]
		end
		local Data10 = string.sub(type1,Break9+1,Break10-1)
		if Data10 == "none" and playerEntry[10] ~= "none" then
			Data10 = playerEntry[10]
		end
		local Data11 = string.sub(type1,Break10+1, # timestamp)
		if Data11 == "0% PvP" and playerEntry[11] ~= "0% PvP" then
			Data10 = playerEntry[11]
		end
		local locationInPlayerlist = deepTableSearch(playerList,Data1,1)
		
		if locationInPlayerlist ~= nil then
			local playerEntry = playerList[locationInPlayerlist]	
			if tonumber(playerEntry[2]) < (tonumber(currentTime) + 15) then
				local x = playerEntry[7]
				if x > tonumber(Data7) then
					Data7 = x
				end
				
				playerList[locationInPlayerlist] = {Data1,Data2,Data3,Data4,Data5,Data6,Data7,Data8,Data9,Data10,Data11}
				
				--print "replace occurred"
			end
			if tonumber(playerEntry[2]) == tonumber(currentTime) then
				local rangeWeight1 = tonumber(playerEntry[2])/tonumber(playerEntry[3])
				local rangeWeight2 = tonumber(Data2)/tonumber(Data3)
				local rangeDivisor = rangeWeight1+rangeWeight2
				Data4 = ((tonumber(playerEntry[4])*rangeWeight1)+(tonumber(Data4)*rangeWeight2))/rangeDivisor
				Data5 = ((tonumber(playerEntry[5])*rangeWeight1)+(tonumber(Data5)*rangeWeight2))/rangeDivisor				
				playerList[locationInPlayerlist] = {Data1,Data2,Data3,Data4,Data5,Data6,Data7,Data8,Data9,Data10,Data11}
				
				--print "replace occurred"
			end
		else 
			
			table.insert(playerList,{Data1,Data2,Data3,Data4,Data5,Data6,Data7,Data8,Data9,Data10,Data11})
		end
		--SendChatMessage(tempPlayerName.."_"..currentTime.."-".."100".."+"..playerX.."="..playerY.."#"..mapFileName.."!active","CHANNEL","Orcish",UWorldPvPChannel)
	end
	

	local focusmanagernumber
	local focusmanagertemp
	local className
	local FMname
	local FMspec 
	local FMgearscore
	local FMpvp
	if event == "COMBAT_LOG_EVENT_UNFILTERED" and # focusmanager ~= 0 then
		--string.sub(type1,1,16)=="SPELL_CAST_START" and
		lastFocusTarget = GetUnitName("focus")
		focusmanagerstring = ""
		local initialLength = # focusmanager+1
		local numberRemoved = 0
		local initialSubtract
		if initialLength >= 7 then
			initialSubtract = 6
		else
			initialSubtract = initialLength - 1
		end
		for i=(initialLength-initialSubtract), # focusmanager do
			
			focusmanagernumber = i-numberRemoved
			focusmanagertemp = focusmanager[i]
			if focusmanagertemp ~= nil then
				className = focusmanagertemp[4]
				FMname = focusmanagertemp[1]
				FMspec = focusmanagertemp[5]
				FMgearscore = focusmanagertemp[6]
				FMpvp = focusmanagertemp[3]
				
					
				focusmanagerstring = focusmanagerstring..focusmanagertemp[1].."/focus "..' /script SendAddonMessage("UWorldPvP","UWorldPvPmacro","WHISPER",'..GetUnitName("player")..') '
				if i == (initialLength-1) then
					if tonumber(focusmanagertemp[2]) >= (tonumber(currentTime) - 200) then
						tempframe.Body1:SetText(classColors[className]..FMname)
						tempframe.Body1a:SetText("|cFFFFFFFF|"..focusmanagertemp[5])
						tempframe.Body1b:SetText("|cFFFFFFFF|"..focusmanagertemp[6])
						warningPlayerName2a = FMname
						tempframeButton1:Enable()
					else
						tempframe.Body1:SetText("")
						tempframe.Body1a:SetText("")
						tempframe.Body1b:SetText("")
						tempframeButton1:Disable()
						table.remove(focusmanager,i-numberRemoved)
						numberRemoved = numberRemoved + 1
					end
				elseif i == (initialLength-2) then
					if tonumber(focusmanagertemp[2]) >= (tonumber(currentTime) - 200) then
						
						tempframe.Body2:SetText(classColors[className]..FMname)
						tempframe.Body2a:SetText("|cFFFFFFFF|"..focusmanagertemp[5])
						tempframe.Body2b:SetText("|cFFFFFFFF|"..focusmanagertemp[6])
						warningPlayerName2b = FMname
						tempframeButton2:Enable()
					else
						tempframe.Body2:SetText("")
						tempframe.Body2a:SetText("")
						tempframe.Body2b:SetText("")
						tempframeButton2:Disable()
						table.remove(focusmanager,i-numberRemoved)
						numberRemoved = numberRemoved + 1
					end
				elseif i == (initialLength-3) then
					if tonumber(focusmanagertemp[2]) >= (tonumber(currentTime) - 200) then
						tempframe.Body3:SetText(classColors[className]..FMname)
						tempframe.Body3a:SetText("|cFFFFFFFF|"..focusmanagertemp[5])
						tempframe.Body3b:SetText("|cFFFFFFFF|"..focusmanagertemp[6])
						warningPlayerName2c = FMname
						tempframeButton3:Enable()
					else
						tempframe.Body3:SetText("")
						tempframe.Body3a:SetText("")
						tempframe.Body3b:SetText("")
						tempframeButton3:Disable()
						table.remove(focusmanager,i-numberRemoved)
						numberRemoved = numberRemoved + 1
					end
				elseif i == (initialLength-4) then
					if tonumber(focusmanagertemp[2]) >= (tonumber(currentTime - 200)) then
						tempframe.Body4:SetText(classColors[className]..FMname)
						tempframe.Body4a:SetText("|cFFFFFFFF|"..focusmanagertemp[5])
						tempframe.Body4b:SetText("|cFFFFFFFF|"..focusmanagertemp[6])
						warningPlayerName2d = FMname
						tempframeButton4:Enable()
					else
						tempframe.Body4:SetText("")
						tempframe.Body4a:SetText("")
						tempframe.Body4b:SetText("")
						tempframeButton4:Disable()
						table.remove(focusmanager,i-numberRemoved)
						numberRemoved = numberRemoved + 1
					end
				elseif i == (initialLength-5) then
					if tonumber(focusmanagertemp[2]) >= (tonumber(currentTime) - 200) then
						tempframe.Body5:SetText(classColors[className]..FMname)
						tempframe.Body5a:SetText("|cFFFFFFFF|"..focusmanagertemp[5])
						tempframe.Body5b:SetText("|cFFFFFFFF|"..focusmanagertemp[6])
						warningPlayerName2e = FMname
						tempframeButton5:Enable()
					else
						tempframe.Body5:SetText("")
						tempframe.Body5a:SetText("")
						tempframe.Body5b:SetText("")
						tempframeButton5:Disable()
						table.remove(focusmanager,i-numberRemoved)
						numberRemoved = numberRemoved + 1
					end
				elseif i == (initialLength-6) then
					if tonumber(focusmanagertemp[2]) >= (tonumber(currentTime) - 200) then
						tempframe.Body6:SetText(classColors[className]..FMname)
						tempframe.Body6a:SetText("|cFFFFFFFF|"..focusmanagertemp[5])
						tempframe.Body6b:SetText("|cFFFFFFFF|"..focusmanagertemp[6])
						warningPlayerName2f = FMname
						tempframeButton6:Enable()
					else
						tempframe.Body6:SetText("")
						tempframe.Body6a:SetText("")
						tempframe.Body6b:SetText("")
						tempframeButton6:Disable()
						table.remove(focusmanager,i-numberRemoved)
						numberRemoved = numberRemoved + 1
					end
				elseif i == (initialLength-7) then
					if tonumber(focusmanagertemp[2]) >= (tonumber(currentTime) - 200) then
						tempframe.Body7:SetText(classColors[className]..FMname)
						tempframe.Body7a:SetText("|cFFFFFFFF|"..focusmanagertemp[5])
						tempframe.Body7b:SetText("|cFFFFFFFF|"..focusmanagertemp[6])
						warningPlayerName2g = FMname
						tempframeButton7:Enable()
					else
						tempframe.Body7:SetText("")
						tempframe.Body7a:SetText("")
						tempframe.Body7b:SetText("")
						tempframeButton7:Disable()
						table.remove(focusmanager,i-numberRemoved)
						numberRemoved = numberRemoved + 1
					end
				end
			end
		end
	elseif 	event == "COMBAT_LOG_EVENT_UNFILTERED" and string.sub(type1,1,16)=="SPELL_CAST_START" and # focusmanager == 0 then
		tempframe.Body1:SetText("")
		tempframe.Body1a:SetText("")
		tempframe.Body1b:SetText("")
		tempframeButton1:Disable()
		tempframe.Body2:SetText("")
		tempframe.Body2a:SetText("")
		tempframe.Body2b:SetText("")
		tempframeButton2:Disable()
		tempframe.Body3:SetText("")
		tempframe.Body3a:SetText("")
		tempframe.Body3b:SetText("")
		tempframeButton3:Disable()
		tempframe.Body4:SetText("")
		tempframe.Body4a:SetText("")
		tempframe.Body4b:SetText("")
		tempframeButton4:Disable()
		tempframe.Body5:SetText("")
		tempframe.Body5a:SetText("")
		tempframe.Body5b:SetText("")
		tempframeButton5:Disable()
		tempframe.Body6:SetText("")
		tempframe.Body6a:SetText("")
		tempframe.Body6b:SetText("")
		tempframeButton6:Disable()
		tempframe.Body7:SetText("")
		tempframe.Body7a:SetText("")
		tempframe.Body7b:SetText("")
		tempframeButton7:Disable()
	end
	
	
	if event == "PARTY_MEMBERS_CHANGED" then
		for i=1,GetNumPartyMembers() do
			if GetUnitName("party"..i) ~= nil then
				local name = GetUnitName("party"..i,true)
				
				SendAddonMessage("UWorldPvP", "This player has UWorldPvP", "BATTLEGROUND", name)
			end
		end
	end
	
	if event == "CHAT_MSG_ADDON" and timestamp == "UWorldPvP" and type1 == "This player has UWorldPvP" then
		table.insert(bgPlayers,sourceName)
	end	
	if event == "UPDATE_BATTLEFIELD_STATUS" then
		bgPlayers = {}
		focusmanager = {}
	end
end



local function RegisterEvents(self, ...)
	for i=1,select('#', ...) do
		self:RegisterEvent(select(i, ...))
	end
end

MainFrame.RegisterEvents = RegisterEvents
MainFrame:SetScript("OnEvent", onEvent)
MainFrame:RegisterEvents("COMBAT_LOG_EVENT_UNFILTERED","CHAT_MSG_ADDON","CHAT_MSG_SYSTEM","CHAT_MSG_CHANNEL","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","INSPECT_TALENT_READY","UI_ERROR_MESSAGE","UPDATE_MOUSEOVER_UNIT","ADDON_LOADED","PLAYER_LOGOUT","PLAYER_ENTERING_WORLD","PARTY_MEMBERS_CHANGED","UPDATE_BATTLEFIELD_STATUS")




--frame:RegisterEvent("WORLD_MAP_UPDATE")
ToolTip:SetFrameStrata("FULLSCREEN_DIALOG")

ToolTip:SetWidth(50)
ToolTip:SetHeight(15)
ToolTip:SetBackdrop({ 
bgFile="Interface/Tooltips/UI-Tooltip-Background", edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
 tile = false, tileSize = 0, edgeSize = 7, 
  insets = { left = 0, right = 0, top = 0, bottom = 0 }
})
ToolTip:SetBackdropColor(0,0,0)
ToolTip.Title=ToolTip:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
ToolTip.Title:SetText("")
ToolTip.Title:SetPoint("TOP",ToolTip,"TOP",0,-2)



local function myChatFilter(self,event,msg,author,lang,arg4,arg5,arg6,arg7,arg8,arg9)
	
	if event == "CHAT_MSG_SYSTEM" and string.sub(msg,1,16) == "No player named " then
		
		return true
	end
--string.sub(msg,1,16) == "No player named "
end

local function myChatFilter2(self,event,msg,author,lang,arg4,arg5,arg6,arg7,arg8,arg9)
	if event == "CHAT_MSG_CHANNEL" and arg9 == "UWorldPvP" then
		return true
		
	end
end

ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", myChatFilter)
ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL", myChatFilter2)

local MapUpdateTime = "map"
local MapUpdateTime2 

local function frameshow(playernumber,width,height)
	local mapFileName3, textureHeight = GetMapInfo()
	local playersInMapZone = deepTableSearch2(playerList,mapFileName3,6)
	local somethingFucker = playersInMapZone[1]
	ToolTip.Title:SetText("|cFFFFFF00"..somethingFucker[1])
	ToolTip:SetPoint("BOTTOMLEFT",width,height)
	ToolTip:Show()
end

local function framehide(playernumber,width,height)
	local mapFileName2, textureHeight = GetMapInfo()
	playersInMapZone = deepTableSearch2(playerList,mapFileName2,6)
	
	ToolTip.Title:SetText("")
	ToolTip:Hide()
end



local function MapOpen()
	local mapFileName2, textureHeight = GetMapInfo()
	local playersInMapZone = deepTableSearch2(playerList,mapFileName2,6)
	
	MapUpdateTime = mapFileName2
	if playersInMapZone~=nil then
		
		for i=1, # playersInMapZone do
		
			local pPosition = playersInMapZone[i]
			local className = "none"
			if pPosition[10] ~= nil then
				className = pPosition[10]
			end
			if (tonumber(pPosition[2]) + 200) > tonumber(currentTime) then
				
				local widthVariable = (pPosition[4]*WorldMapDetailFrame:GetWidth())+WorldMapDetailFrame:GetLeft()--(WorldMapDetailFrame:GetWidth()/40)
				local heightVariable = ((1-pPosition[5])*WorldMapDetailFrame:GetHeight())+WorldMapDetailFrame:GetBottom()--(WorldMapDetailFrame:GetHeight()/40)
				local veryVeryTempFrame2 = framelist[i]
				veryVeryTempFrame2:SetPoint("BOTTOMLEFT",widthVariable,heightVariable)
				if tableSearch(enemyList,pPosition[1])~=nil then
					veryVeryTempFrame2.Title=veryVeryTempFrame2:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
					veryVeryTempFrame2.Title:SetText(classColors[className]..pPosition[1])
					veryVeryTempFrame2.Title:SetPoint("TOP",veryVeryTempFrame2,"TOP",0,13)
				end	
				veryVeryTempFrame2:Show()
			end
		end
	end
	
	playersInMapZone = {}
	
end

local function MapClose()
	
	for i=1, # framelist do
		
		local veryVeryTempFrame = framelist[i]
		veryVeryTempFrame:Hide()
	end
end

local function MapUpdate()
	local mapFileName2, textureHeight = GetMapInfo()
	
	if MapUpdateTime ~= mapFileName2 then
		
		
		for i=1, # framelist do
			local veryVeryTempFrame = framelist[i]
			veryVeryTempFrame:Hide()
		end
		local playersInMapZone = deepTableSearch2(playerList,mapFileName2,6)
		for i=1, # playersInMapZone do
				
			local pPosition = playersInMapZone[i]
			local className = pPosition[10]
			if (tonumber(pPosition[2]) + 200) > tonumber(currentTime) then
				local veryVeryTempFrame2 = framelist[i]
				local widthVariable = (pPosition[4]*WorldMapDetailFrame:GetWidth())+WorldMapDetailFrame:GetLeft()---(WorldMapDetailFrame:GetWidth()/30)
				local heightVariable = ((1-pPosition[5])*WorldMapDetailFrame:GetHeight())+WorldMapDetailFrame:GetBottom()---(WorldMapDetailFrame:GetHeight()/24)
				veryVeryTempFrame2:SetPoint("BOTTOMLEFT",widthVariable,heightVariable)
				if tableSearch(enemyList,pPosition[1])~=nil then
					veryVeryTempFrame2.Title=veryVeryTempFrame2:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
					veryVeryTempFrame2.Title:SetText(classColors[className]..pPosition[1])
					veryVeryTempFrame2.Title:SetPoint("TOP",veryVeryTempFrame2,"TOP",0,13)
				end		
				veryVeryTempFrame2:Show()
			end
		end
		playersInMapZone = {} 
		MapUpdateTime = mapFileName2
		MapUpdateTime2 = GetTime()
	end
end

hooksecurefunc(WorldMapFrame,'Show',MapOpen)
hooksecurefunc(WorldMapFrame,'Hide',MapClose)
WorldMapFrame:SetScript("OnUpdate",MapUpdate)



