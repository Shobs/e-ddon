-------------------------------------------------------------------------------
-- Addon namespace
local Broker_SimplePvP = CreateFrame("Frame")
_G["Broker_SimplePvP"] = Broker_SimplePvP

local LDB = LibStub:GetLibrary("LibDataBroker-1.1")
dataobj = LDB:NewDataObject("Broker_SimplePvP",
                {
                    type = "data source", 
					value = "1",
                    icon = "Interface\\AddOns\\Broker_SimplePvP\\"..UnitFactionGroup("player").."Icon",
                    suffix = " Honor",
                })

-------------------------------------------------------------------------------
-- Local variables
local defaults = {
    displ = 1
}

local GetArenaCurrency = GetArenaCurrency or function() return select(2,GetCurrencyInfo(390)) or 0 end
local GetHonorCurrency = GetHonorCurrency or function() return select(2,GetCurrencyInfo(392)) or 0 end

local values = {
        {func = function() return GetHonorCurrency() end},
        {func = function() return GetArenaCurrency() end},
}


local icons = {
    "Interface\\AddOns\\Broker_SimplePvP\\"..UnitFactionGroup("player").."Honor",
    "Interface\\AddOns\\Broker_SimplePvP\\"..UnitFactionGroup("player").."Conquest",
}

local suffix = {
        " Honor",
        " Conquest",
}


local DISPL_MAX = 2


-------------------------------------------------------------------------------
-- Event handlers
Broker_SimplePvP:SetScript("OnEvent",
    function(self, event, ...)
        if self[event] then
            return self[event](self, event, ...)
        end
    end
)
Broker_SimplePvP:RegisterEvent("ADDON_LOADED")
Broker_SimplePvP:RegisterEvent("BAG_UPDATE")
Broker_SimplePvP:RegisterEvent("HONOR_CURRENCY_UPDATE")
Broker_SimplePvP:RegisterEvent("PLAYER_ENTERING_WORLD")


local function Update()
    dataobj.value = values[Broker_SimplePvPDB.displ].func()
    dataobj.text = dataobj.value.." "..dataobj.suffix
end


function Broker_SimplePvP:ADDON_LOADED(event, addon)
        if addon ~= "Broker_SimplePvP" then return end

    Broker_SimplePvPDB = Broker_SimplePvPDB or defaults
    dataobj.suffix = suffix[Broker_SimplePvPDB.displ]
        dataobj.icon = icons[Broker_SimplePvPDB.displ]
    Update()
    self:UnregisterEvent("ADDON_LOADED")
end


-------------------------------------------------------------------------------
-- LDB functions
function dataobj.OnTooltipShow(tooltip)
    tooltip:AddLine("Broker_SimplePvP", 0,1,0, 0,1,0)
    tooltip:AddLine(" ")
    tooltip:AddDoubleLine("Honor Points:", GetHonorCurrency(), 1,1,1, 1,1,1)
    tooltip:AddDoubleLine("Conquest Points:", GetArenaCurrency(), 1,1,1, 1,1,1)    
    tooltip:AddLine(" ")
    tooltip:AddLine("Click to toggle display.")
end


function dataobj.OnClick(self, button)
    local displ = Broker_SimplePvPDB.displ

    Broker_SimplePvPDB.displ = (displ == DISPL_MAX and 1) or (displ and displ + 1) or 1
    dataobj.suffix = suffix[Broker_SimplePvPDB.displ]
    dataobj.icon = icons[Broker_SimplePvPDB.displ]
    Update()
end

function Broker_SimplePvP.BackpackUpdate( )
    Update( )
end

hooksecurefunc( "BackpackTokenFrame_Update", Broker_SimplePvP.BackpackUpdate)
