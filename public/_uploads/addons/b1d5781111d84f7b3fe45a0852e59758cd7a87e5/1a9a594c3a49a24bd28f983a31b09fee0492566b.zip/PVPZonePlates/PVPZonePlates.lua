--===============================================================
--[[ PVPZonePlates
	by Chrome67
	available on Curse.com and WoWInterface.com
	version 0.03 
	
	
	===Change Log===
	-v.0.01 initial beta release
	-v.0.02 removed debugging code
	-v.0.03 added (option) plates enabled during any combat & toggle commands
	]]
	
--================================================================

--[[ Initialization ]]--

PVPZonePlates = CreateFrame("Frame")

PVPZonePlates_quiet = 0
PVPZonePlates_Combat_ON = 0

--[[ Events ]]--

function PVPZonePlates:OnEvent(event, arg1, ...)
	if event == "ADDON_LOADED" and arg1 == "PVPZonePlates" then
		print("PVPZonePlates Loaded...")
		PVPZonePlates:UnregisterEvent("ADDON_LOADED")
		PVPZonePlates:RegisterEvent("PLAYER_ENTERING_WORLD")
		PVPZonePlates:RegisterEvent("UPDATE_WORLD_STATES")
		PVPZonePlates:RegisterEvent("ZONE_CHANGED_NEW_AREA")
		PVPZonePlates:RegisterEvent("PLAYER_REGEN_DISABLED")
		PVPZonePlates:RegisterEvent("PLAYER_REGEN_ENABLED")
		return
	end
	PVPZonePlates:UpdatePlates()
end

function PVPZonePlates:UpdatePlates()
	local pvpzone = PVPZonePlates:InPvpZone()
	if not PVPZonePlates_quiet then
		print("|cff23e523You have just entered a PVP ZONE; Nameplates are now enabled.|r")
	end
	if pvpzone == 1 then
		SetCVar("nameplateShowEnemies", 1)
		else
		SetCVar("nameplateShowEnemies", 0)
	end
end

function PVPZonePlates:InPvpZone()
	local pvptype = GetZonePVPInfo()
	if (pvptype == "arena" or pvptype == "combat" or UnitAffectingCombat("player") == 1) then
		return 1
	end
	local _, instancetype = IsInInstance()
	if instancetype == "pvp" then
		return 1
	end
end

PVPZonePlates:SetScript("OnEvent", PVPZonePlates.OnEvent)
PVPZonePlates:RegisterEvent("ADDON_LOADED")

--[[ Slash Commands and Help ]]--

SLASH_PVPZP1 = "/pvpzp"
SLASH_PVPZP2 = "/pvpzoneplates"

local function showHelp()
	print("  ")
	print("** PVPZP Help: **")
	print("(http://www.RhustyToyz.com)")
	print("***************************")
	print("/PVPZP           - returns this list")
	print("/PVPZP help      - returns this list")
	print("/PVPZP combat    - toggles ON during combat")
	print("/PVPZP verbose   - switch to VERBOSE mode (eg. msg output enabled)")
	print("/PVPZP quiet     - switch to QUIET mode (eg. no msg output)")
end

SlashCmdList["PVPZP"] = function (msg)
	local cmd, arg = strmatch(msg, "%s*([^%s]+)%s*(.*)");
	if cmd == nil or strlen(cmd) < 1 or cmd == "help" then
		showHelp()
		return
	end
	if (cmd ~= nil and strlen(cmd) > 1) then
		if cmd == "combat" then
			if PVPZonePlates_Combat_ON == 0
				then 
					PVPZonePlates_Combat_ON = 1 
					print("PVPZP - Nameplates <ON> during combat & in PVP Zones.")
					return
				else 
					PVPZonePlates_Combat_ON = 0 
					print("PVPZP - Nameplates <OFF> outside of PVP Zones.")
					return
			end
		elseif cmd == "verbose" then
			if PVPZonePlates_quiet == 0
				then
					PVPZonePlates_quiet = 1
					print("PVPZP - Verbose msg's <ON>.")
					return
				else
					print("PVPZP - Verbose mode already enabled.")
					return
			end
		elseif cmd == "quiet" then
			if PVPZonePlates_quiet == 0
				then
					print("PVPZP - Quiet mode already enabled.")
					return
				else
					PVPZonePlates_quiet = 0
					print("PVPZP - Silent running engaged.")
					return
			end
		elseif cmd == "DEBUG" then
			if PVPZP_DEBUG == 0
				then
					PVPZP_DEBUG = 1
					print("PVPZP - DEBUG MODE ON.")
					return
				else
					PVPZP_DEBUG = 0
					print("PVPZP - DEBUG MODE OFF.")
					return
			end
		else
			showHelp()
			return
		end
	end
end

SLASH_RELOAD1 = "/rl"
SlashCmdList["RELOAD"] = function(cmd)
	ReloadUI()
end	