
local addonName, addon = ...

local L = LibStub("AceLocale-3.0"):GetLocale(addonName, true)

addon.filters["Affordable Filter"] = {}
local filter = addon.filters["Affordable Filter"]


filter.affordablelist = {}
filter.notaffordablelist = {}
filter.resourceslist = {}
function filter:AddItem(link, i)
	if not next(filter.resourceslist) then
		-- expand all headers
		for j=GetCurrencyListSize(), 1, -1 do
			local name, isHeader, isExpanded, isUnused, isWatched, count, icon = GetCurrencyListInfo(j)
			if isHeader and not isExpanded then
				ExpandCurrencyList(j, 1)
			end
		end
		-- record all our recources
		for j=1, GetCurrencyListSize() do
			local name, isHeader, isExpanded, isUnused, isWatched, count, icon = GetCurrencyListInfo(j)
			if not isHeader then
				filter.resourceslist[name] = count
			end
		end
	end
	
	local _, _, price, _, _, _, extendedCost = addon.GetMerchantItemInfo_old(i)
	if price > GetMoney() then
		filter.notaffordablelist[link] = true
		return
	else
		for j=1, addon.GetMerchantItemCostInfo_old(i), 1 do
			local _, num, costlink, name = addon.GetMerchantItemCostItem_old(i, j)
			if (costlink or filter.resourceslist[name]) and ((costlink and num > GetItemCount(costlink)) or (name and num > filter.resourceslist[name])) then
				filter.notaffordablelist[link] = true
				return
			end
		end
		filter.affordablelist[link] = true
	end
end

--GetItemCount(select(3, GetMerchantItemCostItem(1,1)))

function filter:ClearAll()
	wipe(self.affordablelist)
	wipe(self.notaffordablelist)
	wipe(self.resourceslist)
	
	self.affordable = addon.db.profile.affordable
end

function filter:isFilterd(link, i)
	if self.affordable then
		return filter.notaffordablelist[link]
	else
		return false
	end
end

function filter:ResetFilter()
	self.affordable = addon.db.profile.affordable
end

function filter:ShowAll()
	self.affordable = false
end

function filter:FilterAll()
	if self:isRelevant() then
		self.affordable = true
	end
end

function filter:WriteDefault(db)
	db.profile.affordable = false
end

function filter:isRelevant() -- need to look into this one some more
	if next(filter.notaffordablelist) and next(filter.affordablelist) then
		return true
	else
		return false
	end
end

local info, itemtypesorted, itemtypesortedL = {}, {}, {}
function filter:GetDropdown(level)
	wipe(info)
	wipe(itemtypesorted)
	info.keepShownOnClick = 1
    if level == 1 then
		info.text = L['Affordable']
		info.checked = self.affordable
		info.isNotRadio = true
		info.func = function()
			self.affordable = not self.affordable
			ToggleDropDownMenu(1, nil, addon.FilterMenu, addon.FilterButton, 0, 0)
			ToggleDropDownMenu(1, nil, addon.FilterMenu, addon.FilterButton, 0, 0)
			addon:FilterUpdate()
		end
		UIDropDownMenu_AddButton(info, level)
	end
end

addon.filterOptions["Affordable Filter"] = {
	type = 'group',
	name = L["Affordable Filter"],
	args = {
		UIF = {
			name = L["Affordable Filter Default"],
			desc = L['When selected only items you can afford will be displayed initially!'],
			type = 'toggle',
			width = 'full',
			get = function(info)
				return addon.db.profile.affordable
			end,
			set = function(info, val)
				addon.db.profile.affordable = val
				filter:ResetFilter()
			end,
		},
	},
}