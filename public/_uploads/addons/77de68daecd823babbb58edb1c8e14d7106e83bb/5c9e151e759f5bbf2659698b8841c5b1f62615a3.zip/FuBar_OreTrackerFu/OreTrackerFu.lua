local Tablet = AceLibrary("Tablet-2.0")
local Dewdrop = AceLibrary("Dewdrop-2.0")
local Crayon = AceLibrary("Crayon-2.0")
local L = AceLibrary("AceLocale-2.2"):new("FuBar_OreTrackerFu")
local BM = AceLibrary("Babble-Mines-2.2");

OreTrackerFu = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceHook-2.1", "AceDB-2.0", "FuBarPlugin-2.0", "AceConsole-2.0")

OreTrackerFu:RegisterDB("OreTrackerFuDB")
OreTrackerFu:RegisterDefaults('realm', {
	chars = {
		['*'] = {
			compactText = false,
			displayOrder = "abc", -- "abc", "skill"
			displayEmpty = false,
			displayCount = 0,
			displayBank = true,
			displayOtherChars = true,
	
			Ores = {
				['*'] = { inv = 0, bank = 0, disp = false, },
			}
		}
	}
})

OreTrackerFu.displayOrder = {
	abc = {
		BM["Adamantite Bar"],
        BM["Adamantite Ore"],
        BM["Bronze Bar"],
        BM["Cobalt Bar"],
        BM["Cobalt Ore"],
        BM["Copper Bar"],
        BM["Copper Ore"],
        BM["Dark Iron Bar"],
        BM["Dark Iron Ore"],
        BM["Elementium Bar"],
        BM["Elementium Ingot"],
        BM["Elementium Ore"],
        BM["Enchanted Thorium Bar"],
        BM["Eternium Bar"],
        BM["Eternium Ore"],
        BM["Fel Iron Bar"],
        BM["Fel Iron Ore"],
        BM["Gold Bar"],
        BM["Gold Ore"],
        BM["Hardened Adamantite Bar"],
        BM["Hardened Elementium Bar"],
        BM["Hardened Saronite Bar"],
        BM["Iron Ore"],
        BM["Iron Bar"],
        BM["Khorium Bar"],
        BM["Khorium Ore"],
        BM["Mithril Bar"],
        BM["Mithril Ore"],
        BM["Obsidium Bar"],
        BM["Obsidium Ore"],
        BM["Primordial Saronite"],
        BM["Pyrite Bar"],
        BM["Pyrite Ore"],
        BM["Saronite Bar"],
        BM["Saronite Ore"],
        BM["Silver Ore"],
        BM["Silver Bar"],
        BM["Steel Bar"],
        BM["Thorium Bar"],
        BM["Thorium Ore"],
        BM["Tin Bar"],
        BM["Tin Ore"],
        BM["Titanium Bar"],
        BM["Titanium Ore"],
        BM["Titansteel Bar"],
        BM["Truesilver Bar"],
        BM["Truesilver Ore"],

	},
	
	skill = {
		-- ore
        -- Vanilla
        BM["Copper Ore"],
        BM["Copper Bar"],
        BM["Tin Ore"],
        BM["Tin Bar"],
        BM["Bronze Bar"],
        BM["Silver Ore"],
        BM["Silver Bar"],
        BM["Iron Ore"],
        BM["Iron Bar"],
        BM["Gold Ore"],
        BM["Gold Bar"],
        BM["Steel Bar"],
        BM["Mithril Ore"],
        BM["Mithril Bar"],
        BM["Dark Iron Ore"],
        BM["Dark Iron Bar"],
        BM["Truesilver Ore"],
        BM["Truesilver Bar"],
        BM["Thorium Ore"],
        BM["Thorium Bar"],
        BM["Enchanted Thorium Bar"],
        BM["Elementium Ingot"],
        BM["Hardened Elementium Bar"],       
        -- BC
        BM["Fel Iron Ore"],
        BM["Fel Iron Bar"],
        BM["Adamantite Ore"],
        BM["Adamantite Bar"],
        BM["Eternium Ore"],
        BM["Eternium Bar"],
        BM["Hardened Adamantite Bar"],
        BM["Khorium Ore"],
        BM["Khorium Bar"],
        -- WOTLK
        BM["Cobalt Ore"],
        BM["Cobalt Bar"],
        BM["Saronite Ore"],
        BM["Saronite Bar"],
        BM["Hardened Saronite Bar"],
        BM["Titanium Ore"],
        BM["Titanium Bar"],
        BM["Titansteel Bar"],
        BM["Primordial Saronite"],
        -- Cataclysm        
        BM["Obsidium Ore"],
        BM["Obsidium Bar"],
        BM["Elementium Ore"],
        BM["Elementium Bar"],
        BM["Pyrite Ore"],
        BM["Pyrite Bar"],
        


	},
}

OreTrackerFu.hasIcon = "Interface\\Icons\\Trade_mining";
OreTrackerFu.hasNoColor = true;

function OreTrackerFu:OnInitialize()
	self.bankOpened = false;
	self.charName = UnitName("player");
	
	if self.db.realm.chars[self.charName].order then
		self:ResetDB(); -- Old DB, reset it
	end
	
	--Debugger:RegisterFunction(self, "SaveInv");

	self:SaveInv();
end

function OreTrackerFu:OnEnable()
    self:RegisterEvents();
end

-- when player disable this addon .bug.
--function OreTrackerFu:OnDisable()
 --   self:UnRegisterEvents();
--end

function OreTrackerFu:OnMenuRequest(level, value)
	if level == 1 then
		Dewdrop:AddLine(
			'text', L["Display"],
			'hasArrow', true,
			'value', "display"
		)
		Dewdrop:AddLine(
			'text', L["Sort"],
			'hasArrow', true,
			'value', "displayOrder"
		)
		Dewdrop:AddLine(
			'text', L["Compact text"],
			'func', function()
						self.db.realm.chars[self.charName].compactText = not self.db.realm.chars[self.charName].compactText;
						self:UpdateText();
					end,
			'checked', self.db.realm.chars[self.charName].compactText
		)
		Dewdrop:AddLine(
			'text', L["Show empty stacks"],
			'func', function()
						self.db.realm.chars[self.charName].displayEmpty = not self.db.realm.chars[self.charName].displayEmpty;
					end,
			'checked', self.db.realm.chars[self.charName].displayEmpty
		)
		Dewdrop:AddLine(
			'text', L["Show bank"],
			'func', function()
						self.db.realm.chars[self.charName].displayBank = not self.db.realm.chars[self.charName].displayBank;
					end,
			'checked', self.db.realm.chars[self.charName].displayBank
		)
		Dewdrop:AddLine(
			'text', L["Show other chars"],
			'func', function()
						self.db.realm.chars[self.charName].displayOtherChars = not self.db.realm.chars[self.charName].displayOtherChars;
					end,
			'checked', self.db.realm.chars[self.charName].displayOtherChars
		)
		Dewdrop:AddLine('text', " ")
		
	elseif level == 2 then
		if value == "displayOrder" then
		    Dewdrop:AddLine(
		        'text', L["Alphabetically"],
		        'isRadio', true,
		        'func', function() self:SetdisplayOrder("abc") end,
		        'checked', self:IsdisplayOrder("abc")
		    )
		    Dewdrop:AddLine(
		        'text', L["Skill level"],
		        'isRadio', true,
		        'func', function() self:SetdisplayOrder("skill") end,
		        'checked', self:IsdisplayOrder("skill")
		    )
		    
		elseif value == "display" then
		    for i, Ore in pairs(self.displayOrder[self.db.realm.chars[self.charName].displayOrder]) do
		        Dewdrop:AddLine(
		            'text', Crayon:Yellow("[" .. L["short_" .. BM:GetReverseTranslation(Ore)] .. "] ") .. Ore,
		            'func', function(Ore) self:SetDisplayOre(Ore) end,
		            'arg1', Ore,
					'checked', self:IsDisplayOre(Ore)
		        )
		    end
		end
	end

end

function OreTrackerFu:OnTextUpdate()
	local text = "";
	if self.db.realm.chars[self.charName].displayCount > 0 then
     	for i, Ore in pairs(self.displayOrder[self.db.realm.chars[self.charName].displayOrder]) do
	        if self.db.realm.chars[self.charName].Ores[Ore].disp then
	        	local name;
	        	if self.db.realm.chars[self.charName].compactText then
	        		name = L["short_" .. BM:GetReverseTranslation(Ore)];
	        	else
	        		name = Ore;
	        	end
	            text = text .. " " .. Crayon:Yellow(name) .. " " .. Crayon:Colorize(Crayon:GetThresholdHexColor(self.db.realm.chars[self.charName].Ores[Ore].inv, 0, 5, 10, 15, 20), self.db.realm.chars[self.charName].Ores[Ore].inv);
			end
	    end
	    
	   -- text = string.gsub(text, "(%))(%s*)(%w+)", "%1 | %3");
	else
		if self.db.realm.chars[self.charName].compactText then
			text = "OT";
		else
			text = "OreTrackerFu";
		end	
	end
	
	self:SetText(text);
end

function OreTrackerFu:OnTooltipUpdate()
	local cat = Tablet:AddCategory('columns', self:CharsCount(self.db.realm.chars) + 1)
	
	if self.db.realm.chars[self.charName].displayOtherChars then cat:AddLine(self:TooltipCharsNames()); end
	for i, Ore in pairs(self.displayOrder[self.db.realm.chars[self.charName].displayOrder]) do
		if self.db.realm.chars[self.charName].displayEmpty or self:CharsHaveOre(Ore) then
			cat:AddLine(
    			'text', Crayon:Yellow(Ore),
				'justify', "LEFT",		
    			self:TooltipCharsOres(Ore)
			)
		end
	end
end

function OreTrackerFu:TooltipCharsNames()
	local res = {'text2', self.charName, 'justify2', "RIGHT"};
	local i = 3;
	
 	if self.db.realm.chars[self.charName].displayOtherChars then
		for char, _ in pairs(self.db.realm.chars) do
	    	if char ~= self.charName then
	   			table.insert(res, 'text' .. i);
	    		table.insert(res, char);
	    	
	    		table.insert(res, 'justify' .. i);
	    		table.insert(res, "RIGHT");
	    
	    		i = i + 1;
	    	end
		end
	end

	return unpack(res);
end

function OreTrackerFu:TooltipCharsOres(Ore)
	local res = {'text2', self:CountString(Ore), 'justify2', "RIGHT"};
	local i = 3;

	if self.db.realm.chars[self.charName].displayOtherChars then
		for char, _ in pairs(self.db.realm.chars) do
	    	if char ~= self.charName then
	    		tinsert(res, 'text' .. i);
	    		tinsert(res, self:CountString(Ore, char));
	    	    	
	    		table.insert(res, 'justify' .. i);
	    		table.insert(res, "RIGHT");
	    
	    		i = i + 1;
	    	end
		end
	end
	
	return unpack(res);
end

function OreTrackerFu:CharsHaveOre(Ore)
	if self.db.realm.chars[self.charName].Ores[Ore].inv > 0 or (self.db.realm.chars[self.charName].displayBank and self.db.realm.chars[self.charName].Ores[Ore].bank > 0) then
		return true;
	end
	
    if self.db.realm.chars[self.charName].displayOtherChars then
		for char, _ in pairs(self.db.realm.chars) do
			if self.db.realm.chars[char].Ores[Ore].inv > 0 or (self.db.realm.chars[char].displayBank and self.db.realm.chars[char].Ores[Ore].bank > 0) then
				return true;
			end
		end
	end
	
	return false;
end

function OreTrackerFu:CountString(Ore, char)
	return self:InvCountString(Ore, char) .. self:BankCountString(Ore, char);
end

function OreTrackerFu:BankCountString(Ore, char)
	local tempChar = self.db.realm.chars[self.charName];
	
	if char then
		tempChar = self.db.realm.chars[char];
	end
	
	if self.db.realm.chars[self.charName].displayBank then
		return Crayon:Yellow(" (") .. Crayon:Colorize(Crayon:GetThresholdHexColor(tempChar.Ores[Ore].bank, 0, 5, 10, 15, 20), tempChar.Ores[Ore].bank) .. Crayon:Yellow(")");
	else
		return ""
	end
end 

function OreTrackerFu:InvCountString(Ore, char)
	local tempChar = self.db.realm.chars[self.charName];
	
	if char then
		tempChar = self.db.realm.chars[char];
	end
	
	return Crayon:Colorize(Crayon:GetThresholdHexColor(tempChar.Ores[Ore].inv, 0, 5, 10, 15, 20), tempChar.Ores[Ore].inv); 
end 

function OreTrackerFu:SetdisplayOrder(displayOrder)
	self.db.realm.chars[self.charName].displayOrder = displayOrder;
	self:UpdateText();
end

function OreTrackerFu:IsdisplayOrder(displayOrder)
	return self.db.realm.chars[self.charName].displayOrder == displayOrder;
end

function OreTrackerFu:SetDisplayOre(Ore)
	self.db.realm.chars[self.charName].Ores[Ore].disp = not self.db.realm.chars[self.charName].Ores[Ore].disp;
	
	if self.db.realm.chars[self.charName].Ores[Ore].disp then
	    self.db.realm.chars[self.charName].displayCount = self.db.realm.chars[self.charName].displayCount + 1;
	else
	    self.db.realm.chars[self.charName].displayCount = self.db.realm.chars[self.charName].displayCount - 1;
	end
	
	self:UpdateText();
end

function OreTrackerFu:IsDisplayOre(Ore)
	return self.db.realm.chars[self.charName].Ores[Ore].disp;
end

function OreTrackerFu:RegisterEvents()
	self:RegisterEvent("BANKFRAME_OPENED", function() self.bankOpened = true; self:OnBankUpdate(); end);
	self:RegisterEvent("BANKFRAME_CLOSED", function() self.bankOpened = false; end);
	self:RegisterEvent("PLAYERBANKSLOTS_CHANGED", "OnBankUpdate");
	self:RegisterEvent("BAG_UPDATE", "OnBagUpdate");
end

function OreTrackerFu:OnBankUpdate()	
	self:SaveBank();
	--self:SaveInv();
	
	self:Update();
end

function OreTrackerFu:OnBagUpdate(arg1)
	if arg1 > 4 then
	    if BankFrame:IsVisible() then
			self:SaveBank();
		end
	else
		self:SaveInv();
	end
	
	self:Update();
end

function OreTrackerFu:NameFromLink(link)
	return string.match(link, "^|%x+|H.+|h%[(.+)%]");
end

function OreTrackerFu:GetItemQuantityFromInv(Ore)
	local bagSize
	local OreCount = 0;

	for bag = 4, 0, -1 do
		bagSize = GetContainerNumSlots(bag);
		if bagSize > 0 then
			for slot = 1, bagSize, 1 do
				local _, itemQuantity = GetContainerItemInfo(bag, slot);

				if itemQuantity then
					local itemName = OreTrackerFu:NameFromLink(GetContainerItemLink(bag, slot));
					
					if itemName and itemName ~= "" then

						if itemName == Ore then
							OreCount = OreCount + itemQuantity;
						end
					end
				end
			end
		end
	end
	return OreCount;
end

function OreTrackerFu:GetItemQuantityFromBank(Ore)
	local bankSlots, containerItemNum, bagNum, link, quantity, icon, itemName;
	local OreCount = 0;

	bankSlots = GetContainerNumSlots(BANK_CONTAINER);
	if bankSlots then
		for containerItemNum = 1, bankSlots do
			link = GetContainerItemLink(BANK_CONTAINER, containerItemNum);
			_, quantity = GetContainerItemInfo(BANK_CONTAINER, containerItemNum);
			if link then
				--LinkToName
				itemName = OreTrackerFu:NameFromLink(link);
				if itemName == Ore then
					OreCount = OreCount + quantity;
				end
			end
		end

		for bagNum = 5, 10 do
			bankSlots = GetContainerNumSlots(bagNum);
			if bankSlots then
				local id = BankButtonIDToInvSlotID(bagNum, 1);
				link = GetInventoryItemLink("player", id);
				icon = GetInventoryItemTexture("player", id);
				for containerItemNum = 1, bankSlots do
					link = GetContainerItemLink(bagNum, containerItemNum);
					icon, quantity = GetContainerItemInfo(bagNum, containerItemNum);
					if link then
						--LinkToName
						itemName = OreTrackerFu:NameFromLink(link);
						if itemName == Ore then
							OreCount = OreCount + quantity;
						end
					end
				end
			end
		end
	end
	
	if not self.bankOpened then
	    OreCount = self.db.realm.chars[self.charName].Ores[Ore].bank;
	end

	return OreCount;
end

function OreTrackerFu:SaveInv()
	for _, Ore in ipairs(self.displayOrder.abc) do
		self.db.realm.chars[self.charName].Ores[Ore].inv = OreTrackerFu:GetItemQuantityFromInv(Ore);
	end
end

function OreTrackerFu:SaveBank()
	for _, Ore in ipairs(self.displayOrder.abc) do
		self.db.realm.chars[self.charName].Ores[Ore].bank = OreTrackerFu:GetItemQuantityFromBank(Ore);
	end
end

function OreTrackerFu:CharsCount(tab)
   if not self.db.realm.chars[self.charName].displayOtherChars then return 1; end
   
   local n = 0;
   
   for _ in pairs(tab) do
     n = n + 1;
   end
   
   return n;
end
