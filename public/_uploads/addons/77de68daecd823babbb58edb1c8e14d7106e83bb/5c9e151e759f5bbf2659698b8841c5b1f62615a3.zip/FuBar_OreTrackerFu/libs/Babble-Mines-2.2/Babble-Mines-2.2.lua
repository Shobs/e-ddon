--[[
Name: Babble-Mines-2.2
Revision: $Rev: 81944 $
Authors(s): Unrak (ER-EU)(martin@grraids.net)
German Translations: Borschti
Website: www.wowace.com
Dependencies: AceLibrary, AceLocale-2.2
License: MIT
]]

local MAJOR_VERSION = "Babble-Mines-2.2"
local MINOR_VERSION = tonumber(string.sub("$Revision: 81944 $", 12, -3))

if not AceLibrary then error(MAJOR_VERSION .. " requires AceLibrary") end
if not AceLibrary:HasInstance("AceLocale-2.2") then error(MAJOR_VERSION .. " requires AceLocale-2.2") end

local _, x = AceLibrary("AceLocale-2.2"):GetLibraryVersion()
MINOR_VERSION = MINOR_VERSION * 100000 + x

if not AceLibrary:IsNewVersion(MAJOR_VERSION, MINOR_VERSION) then return end

local BabbleMines = AceLibrary("AceLocale-2.2"):new(MAJOR_VERSION)

BabbleMines:RegisterTranslations("enUS", function() return {
	
-- ore
    ["Adamantite Bar"] = true,
    ["Adamantite Ore"] = true,
    ["Bronze Bar"] = true,
    ["Cobalt Bar"] = true,
    ["Cobalt Ore"] = true,
    ["Copper Bar"] = true,
    ["Copper Ore"] = true,
    ["Dark Iron Bar"] = true,
    ["Dark Iron Ore"] = true,
    ["Elementium Bar"] = true,
    ["Elementium Ingot"] = true,
    ["Elementium Ore"] = true,
    ["Enchanted Thorium Bar"] = true,
    ["Eternium Bar"] = true,
    ["Eternium Ore"] = true,
    ["Fel Iron Bar"] = true,
    ["Fel Iron Ore"] = true,
    ["Gold Bar"] = true,
    ["Gold Ore"] = true,
    ["Hardened Adamantite Bar"] = true,
    ["Hardened Saronite Bar"] = true,
    ["Hardened Elementium Bar"] = true,
    ["Iron Ore"] = true,
    ["Iron Bar"] = true,
    ["Khorium Bar"] = true,
    ["Khorium Ore"] = true,
    ["Mithril Bar"] = true,
    ["Mithril Ore"] = true,
    ["Obsidium Bar"] = true,
    ["Obsidium Ore"] = true,
    ["Primordial Saronite"] = true,
    ["Pyrite Bar"] = true,
    ["Pyrite Ore"] = true,
    ["Saronite Bar"] = true,
    ["Saronite Ore"] = true,
    ["Silver Ore"] = true,
    ["Silver Bar"] = true,
    ["Steel Bar"] = true,
    ["Thorium Bar"] = true,
    ["Thorium Ore"] = true,
    ["Tin Bar"] = true,
    ["Tin Ore"] = true,
    ["Titanium Bar"] = true,
    ["Titanium Ore"] = true,
    ["Titansteel Bar"] = true,
    ["Truesilver Bar"] = true,
    ["Truesilver Ore"] = true,

      
    
} end)
BabbleMines:RegisterTranslations("deDE", function() return {
	
-- Erz
    ["Adamantite Bar"] = "Adamantitbarren",
    ["Adamantite Ore"] = "Adamantiterz",
    ["Bronze Bar"] = "Bronzebarren",
    ["Cobalt Bar"] = "Kobaltbarren",
    ["Cobalt Ore"] = "Kobalterz",
    ["Copper Bar"] = "Kupferbarren",
    ["Copper Ore"] = "Kupfererz",
    ["Dark Iron Bar"] = "Dunkeleisenbarren",
    ["Dark Iron Ore"] = "Dunkeleisenerz",
    ["Elementium Bar"] = "Elementiumbarren",
    ["Elementium Ingot"] = "Elementiumblock",
    ["Elementium Ore"] = "Elementiumerz",
    ["Enchanted Thorium Bar"] = "Verzauberter Thoriumbarren",
    ["Eternium Bar"] = "Eterniumbarren",
    ["Eternium Ore"] = "Eterniumerz",
    ["Fel Iron Bar"] = "Teufelseisenbarren",
    ["Fel Iron Ore"] = "Teufelseisenerz",
    ["Gold Bar"] = "Goldbarren",
    ["Gold Ore"] = "Golderz",
    ["Hardened Adamantite Bar"] = "gehaerteter Adamantitbarren",
    ["Hardened Saronite Bar"] = "geh\195\164rteter Saronitbarren",
    ["Hardened Elementium Bar"] = "geh\195\164rteter Elementiumblock",
    ["Iron Ore"] = "Eisenerz",
    ["Iron Bar"] = "Eisenbarren",
    ["Khorium Bar"] = "Khoriumbarren",
    ["Khorium Ore"] = "Koriumerz",
    ["Mithril Bar"] = "Mithrilbarren",
    ["Mithril Ore"] = "Mithrilerz",
    ["Obsidium Bar"] = "Obsidiumbarren",
    ["Obsidium Ore"] = "Obsidiumerz",
    ["Primordial Saronite"] = "Urt\195\188mliches Saronit",
    ["Pyrite Bar"] = "Pyritbarren",
    ["Pyrite Ore"] = "Pyriterz",
    ["Saronite Bar"] = "Saronitbarren",
    ["Saronite Ore"] = "Saroniterz",
    ["Silver Ore"] = "Silbererz",
    ["Silver Bar"] = "Silberbarren",
    ["Steel Bar"] = "Stahlbarren",
    ["Thorium Bar"] = "Thoriumbarren",
    ["Thorium Ore"] = "Thoriumerz",
    ["Tin Bar"] = "Zinnbarren",
    ["Tin Ore"] = "Zinnerz",
    ["Titanium Bar"] = "Titanbarren",
    ["Titanium Ore"] = "Titanerz",
    ["Titansteel Bar"] = "Titanstahlbarren",
    ["Truesilver Bar"] = "Echtsilberbarren",
    ["Truesilver Ore"] = "Echtsilbererz",
} end)

BabbleMines:Debug()
BabbleMines:SetStrictness(true)

AceLibrary:Register(BabbleMines, MAJOR_VERSION, MINOR_VERSION)
BabbleMines = nil