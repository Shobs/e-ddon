local L = AceLibrary("AceLocale-2.2"):new("FuBar_OreTrackerFu");

L:RegisterTranslations("enUS", function() return {
    -- ore
    -- Vanilla
    ["short_Copper Ore"] = 		    "CoP",
    ["short_Copper Bar"] =		    "CoPB",
    ["short_Tin Ore"] =		    "TiO",
    ["short_Tin Bar"] =		        "TiB",
    ["short_Bronze Bar"] =		    "BrO",
    ["short_Silver Ore"] = 	    "SilO",
    ["short_Silver Bar"] = 		    "SilB",
    ["short_Iron Ore"] =		    "IrnO",
    ["short_Iron Bar"] = 		    "IrnB",
    ["short_Gold Ore"] = 		    "GoO",
    ["short_Gold Bar"] =		    "GoB",
    ["short_Steel Bar"] = 		    "StB",
    ["short_Mithril Ore"] = 		"MiO",
    ["short_Mithril Bar"]= 		"MiB",
    ["short_Dark Iron Ore"] = 	    "DiO",
    ["short_Dark Iron Bar"] = 	    "DiB",
    ["short_Truesilver Ore"] = 	    "TsO",
    ["short_Truesilver Bar"] = 	    "TsB",
    ["short_Thorium Ore"] = 	    "ThO",
    ["short_Thorium Bar"] = 		"ThB",
    ["short_Enchanted Thorium Bar"]= "ETB",
    ["short_Hardened Elementium Bar"] = "HEB",
    ["short_Elementium Ingot"] = "ElI",
   
    -- BC
    ["short_Fel Iron Ore"] =		"FIO",
    ["short_Fel Iron Bar"] = 		"FIB",
    ["short_Adamantite Ore"] = 	    "AdO",
    ["short_Adamantite Bar"] = 	    "AdB",
    ["short_Eternium Ore"] = 	    "EteO",
    ["short_Eternium Bar"] = 	    "EtoB",
    ["short_Hardened Adamantite Bar"] = "HAB",
    ["short_Khorium Ore"] = 	    "KhO",
    ["short_Khorium Bar"] = 		"KhB",
    
    -- WOTLK
    ["short_Cobalt Ore"] = 		    "CoO",
    ["short_Cobalt Bar"] = 		    "CoB",
    ["short_Saronite Ore"] = 	    "SaO",
    ["short_Saronite Bar"] = 		"SaB",
    ["short_Hardened Saronite Bar"] = "HSB",
    ["short_Titanium Ore"] = 	    "TitO",
    ["short_Titanium Bar"] = 	    "TitB",
    ["short_Titansteel Bar"] = 	    "TSB",
    ["short_Primordial Saronite"] = "PriS",
    
    -- Cataclysm
    ["short_Elementium Ore"] = 	    "EleO",
    ["short_Elementium Bar"] = 	    "EleB",
    ["short_Obsidium Bar"] =      "ObsB",
    ["short_Obsidium Ore"] =        "ObsO",
    ["short_Pyrite Bar"] =          "PyB",
    ["short_Pyrite Ore"] =          "PyO",
    

    
	["Display"] = true,
	["Sort"] = true,
	["Compact text"] = true,
	["Show empty stacks"] = true,
	["Show other chars"] = true,
	["Show bank"] = true,
	["Alphabetically"] = true,
	["Skill level"] = true,
} end)