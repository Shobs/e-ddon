function EventHorizon:InitializeClass()
 
 self.config.gcdSpellID = 48623
 
 -- General rotation
--DOTS
 -- Icy Touch
 self:NewSpell({
  spellID = 55095,
  debuff = true,
  refreshable = true,
  dot = 3,
 })
 
 -- Plague Strike
 self:NewSpell({
  spellID = 55078,
  debuff = true,
  refreshable = true,
  dot = 3,
 })
  
-- WEAPON ENCHANTS
 -- Unholy Strength (Fallen Crusader proc)
 self:NewSpell({
  spellID = 53365,
  playerbuff = true,
  requiredTree = {2,3},
 })
 -- Frost Vulnerability (Razorice debuff)
-- self:NewSpell({
--  spellID = 51714,
--  debuff = true,
-- })
 -- Cinderglacier
-- self:NewSpell({
--  spellID = 53386,
--  playerbuff = true,
-- })
 -- Soul Reaper debuff
 self:NewSpell({
  spellID = 114867,
  debuff = true,
  dot = 5,
  requiredLevel = 87,
 })
 
  
 -- Blood tree (no requiredTalent entries until trees are more solid)
 
 -- Rune Tap
-- self:NewSpell({
--  spellID = 48982,
--  cooldown = true,
--  requiredTree = 1,
-- })
 
 -- Bone Shield
 self:NewSpell({
  spellID = 49222,
  playerbuff = true,
  cooldown = true,
  requiredTree = 1,
 })
 
 -- Will of the Necropolis
 self:NewSpell({
  spellID = 81164,
  playerbuff = true,
  requiredTree = 1,
 })
 
 -- Scent of Blood
 self:NewSpell({
  spellID = 50421,
  playerbuff = true,
  requiredTree = 1,
 })
 
 
 -- Dancing Rune Weapon
-- self:NewSpell({
--  spellID = 49028,
--  cooldown = true,
--  requiredTree = 1,
-- })
 
 -- Frost tree (again, no requiredTalents yet)
 
 -- Killing Machine
 self:NewSpell({
  spellID = 51124,
  playerbuff = true,
  requiredTree = 2,
 })
 
 -- Rime
 self:NewSpell({
  spellID = 59052,
  playerbuff = true,
  requiredTree = 2,
 })
 
 -- Pillar of Frost
 self:NewSpell({
  spellID = 51271,
  playerbuff = true,
  cooldown = true,
  requiredTree = 2,
 })
 
 -- Unholy tree
 
 -- Sudden Doom
 self:NewSpell({
  spellID = 81340,
  playerbuff = true,
  requiredTree = 3,
 })
 
 -- Shadow Infusion + Dark Transformation (Yes, they're exclusive)
 self:NewSpell({
  spellID = 91342,
  playerbuff = {91342,63560},
  auraunit = 'pet',
  requiredTree = 3,
 })
 --Unholy Frenzy
 self:NewSpell({
  spellID = 49016,
  playerbuff = true,
  requiredTree = 3,
 })
end