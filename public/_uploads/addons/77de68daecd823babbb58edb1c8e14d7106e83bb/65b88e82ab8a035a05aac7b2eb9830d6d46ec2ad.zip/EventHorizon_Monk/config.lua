local usemouseover = true	-- Make this false or nil (or just delete the line altogether) to make your healing bars not change when you mouse over something.

function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 115921 -- Legacy of the Emperor
	self.config.hastedSpellID = {115178,10} -- Resuscitate

	-- Mistweaver

	--Soothing Mist
	self:NewSpell({
		spellID = 115175,
		refreshable = true,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		hasted = true,
		requiredTree = 2,
		requiredLevel = 10,
	})

	--Renewing Mist
	self:NewSpell({
		spellID = 115151,
		refreshable = true,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		hasted = true,
		cooldown = true,
		requiredTree = 2,
		requiredLevel = 10,
	})
	
	--Enveloping Mist
	self:NewSpell({
		spellID = 124682,
		cast = {124682,116694},
		refreshable = true,
		playerbuff = true,
		auraunit = usemouseover and 'mouseover' or 'target',
		hasted = true,
		requiredTree = 2,
		requiredLevel = 10,
	})

	--Mana Tea
	self:NewSpell({
		spellID = 115867,
		playerbuff = true,
		cooldown = 123761,
		cast = true,
		channeled = true,
		requiredTree = 2,
		requiredLevel = 58,
	})
	
	--Second tier talents (mouseover target)
	self:NewSpell({
		spellID = 124081,
		playerbuff = true,
		cooldown = {115098,124081},
		auraunit = usemouseover and 'mouseover' or 'target',
		cast = 123986,
		requiredLevel = 30,
		requiredTree = 2,
	})

	--Windwalker
	
	--Tiger Power
	self:NewSpell({
		spellID = 125359,
		playerbuff = true,
		requiredTree = 3,
		requiredLevel = 10,
	})
	
	--Rising Sun Kick
	self:NewSpell({
		spellID = 107428,
		cooldown = true,
		debuff = true,
		requiredTree = 3,
		requiredLevel = 10,
	})
	
	--Fist of Fury + Spinning Crane Kick
	self:NewSpell({
		spellID = 113656,
		cooldown = true,
		playerbuff = 101546,
		channeled = true,
		requiredTree = 3,
		requiredLevel = 10,
	})
	
	--Tigereye Brew
	self:NewSpell({
		spellID = 125195,
		playerbuff = true,
		requiredTree = 3,
		requiredLevel = 60,
	})
	--Brewmaster
	
	--Blackout kick+Guard
	self:NewSpell ({
		spellID = 115307,
		playerbuff = true,
		cooldown = 115295,
		requiredTree = 1,
		requiredLevel = 7,
	})	
	
	--Dizzying Haze+Keg Smash
	self:NewSpell ({
		spellID = 115180,
		debuff = true,
		cooldown = 121253,
		requiredTree = 1,
		requiredLevel = 10,
	})	
	
	--Expel Harm+Tiger Palm
	self:NewSpell ({
		spellID = 125359,
		playerbuff = true,
		cooldown = 115072,
		requiredTree = 1,
		requiredLevel = 3,
	})
		
	--General
	
	--Second tier talents
	self:NewSpell({
		spellID = 124081,
		playerbuff = true,
		cooldown = {115098,124081},
		cast = 123986,
		requiredLevel = 30,
		requiredTree = {1,3},
	})
end