function EventHorizon:InitializeClass()
	self.config.gcdSpellID = 1752
	
	-- General
	
	-- Slice and Dice
	self:NewSpell({
		spellID = 5171,
		playerbuff = true,
		refreshable = true,
		requiredLevel = 22,
	})
	
	-- Rupture
	self:NewSpell({
		spellID = 1943,
		debuff = true,
		dot = 2,
		refreshable = true,
		requiredTree = {1,3},
		requiredLevel = 46,
	})
	
	-- Assassination
	
	-- Envenom
	self:NewSpell({
		spellID = 32645,
		playerbuff = true,
		requiredTree = 1,
		requiredLevel = 54,
	})
	
	-- Vendetta
	self:NewSpell({
		spellID = 79140,
		debuff = true,
		cooldown = true,
		requiredTree = 1,
		requiredLevel = 80,
	})
	
	-- Combat
	
	-- Revealing Strike
	self:NewSpell({
		spellID = 84617,
		debuff = true,
		requiredTree = 2,
		requiredLevel = 29,
	})
	
	-- Killing Spree
	self:NewSpell({
		spellID = 51690,
		playerbuff = true,
		cooldown = true,
		requiredTree = 2,
		requiredLevel = 69,
	})
	
	-- Adrenaline Rush
	self:NewSpell({
		spellID = 13750,
		playerbuff = true,
		cooldown = true,
		requiredTree = 2,
		requiredLevel = 49,
	})
	
	-- Subtlety
	
	-- Hemo
	self:NewSpell({
		spellID = 16511,
		debuff = true,
		refreshable = true,
		requiredTree = 3,
		requiredLevel = 29,
	})
	
	-- Shadow Dance
	self:NewSpell({
		spellID = 51713,
		playerbuff = true,
		cooldown = true,
		requiredTree = 3,
		requiredLevel = 69,
	})
	
	-- Vanish
	self:NewSpell({
		spellID = 1856,
		playerbuff = true,
		cooldown = true,
		requiredTree = 3, -- comment out to enable for all specs
		requiredLevel = 34,
	})
	
	-- Common
	
	-- Shadow Blades
	self:NewSpell({
		spellID = 121471,
		playerbuff = true,
		cooldown = true,
		requiredLevel = 87,
	})
	
	--[[ Disabled
	]]--
end