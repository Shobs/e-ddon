--	Auction Profit v1.4
--	Addon to calculate all posted auctions for Bid and Buyout price and integrate into Auction Frame
--  Written by Holygra�l - Terokkar (EU)
--  http://eu.battle.net/wow/en/character/terokkar/Holygra�l/advanced


function AP_Calc()
  local total = 0
  local sumBuyoutPrices = 0
  local sumBidPrices = 0
  local bid = 0
  local _,count = GetNumAuctionItems("owner");
  local rate = GetAuctionHouseDepositRate();
  if rate == 5 then rate = .95 else rate = .85 end
  if AP_SubtractAHCut == 0 then rate = 1 end
  
    for i = 1, GetNumAuctionItems("owner") do
    local _, _, _, _, _, _, minBid, _, buyoutPrice, bidAmount, _, _ = GetAuctionItemInfo("owner", i);
        if select(4, GetBuildInfo()) >= 40300 then -- fix for added paramter in 4.3
            sumBuyoutPrices = sumBuyoutPrices + select(10, GetAuctionItemInfo("owner", i))
        else
            sumBuyoutPrices = sumBuyoutPrices + select(9, GetAuctionItemInfo("owner", i))
        end

    if bidAmount == 0  then 
      bid = bid + floor((minBid*rate)+.5)
    else
      bid = bid + floor((bidAmount*rate)+.5)
    end
    sumBidPrices = sumBidPrices + bid
    bid = 0
  end
  if AP_ShowBO == 1 then
    if AP_ShowBid == 1 then
      AP_UMF( "AP_Buy_MoneyFrame", "/  Buyout:", sumBuyoutPrices)
    else
      AP_UMF( "AP_Buy_MoneyFrame", "Auction Profit - Buyout:", sumBuyoutPrices)
    end
  end
  
  if AP_ShowBid == 1 then
    AP_UMF( "AP_Bid_MoneyFrame", "Auction Profit - Bid:", sumBidPrices)
  end

end

function AP_CMF(frameName, nextTo)
	local frame = CreateFrame("Button",frameName,AuctionFrameAuctions)
	frame:SetPoint("RIGHT",nextTo,"LEFT",-5,0)
	frame:SetWidth(100)
	frame:SetHeight(18)

	local goldIcon = frame:CreateTexture(frameName.."GoldIcon", "ARTWORK")
	goldIcon:SetWidth(16)
	goldIcon:SetHeight(16)
	goldIcon:SetTexture("Interface\\MoneyFrame\\UI-MoneyIcons")
	goldIcon:SetTexCoord(0, 0.25, 0, 1)

	local silverIcon = frame:CreateTexture(frameName.."SilverIcon", "ARTWORK")
	silverIcon:SetWidth(16)
	silverIcon:SetHeight(16)
	silverIcon:SetTexture("Interface\\MoneyFrame\\UI-MoneyIcons")
	silverIcon:SetTexCoord(0.25, 0.5, 0, 1)

	local copperIcon = frame:CreateTexture(frameName.."CopperIcon", "ARTWORK")
	copperIcon:SetWidth(16)
	copperIcon:SetHeight(16)
	copperIcon:SetTexture("Interface\\MoneyFrame\\UI-MoneyIcons")
	copperIcon:SetTexCoord(0.5, 0.75, 0, 1)

	local goldText = frame:CreateFontString(frameName.."GoldText", "OVERLAY")
	goldText:SetJustifyH("RIGHT")
	goldText:SetPoint("RIGHT", goldIcon, "LEFT", 0, 0)
	goldText:SetFontObject(GameFontNormal)

	local silverText = frame:CreateFontString(frameName.."SilverText", "OVERLAY")
	silverText:SetJustifyH("RIGHT")
	silverText:SetPoint("RIGHT", silverIcon, "LEFT", 0, 0)
	silverText:SetFontObject(GameFontNormal)

	local copperText = frame:CreateFontString(frameName.."CopperText", "OVERLAY")
	copperText:SetJustifyH("RIGHT")
	copperText:SetPoint("RIGHT", copperIcon, "LEFT", 0, 0)
	copperText:SetFontObject(GameFontNormal)

	copperIcon:SetPoint("RIGHT", frame, "RIGHT")
	silverIcon:SetPoint("RIGHT", copperText, "LEFT")
	goldIcon:SetPoint("RIGHT", silverText, "LEFT")

	local TypeText = frame:CreateFontString(frameName.."TypeText", "OVERLAY")
	TypeText:SetJustifyH("RIGHT")
	TypeText:SetPoint("RIGHT", goldText, "LEFT", 0, 0)
	TypeText:SetFontObject(GameFontNormal)


	frame:Hide()
end


function AP_UMF( frameName, TextValue, value )

	local copper = value
	local gold = floor(copper / 10000)
	local silver = mod(floor(copper / 100), 100)
	copper = mod(copper, 100)
		
	local width = 0

    local TypeText = getglobal(frameName.."TypeText");
	TypeText:Show()
	TypeText:SetWidth(0)
	TypeText:SetText(TextValue)
	width = width + TypeText:GetWidth()
	
	local GoldIcon = getglobal(frameName.."GoldIcon");
	local GoldText = getglobal(frameName.."GoldText");
	GoldIcon:Show()
	GoldText:Show()
	GoldText:SetWidth(0)
	GoldText:SetText(gold)
	width = width + GoldIcon:GetWidth() + GoldText:GetWidth()

	local SilverIcon = getglobal(frameName.."SilverIcon");
	local SilverText = getglobal(frameName.."SilverText");
	SilverIcon:Show()
	SilverText:Show()
	SilverText:SetWidth(0)
	SilverText:SetText(silver)
	width = width + SilverIcon:GetWidth() + SilverText:GetWidth()

	local CopperIcon = getglobal(frameName.."CopperIcon");
	local CopperText = getglobal(frameName.."CopperText");
	CopperIcon:Show()
	CopperText:Show()
	CopperText:SetWidth(0)
	CopperText:SetText(copper)
	width = width + CopperIcon:GetWidth() + CopperText:GetWidth()
	
	local MoneyFrame = getglobal(frameName);
	MoneyFrame:SetWidth(width)
end

function AP_ShowHide_BO_Button(value)
  if value == 1 then
    if AP_ShowBid == 1 then
      AP_Bid_MoneyFrame:SetPoint("RIGHT",AP_Buy_MoneyFrame,"LEFT",-5,0)
    end
    AP_Buy_MoneyFrame:Show()
  else
   AP_Buy_MoneyFrame:Hide()
    if AP_ShowBid == 1 then
      AP_Bid_MoneyFrame:SetPoint("RIGHT",AuctionsCancelAuctionButton,"LEFT",-5,0)
    end
  end
end

function AP_ShowHide_Bid_Button(value)
  if value == 1 then
    if AP_ShowBO == 1 then
      AP_Bid_MoneyFrame:SetPoint("RIGHT",AP_Buy_MoneyFrame,"LEFT",-5,0)
    else
      AP_Bid_MoneyFrame:SetPoint("RIGHT",AuctionsCancelAuctionButton,"LEFT",-5,0)
    end
    AP_Bid_MoneyFrame:Show()
  else
    AP_Bid_MoneyFrame:Hide()
  end
end

function AP_CreateButtons()
  AP_CMF("AP_Buy_MoneyFrame","AuctionsCancelAuctionButton");
  AP_CMF("AP_Bid_MoneyFrame","AP_Buy_MoneyFrame");
  AP_ShowHide_BO_Button(AP_ShowBO)
  AP_ShowHide_Bid_Button(AP_ShowBid)
  AP_Calc();
end

function AP_SlashCmd(APcmd)
  if (APcmd=="") then
    DEFAULT_CHAT_FRAME:AddMessage("Useage:");
    DEFAULT_CHAT_FRAME:AddMessage("/ap Cut -Toggles AH Cut on or off");
    DEFAULT_CHAT_FRAME:AddMessage("/ap BO - Toggles BO Total on or off");
    DEFAULT_CHAT_FRAME:AddMessage("/ap Bid - Toggles Bid Total on or off");
  end

  if (string.lower(APcmd)=="cut") then
    if AP_SubtractAHCut == 1 then
      AP_SubtractAHCut = 0
      DEFAULT_CHAT_FRAME:AddMessage("|cFFffd700Auction_Profit:|rAH Cut turned |cFFFF0000off|r")
    else
      AP_SubtractAHCut = 1
      DEFAULT_CHAT_FRAME:AddMessage("|cFFffd700Auction_Profit:|rAH Cut turned |cFF00FF00on|r")
    end
    AP_Calc();
  end
  
  if (string.lower(APcmd)=="bo") then
    if AP_ShowBO == 1 then
      AP_ShowBO = 0
      DEFAULT_CHAT_FRAME:AddMessage("|cFFffd700Auction_Profit:|rBuyout Totals turned |cFFFF0000off|r")
    else
      AP_ShowBO = 1
      DEFAULT_CHAT_FRAME:AddMessage("|cFFffd700Auction_Profit:|rBuyout Totals turned |cFF00FF00on|r")
    end
    AP_ShowHide_BO_Button(AP_ShowBO)
    AP_Calc();
  end

  if (string.lower(APcmd)=="bid") then
    if AP_ShowBid == 1 then
      AP_ShowBid = 0
      DEFAULT_CHAT_FRAME:AddMessage("|cFFffd700Auction_Profit:|rBid Totals turned |cFFFF0000off|r")
    else
      AP_ShowBid = 1
      DEFAULT_CHAT_FRAME:AddMessage("|cFFffd700Auction_Profit:|rBid Totals turned |cFF00FF00on|r")
    end
    AP_ShowHide_Bid_Button(AP_ShowBid)
    AP_Calc();
  end

end

function AP_OnEvent(self,event)
  if event == "AUCTION_HOUSE_SHOW" then
    if AP_ButtonsLoaded == 1 then
      AP_Calc();
    else
      AP_CreateButtons();
      AP_ButtonsLoaded = 1
    end
  elseif event == "AUCTION_OWNED_LIST_UPDATE" then
    AP_Calc();
  end
end

  AP_SubtractAHCut = 1
  AP_ShowBid = 1
  AP_ShowBO = 1
  AP_ButtonsLoaded = 0

	local frame = CreateFrame("Frame","Auction_ProfitFrame")
  frame:SetScript("OnEvent", AP_OnEvent);
  frame:RegisterEvent("AUCTION_HOUSE_SHOW");
  frame:RegisterEvent("AUCTION_OWNED_LIST_UPDATE");
 

  SLASH_Auction_Profit1 = "/Auction_Profit";
  SLASH_Auction_Profit2 = "/AP";
  SlashCmdList["Auction_Profit"] = function (msg) AP_SlashCmd(msg) end;