local FRAME_STATE_BLIZZ = 1
local FRAME_STATE_MAIN = 2

function BlizzArt_GetCurrentState(frame)
	local selectedSkin = BlizzArt_SVPC[frame:GetName()]
	if selectedSkin then
		return FRAME_STATE_BLIZZ
	else
		return FRAME_STATE_MAIN
	end
end

function BlizzArt_ValidateTransition(frame)
	local CURRENT_FRAME_STATE = BlizzArt_GetCurrentState(frame)
	
	if frame.hideOnFinish then
		frame:Hide()
	end
	if frame.stopOnFinish then
		return
	end
	
	if CURRENT_FRAME_STATE == FRAME_STATE_MAIN then
		if not frame:IsShown() and frame == BlizzActionBar then
			BlizzActionBar_SetupMain()
			BlizzArt_BeginTransition(frame, 1, 1)
		elseif frame:IsShown() and frame == BlizzActionBar then
			BlizzArt_BeginTransition(frame, nil, nil)
		elseif frame:IsShown() then
			BlizzArt_BeginTransition(frame, nil, 1)
		end
	elseif CURRENT_FRAME_STATE == FRAME_STATE_BLIZZ then
		if not frame:IsShown() then
			BlizzArt_SetSkin(frame)
			BlizzArt_BeginTransition(frame, 1, 1)
		elseif frame:IsShown() then
			BlizzArt_BeginTransition(frame, nil, nil)
		end
	end
end

function BlizzArt_BeginTransition(frame, animIn, animStop)
	BlizzArt_PlaySound(animIn)
	frame:Show()
	frame.hideOnFinish = not animIn
	frame.stopOnFinish = animStop
	frame.anim:Play(animIn)
end

function BlizzArt_PlaySound(animIn)
	if not BlizzActionBar.anim:IsPlaying() then
		if animIn then
			PlaySound("AchievementMenuOpen")
		else
			PlaySound("igMiniMapClose")
		end
	end
end

function BlizzArt_SetSkin(frame)
	local textureFile = "Interface\\AddOns\\BlizzArtUI\\Texture\\%s"
	local skin = BlizzArt_SVPC[frame:GetName()]
	for _, texture in pairs(frame.textureList) do
		frame[texture]:SetTexture(textureFile:format(skin), strsub(texture, 1, 1) == "_")
	end	
	if frame == BlizzActionBar and not IsBlizzActionBarState() then
		BlizzActionBar_Setup()
	end
end