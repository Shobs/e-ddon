local textureList = {
	"_BG",
	"EndCapL",
	"EndCapR",
	"_Boarder",
	"Divider1",
	"Divider2",
	"Divider3",
	"MicroBGL",
	"MicroBGR",
	"_MicroBGMid",
	"ButtonBGL",
	"ButtonBGR",
	"_ButtonBGMid",
	"BagBGL",
	"BagBGR",
	"_BagBGMid",
	"PageOverlay",
	"PageButtonBG",
	"PageBG",
	"PageMarker",
	"PageUpUp",
	"PageUpDown",
	"PageUpHighlight",
	"PageDownUp",
	"PageDownDown",
	"PageDownHighlight",
	"HealthBarBG1",
	"HealthBarBG2",
	"HealthBarOverlay",
	"PowerBarBG1",
	"PowerBarBG2",
	"PowerBarOverlay",
	"_XpMid",
	"XpL",
	"XpR",
}

function BlizzActionBar_OnLoad(self)
	--Setup the XP bar
	for i=1,19 do
		local texture = self.xpBar:CreateTexture("BlizzActionBarXpDiv"..i, "OVERLAY", nil, 2)
		texture:SetSize(7, 14)
		texture:SetTexCoord(0.2773438, 0.2910156, 0.390625, 0.4179688)
		self.xpBar["XpDiv"..i] = texture
		self["XpDiv"..i] = texture
		textureList[#textureList + 1] = "XpDiv"..i
	end
	self.textureList = textureList
		
	--Add PageUp button Textures
	self["PageUpUp"] = self.PageUpButton:GetNormalTexture()
	self["PageUpDown"] = self.PageUpButton:GetPushedTexture()
	self["PageUpHighlight"] = self.PageUpButton:GetHighlightTexture()
	
	--Add PageDown button Textures
	self["PageDownUp"] = self.PageDownButton:GetNormalTexture()
	self["PageDownDown"] = self.PageDownButton:GetPushedTexture()
	self["PageDownHighlight"] = self.PageDownButton:GetHighlightTexture()
	
	self:RegisterEvent("PLAYER_LOGIN")
	self:RegisterEvent("PLAYER_LEVEL_UP")
	self:RegisterEvent("UPDATE_FACTION")
	self:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
	
	hooksecurefunc("UIParent_ManageFramePosition", BlizzActionBar_ManageFramePosition)
	hooksecurefunc("MoveMicroButtons", BlizzActionBar_MoveMicroButtons)
end

function BlizzActionBar_OnEvent(self, event, ...)
	if event == "PLAYER_LOGIN" then
		BlizzActionBar_SetupAnim()
		BlizzActionBar_SetSkin()
		BlizzActionBar_UpdateStatusBars()
		BlizzActionBar_SetPageValue(GetActionBarPage())
	elseif event == "PLAYER_LEVEL_UP" then
		BlizzActionBar_UpdateXpBar()
	elseif event == "UPDATE_FACTION" then
		BlizzActionBar_UpdateXpBar()
	elseif event == "ACTIONBAR_PAGE_CHANGED" then
		BlizzActionBar_SetPageValue(GetActionBarPage())
	end
end

function BlizzActionBar_SetSkin()
	local textureFile = "Interface\\AddOns\\BlizzArtUI\\Texture\\%s"
	local selectedSkin = BlizzArt_SVPC["BlizzActionBar"]
	if selectedSkin then
		for _, texture in pairs(BlizzActionBar.textureList) do
			BlizzActionBar[texture]:SetTexture(textureFile:format(selectedSkin), strsub(texture, 1, 1) == "_")
		end
		BlizzActionBar_Setup()
	else
		BlizzActionBar_SetupMain()
	end
end

function BlizzActionBar_CalcSize()
	local width, xpWidth, anchor, buttonAnchor
	local hasPage = BlizzArt_SVPC.hasPageBar
	local hasBag = BlizzArt_SVPC.hasBagSlots
	local hasStatus = BlizzArt_SVPC.hasStatusBars
	
	BlizzActionBar.pageFrame:Hide()
	BlizzActionBar.bagFrame:Hide()
	BlizzActionBar.healthFrame:Hide()
	BlizzActionBar.powerFrame:Hide()
	
	if hasPage and hasBag then
		width, xpWidth, anchor, buttonAnchor  = 1190, 905, 174, -326
		BlizzActionBar.bagFrame:Show()
		BlizzActionBar.pageFrame:Show()
	elseif hasPage then
		width, xpWidth, anchor, buttonAnchor = 1095, 810, 220, -280
		BlizzActionBar.pageFrame:Show()
	elseif hasBag then
		width, xpWidth, anchor, buttonAnchor = 1105, 820, 132, -368
		BlizzActionBar.bagFrame:Show()
	else
		width, xpWidth, anchor, buttonAnchor = 1010, 725, 178, -322
	end	
	if hasStatus then
		width, xpWidth = width + 125, xpWidth + 125
		BlizzActionBar.healthFrame:Show()
		BlizzActionBar.powerFrame:Show()
	end
	
	ActionButton1:ClearAllPoints()
	ActionButton1:SetPoint("BOTTOM", BlizzActionBar, "BOTTOM", buttonAnchor, 3)
	BlizzActionBar.PageUpButton:SetPoint("BOTTOM", BlizzActionBar, buttonAnchor-92, 44)
	BlizzActionBar.PageDownButton:SetPoint("BOTTOM", BlizzActionBar, buttonAnchor-92, 8)
	BlizzActionBar.Divider2:SetPoint("BOTTOM", anchor, 0)
	BlizzActionBar:SetWidth(width)	
	BlizzActionBar_XpBar_SetWidth(xpWidth)
end

function BlizzActionBar_SetPageValue(page)
	if page == 6 then
		BlizzActionBar.pageFrame.PageMarker:Hide()
	else
		BlizzActionBar.pageFrame.PageMarker:Show()
	end
	PlaySound("UChatScrollButton")
	BlizzActionBar.pageFrame.PageMarker:SetPoint("CENTER", BlizzActionBar.pageFrame.PageOverlay, "BOTTOM", 0, page/4 * (BlizzActionBar.pageFrame.PageOverlay:GetHeight() - 35))
end

local BlizzActionBarBackpackButton_SetChecked = MainMenuBarBackpackButton.SetChecked
function MainMenuBarBackpackButton.SetChecked(self, checked)
	BlizzActionBarBackpackButton_SetChecked(self, checked)
	if MainMenuBarBackpackButton:GetChecked() then
		BlizzActionBarBackpackButton:SetButtonState("PUSHED", 1)
	else
		BlizzActionBarBackpackButton:SetButtonState("NORMAL")
	end
end

function BlizzActionBar_SetMultiCastButtonsParent(parent)
	for _, button in pairs({ MultiCastActionBarFrame:GetChildren() }) do
		local _, relativeTo = button:GetPoint()
		if relativeTo == button:GetParent() then
			button:SetParent(parent)
		end
	end
end

function BlizzActionBar_SetBagButtonsParent(parent)
	for i=0, 3 do
		_G["CharacterBag"..i.."Slot"]:SetParent(parent)
	end
end

function BlizzActionBar_MoveBagButtons()
	CharacterBag0Slot:ClearAllPoints()
	CharacterBag2Slot:ClearAllPoints()
	if IsBlizzActionBarState() then
		CharacterBag0Slot:SetPoint("BOTTOMRIGHT", BlizzActionBar.BagBGR, "BOTTOMRIGHT", -12, 10)
		CharacterBag2Slot:SetPoint("BOTTOM", CharacterBag0Slot, "TOP", 0, 2)
	else
		CharacterBag0Slot:SetPoint("RIGHT", MainMenuBarBackpackButton, "LEFT", -2, 0)
		CharacterBag2Slot:SetPoint("RIGHT", CharacterBag1Slot, "LEFT", -2, 0)
	end
end

function BlizzActionBar_MoveMicroButtons()
	PVPMicroButton:ClearAllPoints()
	if UnitHasVehicleUI("player") then
		PVPMicroButton:SetPoint("BOTTOMLEFT", GuildMicroButton, "BOTTOMRIGHT", -3, 0)
	elseif IsBlizzActionBarState() then
		CharacterMicroButton:ClearAllPoints()
		CharacterMicroButton:SetPoint("TOPLEFT", BlizzActionBar.MicroBGL, "TOPLEFT", 10, 15)
		PVPMicroButton:SetPoint("TOPLEFT", CharacterMicroButton, "BOTTOMLEFT", 0, 24)
	else
		CharacterMicroButton:ClearAllPoints()
		CharacterMicroButton:SetPoint("BOTTOMLEFT", MainMenuBarArtFrame, "BOTTOMLEFT", 548, 2)
		PVPMicroButton:SetPoint("BOTTOMLEFT", GuildMicroButton, "BOTTOMRIGHT", -3, 0)
	end
end

function BlizzActionBar_MoveActionButtons()
	MultiBarBottomLeftButton1:ClearAllPoints()
	MultiBarBottomRightButton1:ClearAllPoints()
	if IsBlizzActionBarState() then
		MultiBarBottomLeftButton1:SetPoint("BOTTOM", ActionButton1, "TOP", 0, 6)
		MultiBarBottomRightButton1:SetPoint("BOTTOMRIGHT", BlizzActionBar, "BOTTOMRIGHT", -606, 125)
		PossessButton1:SetPoint("BOTTOMLEFT", BlizzActionBar, 145, 125)
	else
		MultiBarBottomLeftButton1:SetPoint("BOTTOMLEFT", MultiBarBottomLeft, 0, 0)
		MultiBarBottomRightButton1:SetPoint("BOTTOMLEFT", MultiBarBottomRight, 0, 0)
		PossessButton1:SetPoint("BOTTOMLEFT", PossessBarFrame, 10, 3)
		ActionButton1:ClearAllPoints()
		ActionButton1:SetPoint("BOTTOMLEFT", MainMenuBarArtFrame, 8, 4)
	end
end

function BlizzActionBar_MoveShapeshiftButton()
	if not InCombatLockdown() then
		if IsBlizzActionBarState() then
			ShapeshiftButton1:SetPoint("BOTTOMLEFT", BlizzActionBar, 145, 125)
		else
			ShapeshiftButton1:SetPoint("BOTTOMLEFT", ShapeshiftBarFrame, 10, 3)
		end
	end
end

function BlizzActionBar_MovePetActionButton()
	if not InCombatLockdown() then
		PetActionButton1:ClearAllPoints()
		if IsBlizzActionBarState() then
			if not ShapeshiftBarFrame:IsShown() then
				PetActionButton1:SetPoint("BOTTOMLEFT", BlizzActionBar, 145, 125)
			elseif MultiBarBottomRight:IsShown() then
				PetActionButton1:SetPoint("BOTTOMRIGHT", BlizzActionBar, "BOTTOMRIGHT", -548, 169)
			else
				PetActionButton1:SetPoint("BOTTOMRIGHT", BlizzActionBar, "BOTTOMRIGHT", -485, 125)
			end
		else
			PetActionButton1:SetPoint("BOTTOMLEFT", PetActionBarFrame, 36, 2)
		end
	end
end

function BlizzActionBar_MoveCastingBar()
	local bottomY = CastingBarFrame:GetBottom()
	local screenWidth, screenHeight = GetScreenWidth(), GetScreenHeight()
	if IsBlizzActionBarState() and bottomY and bottomY < screenHeight / 2 then
		if MultiBarBottomRight:IsShown() and PetActionBarFrame:IsShown() and ShapeshiftBarFrame:IsShown() then
			CastingBarFrame:SetPoint("BOTTOM", UIParent, 0, 200)
		else
			CastingBarFrame:SetPoint("BOTTOM", UIParent, 0, 170)
		end
	end
end

function BlizzActionBar_ManageFramePosition()
	BlizzActionBar_MoveShapeshiftButton()
	BlizzActionBar_MovePetActionButton()
	BlizzActionBar_MoveCastingBar()
end

function BlizzActionBar_SetupMainMenuBar()
	local alpha, isEnabled = 1, true
	if IsBlizzActionBarState() then
		alpha, isEnabled = 0, false
	end
	MainMenuBarBackpackButton:SetAlpha(alpha)
	MainMenuBarBackpackButton:EnableMouse(isEnabled)
	ActionBarUpButton:SetAlpha(alpha)
	ActionBarUpButton:EnableMouse(isEnabled)
	ActionBarDownButton:SetAlpha(alpha)
	ActionBarDownButton:EnableMouse(isEnabled)
	MainMenuExpBar:SetAlpha(alpha)
	MainMenuExpBar:EnableMouse(isEnabled)
	ReputationWatchBar:SetAlpha(alpha)
	ReputationWatchBar:EnableMouse(isEnabled)
	MainMenuBarMaxLevelBar:SetAlpha(alpha)
	MainMenuBarMaxLevelBar:EnableMouse(isEnabled)
	MainMenuBarTexture0:SetAlpha(alpha)
	MainMenuBarTexture1:SetAlpha(alpha)
	MainMenuBarTexture2:SetAlpha(alpha)
	MainMenuBarTexture3:SetAlpha(alpha)
	MainMenuBarLeftEndCap:SetAlpha(alpha)
	MainMenuBarRightEndCap:SetAlpha(alpha)
	MainMenuBarPageNumber:SetAlpha(alpha)
end

function BlizzActionBar_SetupBonusBar()	
	local condition = "[bonusbar:5] 11; [bar:2] 2; [bar:3] 3; [bar:4] 4; [bar:5] 5; [bar:6] 6; [bonusbar:1] 7; [bonusbar:2] 8; [bonusbar:3] 9; [bonusbar:4] 10; 1"
	local frame = CreateFrame("Frame", nil, nil, "SecureHandlerStateTemplate")
	for i = 1, 12 do
		frame:SetFrameRef("ActionButton"..i, _G["ActionButton"..i])
	end
	frame:Execute([[
		buttons = table.new()
		for i = 1, 12 do
			table.insert(buttons, self:GetFrameRef("ActionButton"..i))
		end
	]])
	frame:SetAttribute("_onstate-page",[[
		for i, button in ipairs(buttons) do
			button:SetAttribute("actionpage", tonumber(newstate))
		end
	]])
	RegisterStateDriver(frame, "page", condition)
	RegisterStateDriver(BonusActionBarFrame, "visibility", "hide")
end

function BlizzActionBarAnim_OnFinished()
	BlizzArt_ValidateTransition(BlizzActionBar)
end

function BlizzActionBar_SetupAnim()
	MainMenuBar.anim = MainMenuBar:CreateAnimationGroup()
	MainMenuBar.anim:CreateAnimation("Translation")
	MainMenuBar.anim:GetAnimations():SetDuration(0.5)
	MainMenuBar.anim:GetAnimations():SetOrder(1)
	MainMenuBar.anim:SetScript("OnFinished", BlizzActionBarAnim_OnFinished)
	BlizzActionBar.anim = MainMenuBar.anim
end

function BlizzActionBar_SetAnimOffset()
	local scale = UIParent:GetScale()
	local offset = 215
	if MultiBarBottomRight:IsShown() and ShapeshiftBarFrame:IsShown() and PetActionBarFrame:IsShown() then
		offset = 250
	end
	MainMenuBar.anim:GetAnimations():SetOffset(0, -offset * scale)
end

function IsBlizzActionBarState()
	return BlizzActionBar.state == 1
end

function BlizzActionBar_Setup()
	CastingBarFrame:SetScale(1.2)
	CastingBarFrame_SetLook(CastingBarFrame, "UNITFRAME")

	BlizzActionBar.state = 1
	BlizzActionBar:SetPoint("BOTTOM", UIParent, 0, 0)

	BlizzActionBar_SetupMainMenuBar()
	BlizzActionBar_SetupBonusBar()
	BlizzActionBar_SetMultiCastButtonsParent(MultiCastActionButtonFrame)
	BlizzActionBar_SetBagButtonsParent(BlizzActionBar.bagFrame)
	BlizzActionBar_MoveBagButtons()
	BlizzActionBar_MoveMicroButtons()
	BlizzActionBar_MoveActionButtons()
	BlizzActionBar_SetAnimOffset()
	BlizzActionBar_CalcSize()
	UIParent_ManageFramePositions()
end

function BlizzActionBar_SetupMain()
	CastingBarFrame:SetScale(1)
	CastingBarFrame_SetLook(CastingBarFrame, "CLASSIC")
	
	BlizzActionBar.state = nil
	BlizzActionBar:SetPoint("BOTTOM", UIParent, 0, -1000)
	
	BlizzActionBar_SetupMainMenuBar()
	BlizzActionBar_SetupBonusBar()
	BlizzActionBar_SetMultiCastButtonsParent(MultiCastActionBarFrame)
	BlizzActionBar_SetBagButtonsParent(MainMenuBarArtFrame)
	BlizzActionBar_MoveBagButtons()
	BlizzActionBar_MoveMicroButtons()
	BlizzActionBar_MoveActionButtons()
	BlizzActionBar_SetAnimOffset()
	UIParent_ManageFramePositions()
end

function BlizzActionBar_AbbreviateLargeNumbers(value)
	local strLen = strlen(value)
	local retString = value
	if strLen > 8 then
		retString = string.sub(value, 1, -7)..SECOND_NUMBER_CAP
	elseif strLen > 5 then
		retString = string.sub(value, 1, -4)..FIRST_NUMBER_CAP
	elseif strLen > 3 then
		retString = BlizzActionBar_BreakUpLargeNumbers(value)
	end
	return retString
end

function BlizzActionBar_BreakUpLargeNumbers(value)
	local retString = ""
	if value < 1000 then
		if value - math.floor(value) == 0 then
			return value
		end
		local decimal = math.floor(value*100)
		retString = string.sub(decimal, 1, -3)
		retString = retString..DECIMAL_SEPERATOR
		retString = retString..string.sub(decimal, -2)
		return retString
	end

	value = math.floor(value)
	local strLen = strlen(value)
	if GetCVarBool("breakUpLargeNumbers") then
		if strLen > 6 then
			retString = string.sub(value, 1, -7)..LARGE_NUMBER_SEPERATOR
		end
		if strLen > 3 then
			retString = retString..string.sub(value, -6, -4)..LARGE_NUMBER_SEPERATOR
		end
		retString = retString..string.sub(value, -3, -1)
	else
		retString = value
	end
	return retString
end

function BlizzActionBar_StatusBars_ShowTooltip(self)
	if GetMouseFocus() == self then
		local value = self:GetValue()
		local _, valueMax = self:GetMinMaxValues()
		if valueMax > 0 then
			local exhaustionStateID, exhaustionStateName, exhaustionStateMultiplier = GetRestState()
			local text = format("%s/%s (%s%%)", BlizzActionBar_AbbreviateLargeNumbers(value), BlizzActionBar_AbbreviateLargeNumbers(valueMax), tostring(math.ceil((value / valueMax) * 100)))
			GameTooltip:SetOwner(self, self.tooltipAnchorPoint)
			if self.prefix then
				GameTooltip:AddLine(self.prefix)
			end
			GameTooltip:AddLine(text, 1.0,1.0,1.0)
			if self.prefix == XP then
				GameTooltip:AddLine("\n"..format(EXHAUST_TOOLTIP1, exhaustionStateName, exhaustionStateMultiplier * 100))
			end
			GameTooltip:Show()
		end
	end
end

function BlizzActionBar_XpBar_SetWidth(width)
	BlizzActionBar.xpBar._XpMid:SetWidth(width)
	BlizzActionBar.xpBar:SetWidth(width+16)
	local divWidth = (width+16)/20
	local xpos = divWidth-10
	for i=1,19 do
		local texture = BlizzActionBar.xpBar["XpDiv"..i]
		texture:SetPoint("LEFT", BlizzActionBar.xpBar._XpMid, "LEFT", floor(xpos), 10)
		xpos = xpos + divWidth
	end
end

function BlizzActionBar_UpdateXpBar()	
	if ReputationWatchBar:IsShown() then
		BlizzActionBar.xpBar:SetMinMaxValues(ReputationWatchStatusBar:GetMinMaxValues())
		BlizzActionBar.xpBar:SetValue(ReputationWatchStatusBar:GetValue())
		BlizzActionBar.xpBar:SetStatusBarColor(ReputationWatchStatusBar:GetStatusBarColor())
		SetTextStatusBarTextPrefix(BlizzActionBar.xpBar, GetWatchedFactionInfo())
	elseif MainMenuExpBar:IsShown() then
		BlizzActionBar.xpBar:SetMinMaxValues(MainMenuExpBar:GetMinMaxValues())
		BlizzActionBar.xpBar:SetValue(MainMenuExpBar:GetValue())
		BlizzActionBar.xpBar:SetStatusBarColor(MainMenuExpBar:GetStatusBarColor())
		SetTextStatusBarTextPrefix(BlizzActionBar.xpBar, XP)
	else
		BlizzActionBar.xpBar:SetMinMaxValues(0,0)
		BlizzActionBar.xpBar:SetValue(0)
		BlizzActionBar.xpBar:SetStatusBarColor(0, 0, 0, 0)
		SetTextStatusBarTextPrefix(BlizzActionBar.xpBar, "")
	end
end

function BlizzActionBar_UpdateStatusBars()
	UnitFrameHealthBar_Update(BlizzActionBar.healthFrame.healthBar, "player")
	UnitFrameManaBar_Update(BlizzActionBar.powerFrame.powerBar, "player")
end