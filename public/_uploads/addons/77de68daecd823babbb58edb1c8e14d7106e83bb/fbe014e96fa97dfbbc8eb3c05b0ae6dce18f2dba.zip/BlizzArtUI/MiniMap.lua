local mainMenu = {
	"All",
	"Action Bar",
	"Minimap",
	"Player",
	"Target",
	"Focus",
	"Bag Slots",
	"Page Bar",
	"Status Bars",
}

local skinMenu = {
	"Alliance",
	"Bamboo",
	"Darkmoon",
	"Fancy",
	"Horde",
	"Generic",
	"Gnome",
	"Mechanical",
	"Natural",
	"Stone",
	"Tree",
	"Wood",
}

local iconList = {
	"INV_BannerPVP_02",
	"INV_Misc_Herb_05",
	"Spell_Shadow_SoulGem",
	"INV_Chest_Cloth_56",
	"INV_BannerPVP_01",
	"TEMP",
	"Achievement_Character_Gnome_Male",
	"INV_Misc_Gear_05",
	"INV_Misc_LeatherScrap_03",
	"INV_Stone_WeightStone_02",
	"Spell_Nature_ResistNature",
	"INV_TradeskillItem_02",
}

local frameList = {
	"BlizzActionBar",
	"BlizzMiniMap",
	"BlizzPlayerFrame",
	"BlizzTargetFrame",
	"BlizzFocusFrame",
}

local textureList = {
	"BG",
}

function BlizzMiniMap_OnLoad(self)
	self.textureList = textureList
	self:RegisterEvent("PLAYER_LOGIN")
end

function BlizzMiniMap_OnEvent(self, event, ...)
	if event == "PLAYER_LOGIN" then
		BlizzMiniMap_SetVariables()
		BlizzMiniMap_SetSkin()
	end
end

function BlizzMiniMap_SetVariables()
	if not BlizzArt_SVPC then
		BlizzArt_SVPC = {}
		BlizzArt_SVPC["Version"] = 2.51
	elseif BlizzArt_SVPC["Version"] < 2.51 then
		BlizzArt_SVPC["Version"] = 2.51
		BlizzArt_SVPC.hasPageBar = BlizzArt_SVPC.hasActionPage
		BlizzArt_SVPC.hasActionPage = nil
	end
end

function BlizzMiniMap_SetSkin()
	local textureFile = "Interface\\AddOns\\BlizzArtUI\\Texture\\%s"
	local selectedSkin = BlizzArt_SVPC["BlizzMiniMap"]
	if selectedSkin then
		for _, texture in pairs(BlizzMiniMap.textureList) do
			BlizzMiniMap[texture]:SetTexture(textureFile:format(selectedSkin), strsub(texture, 1, 1) == "_")
		end
	end
end

function BlizzMiniMapButtonDropDown_OnLoad(self)
	UIDropDownMenu_Initialize(self, BlizzMiniMapButtonDropDown_Initialize, "MENU")
	self.noResize = true
end

function BlizzMiniMapButtonDropDown_InitializeTransition(frame)	
	local frame = _G[frame]
	frame.stopOnFinish = nil
	
	if not frame.anim:IsPlaying() and not InCombatLockdown() then
		BlizzArt_ValidateTransition(frame)
	end
end

function BlizzMiniMapButtonDropDown_Refresh(button, arg1, arg2)
	local isChecked = BlizzMiniMapButtonDropDown_IsChecked(button)
	if button.arg1 == "All" then
		for _, frame in pairs(frameList) do
			if isChecked then
				BlizzArt_SVPC[frame] = nil
			else
				BlizzArt_SVPC[frame] = arg2
			end
			BlizzMiniMapButtonDropDown_InitializeTransition(frame)
		end
	else
		if isChecked then
			BlizzArt_SVPC[arg1] = nil
		else
			BlizzArt_SVPC[arg1] = arg2
		end
		BlizzMiniMapButtonDropDown_InitializeTransition(arg1)
	end
	UIDropDownMenu_Refresh(BlizzMiniMapButtonDropDown)
end

function BlizzMiniMapButtonDropDown_IsChecked(button)
	if button.arg1 == "All" then
		for _, frame in pairs(frameList) do
			local isChecked = BlizzArt_SVPC[frame] == button.arg2
			if not isChecked then
				return false
			end
		end
		return true
	else
		return BlizzArt_SVPC[button.arg1] == button.arg2
	end
end

function BlizzMiniMapButtonDropDown_RefreshMain(button, arg1)
	local isChecked = BlizzMiniMapButtonDropDown_IsCheckedMain(button)
	if isChecked then
		BlizzArt_SVPC[arg1] = false
	else
		BlizzArt_SVPC[arg1] = true
	end

	if IsBlizzActionBarState() and not InCombatLockdown() then
		if not BlizzActionBar.anim:IsPlaying() then
			BlizzActionBar.state = nil
			BlizzActionBar.stopOnFinish = nil
			BlizzArt_ValidateTransition(BlizzActionBar)
		end
	end
end
 
function BlizzMiniMapButtonDropDown_IsCheckedMain(button)
	if BlizzArt_SVPC[button.arg1] == nil then
		BlizzArt_SVPC[button.arg1] = true
	end	
	return BlizzArt_SVPC[button.arg1]
end

function BlizzMiniMapButtonDropDown_Initialize(self, level)
	for index, text in pairs(mainMenu) do
		local info = UIDropDownMenu_CreateInfo()
		info.text = text	
		if index == 1 then
			info.hasArrow = true
			info.notCheckable = true
			info.value = "All"		
		elseif index < 7  then
			info.hasArrow = true
			info.notCheckable = true
			info.value = frameList[index-1]
		else
			info.isNotRadio = true
			info.keepShownOnClick = true
			info.func = BlizzMiniMapButtonDropDown_RefreshMain
			info.checked = BlizzMiniMapButtonDropDown_IsCheckedMain
		end	
		if index == 7 then
			info.arg1 = "hasBagSlots"
			info.icon = "Interface\\AddOns\\BlizzArtUI\\Texture\\Banker"
		elseif index == 8 then
			info.arg1 = "hasPageBar"
			info.icon = "Interface\\AddOns\\BlizzArtUI\\Texture\\Profession"
		elseif index == 9 then
			info.arg1 = "hasStatusBars"
			info.icon = "Interface\\AddOns\\BlizzArtUI\\Texture\\Food"
		end
		if level == 1 then	
			UIDropDownMenu_AddButton(info, level)
		end
	end
	
	for index, text in pairs(skinMenu) do
		local icon = iconList[index]
		local info = UIDropDownMenu_CreateInfo()
		info.text = text
		info.icon = "Interface\\Icons\\"..icon
		info.arg1 = UIDROPDOWNMENU_MENU_VALUE
		info.arg2 = text
		info.isNotRadio = true
		info.keepShownOnClick = true
		info.func = BlizzMiniMapButtonDropDown_Refresh
		info.checked = BlizzMiniMapButtonDropDown_IsChecked	
		if level == 2 then
			UIDropDownMenu_AddButton(info, level)
		end
	end
end