local textureList = {
	"BG",
}

function BlizzPlayerFrame_ShowSkin()
	BlizzPlayerFrameBG:Show()
end

function BlizzPlayerFrame_HideSkin()
	BlizzPlayerFrameBG:Hide()
end

function BlizzUnitFrame_OnLoad(self)
	self.textureList = textureList
	self:RegisterEvent("PLAYER_LOGIN")
	
	if self == BlizzPlayerFrame then
		hooksecurefunc("PlayerFrame_ToPlayerArt", BlizzPlayerFrame_ShowSkin)
		hooksecurefunc("PlayerFrame_ToVehicleArt", BlizzPlayerFrame_HideSkin)
	end
end

function BlizzUnitFrame_OnEvent(self, event, ...)
	if event == "PLAYER_LOGIN" then
		BlizzUnitFrame_SetSkin(self)
	end
end

function BlizzUnitFrame_SetSkin(self)
	local textureFile = "Interface\\AddOns\\BlizzArtUI\\Texture\\%s"
	local selectedSkin = BlizzArt_SVPC[self:GetName()]
	if selectedSkin then
		for _, texture in pairs(self.textureList) do
			self[texture]:SetTexture(textureFile:format(selectedSkin), strsub(texture, 1, 1) == "_")
		end
	end
end