--nccooldownflash

--		config

local size = 50 -- icon size
local border = [[Interface\AddOns\ncCooldownFlash\grow]]
local bordersize = 4

-- for 1px border set it to 

--local border = [[Interface\Buttons\WHITE8x8]]
--local bordersize = 1


--		config end

local lib = LibStub("LibCooldown")
if not lib then error("CooldownFlash requires LibCooldown") return end

local filter = {
	["pet"] = "all",
	["item"] = {
		[6948] = true, -- hearthstone
	},
	["spell"] = {
	},
}

local backdrop = {
	  bgFile = [[Interface\Buttons\WHITE8x8]], 
	  edgeFile = border, 
	  tile = false, tileSize = 0, edgeSize = bordersize, 
	  insets = { left = bordersize, right = bordersize, top = bordersize, bottom = bordersize}
	}
	
local flash = CreateFrame("Frame", nil, UIParent)
flash.icon = flash:CreateTexture(nil, "OVERLAY")

flash:SetScript("OnEvent", function()
	flash:SetPoint("CENTER", UIParent)
	flash:SetSize(size,size)
	flash:SetBackdrop(backdrop)
	flash:SetBackdropColor(0,0,0)
	flash:SetBackdropBorderColor(0,0,0)
	
	flash.icon:SetPoint("TOPLEFT", bordersize, -bordersize)
	flash.icon:SetPoint("BOTTOMRIGHT", -bordersize, bordersize)
	flash.icon:SetTexCoord(.08, .92, .08, .92)
	
	flash:Hide()
	
	flash:SetScript("OnUpdate", function(self, e)
		flash.e = flash.e + e
		if flash.e > .75 then
			flash:Hide()
		elseif flash.e < .25 then
			flash:SetAlpha(flash.e*4)
		elseif flash.e > .5 then
			flash:SetAlpha(1-(flash.e%.5)*4)
		end
	end)
	
	flash:UnregisterEvent("PLAYER_ENTERING_WORLD")
	flash:SetScript("OnEvent", nil)
	
end)

flash:RegisterEvent("PLAYER_ENTERING_WORLD")

lib:RegisterCallback("stop", function(id, class)
	if filter[class]=="all" or filter[class][id] then return end
	flash.icon:SetTexture(class=="item" and GetItemIcon(id) or select(3, GetSpellInfo(id)))
	flash.e = 0
	flash:Show()
end)