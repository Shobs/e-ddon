-- Sell-All page for Abigail 1.21
-- 13/6/12


local abiSellHelpText={}
local abiSellAllTable={}
local abiSellBuyoutPrice={}
local abiSellBidPrice={}
local abiSellCheapestPrice={}
local abiSellDefaultBuy={}
local abiSellPriceType={}
local abiRealm=GetRealmName()
local abiSellTableOffset=0
local abiAHType=1
local abiSearchDone=0
local abiReadWhichItem
local abiDoingARead=0
local abiDuration=3
local abiDurTable={"12 Hrs","24 Hrs","48 Hrs"}
local abiSellShowTooltip=0

abiSellHelpText[1]="Auction all items in all bags."
abiSellHelpText[2]="Press to 'round' the selling prices."
abiSellHelpText[3]="Press to show selling prices for items in bags."
abiSellHelpText[4]="Checks for the best-value Auction of each item."
abiSellHelpText[5]="Reset all prices and slider values."
abiSellHelpText[6]="Toggle how the Auction Prices are shown."
abiSellHelpText[7]="Undercut the Auction Price."
abiSellHelpText[8]="Set the duration of the auctions."
abiSellHelpText[9]="Create an Auction for this item."
abiSellHelpText[10]="L-Click = Name To Browse Fields,  R-Click = Toggle Tooltip"



function abiSellingFrame_OnLoad()
	abiSellingFrame:Hide()
	abiSellingLowestPriceButton:Disable()
	--abiSellingAHTypeButton:Disable()
	abiSellingResetButton:Disable()
end



function abiSellingAHTypeButtonClicked()

	if abiAHType==1 then
		abiSellingAHTypeButton:SetText("Per Stack")
		abiAHType=2
	else
		abiSellingAHTypeButton:SetText("Per Unit")
		abiAHType=1
	end

	if #abiSellAllTable==0 then
		return
	end

	for abiloop=1,#abiSellAllTable do
		_,abiCount,_,_,_=abiDecodeSellAllTable(abiSellAllTable[abiloop])

		if abiAHType==1 then -- and abiSellCheapestPrice[abiloop]~=0 then
			abiSellCheapestPrice[abiloop]=math.floor(abiSellCheapestPrice[abiloop]/abiCount)
			abiSellBuyoutPrice[abiloop]=math.floor(abiSellBuyoutPrice[abiloop]/abiCount)
			abiSellBidPrice[abiloop]=math.floor(abiSellBidPrice[abiloop]/abiCount)
			--abiSellDefaultBuy[abiloop]=math.floor(abiSellDefaultBuy[abiloop]/abiCount)
		end

		if abiAHType==2 then -- and abiSellCheapestPrice[abiloop]~=0 then
			abiSellCheapestPrice[abiloop]=abiSellCheapestPrice[abiloop]*abiCount
			abiSellBuyoutPrice[abiloop]=abiSellBuyoutPrice[abiloop]*abiCount
			abiSellBidPrice[abiloop]=abiSellBidPrice[abiloop]*abiCount
			--abiSellDefaultBuy[abiloop]=math.floor(abiSellDefaultBuy[abiloop]*abiCount)

		end
	end

	abiDisplayTheSellingItems()
end



function abiSellHelp(passed)
	abiSellFrameHelp:SetText("|cffffffff"..abiSellHelpText[passed])
end



function abiSellingResetButtonClicked()
	abiSellAllTable=table.wipe(abiSellAllTable)
	abiSellBuyoutPrice=table.wipe(abiSellBuyoutPrice)
	abiSellBidPrice=table.wipe(abiSellBidPrice)
	abiSellCheapestPrice=table.wipe(abiSellCheapestPrice)
	abiSellDefaultBuy=table.wipe(abiSellDefaultBuy)
	abiSellTableOffset=0
	abiAHType=1
	abiSearchDone=0
	abiSellingAHTypeButton:SetText("Per Unit")
	abiSellingSlider2Text:SetText("0%")
	abiSellingSlider1Text:SetText("10%")
	abiSellingSlider3Text:SetText("5%")
	abiSellingSlider2:SetValue(0)
	abiSellingSlider1:SetValue(10)
	abiSellingSlider3:SetValue(5)
	abiSellingSearchButtonClicked()
	abiDuration=3
	abiSellingTimeButton:SetText("48 Hrs")
end



function abiSellingSearchButtonClicked()
	abiSellAllTable=table.wipe(abiSellAllTable)
	abiSellBuyoutPrice=table.wipe(abiSellBuyoutPrice)
	abiSellBidPrice=table.wipe(abiSellBidPrice)
	abiSellCheapestPrice=table.wipe(abiSellCheapestPrice)

	local abiBagName
	local abiSlots
	local abiTexture,abiCount,abiLink
	local t

	-- close any open bags
	for abiloop=1,5 do
		getglobal("ContainerFrame"..abiloop):Hide()
	end

	-- now open them in order
	for abiloop=0,4 do
		ToggleBag(abiloop)
	end

	-- and read the auctionable items from the bags
	for abiBag=0,4 do
		abiSlots=GetContainerNumSlots(abiBag)

		if abiSlots~=0 then

			for abiloop=1,abiSlots do
				abiTexture,abiCount,_,_,_,_,abiLink,_=GetContainerItemInfo(abiBag,abiloop)

				if abiCount~=nil then
					abiName=abiDecodeItemLink(abiLink)
					f = CreateFrame('GameTooltip', 'SellingTooltip', UIParent, 'GameTooltipTemplate')
					f:SetOwner(UIParent, 'ANCHOR_NONE')
					f:SetBagItem(abiBag,abiloop)
					t=SellingTooltipTextLeft2:GetText()

					if t~="Soulbound" and t~="Battle.net Account Bound" then
						abiSellAllTable[#abiSellAllTable+1]=abiName.."%"..abiCount.."%"..abiBag.."%"..abiloop.."%"..abiLink
						abiSellCheapestPrice[#abiSellCheapestPrice+1]=0
					end

					f:Hide()
				end
			end
		end
	end

	abiGetSellingPrices(0)
	abiSellingScrollFrameUpdate()
	abiDisplayTheSellingItems()
	abiSellingLowestPriceButton:Enable()
	abiSellingResetButton:Enable()
	abiSearchDone=1
	abiSellFrameHelp:SetText("|cffffffff"..#abiSellAllTable.." auctionable items found")

	abiSellingScrollFrame:SetVerticalScroll(0)
	abiSellTableOffset=0

end



function abiDisplayTheSellingItems()
	local abiStart
	local abiFinish
	local abiOneToTwelve

	for abiloop=1,12 do
		getglobal("abiSellingName"..abiloop):SetText("empty")
		getglobal("abiSellingName"..abiloop):Show()
		getglobal("abiSellingBuy"..abiloop):Hide()
		getglobal("abiSellingBid"..abiloop):Hide()
		getglobal("abiSellingButton"..abiloop):Hide()
		getglobal("abiUC"..abiloop):Hide()
	end


	abiStart=1+abiSellTableOffset
	abiFinish=12+abiSellTableOffset

	if abiFinish>#abiSellAllTable then
		abiFinish=#abiSellAllTable
		abiStart=abiFinish-11
	end

	if abiStart<1 then
		abiStart=1
	end

	if abiStart<=abiFinish then

		for abiloop=abiStart,abiFinish do
			abiOneToTwelve=abiloop-abiStart+1
			abiName,abiCount,_,_,_=abiDecodeSellAllTable(abiSellAllTable[abiloop])
			if abiName=="This Item Auctioned" then
				getglobal("abiSellingName"..abiOneToTwelve):SetText(abiName)
				getglobal("abiSellingButton"..abiOneToTwelve):Disable()
				getglobal("abiSellingButton"..abiOneToTwelve):Show()
				getglobal("abiPriceType"..abiOneToTwelve):SetText("-")
				getglobal("abiPriceType"..abiOneToTwelve):Show()
			else
				getglobal("abiSellingName"..abiOneToTwelve):SetText(abiCount.." x "..abiName)
				getglobal("abiSellingButton"..abiOneToTwelve):Enable()
				getglobal("abiSellingButton"..abiOneToTwelve):Show()
				getglobal("abiPriceType"..abiOneToTwelve):SetText(abiSellPriceType[abiloop])
				getglobal("abiPriceType"..abiOneToTwelve):Show()

			end


			AbigailMoneyFrame_Update(getglobal("abiSellingBid"..abiOneToTwelve),abiSellBidPrice[abiloop],0,"|cffffffff")
			getglobal("abiSellingBid"..abiOneToTwelve):Show()

			AbigailMoneyFrame_Update(getglobal("abiSellingBuy"..abiOneToTwelve),abiSellBuyoutPrice[abiloop],0,"|cffffffff")		
			getglobal("abiSellingBuy"..abiOneToTwelve):Show()

			AbigailMoneyFrame_Update(getglobal("abiSellingCheap"..abiOneToTwelve),abiSellCheapestPrice[abiloop],0,"|cffffffff")

			if abiSellCheapestPrice[abiloop]>0 then
				getglobal("abiSellingCheap"..abiOneToTwelve):Show()
				getglobal("abiUC"..abiOneToTwelve):Enable()
				--getglobal("abiSellingButton"..abiOneToTwelve):Enable()
			else
				getglobal("abiSellingCheap"..abiOneToTwelve):Hide()
				getglobal("abiUC"..abiOneToTwelve):Disable()
				--getglobal("abiSellingButton"..abiOneToTwelve):Disable()

			end

			getglobal("abiUC"..abiOneToTwelve):Show()
		end
	end
end



function abiSellMessageFrame_OnEnter(passed)
	local abiSellLink,abiSellName
	local t=passed+abiSellTableOffset
	if t<=#abiSellAllTable then
		abiSellName,_,_,_,abiSellLink=abiDecodeSellAllTable(abiSellAllTable[t])
		GameTooltip:Hide()
		if abiSellName~="This Item Auctioned" and abiSellShowTooltip==1 then
			GameTooltip:SetOwner(abiSellingFrame,"ANCHOR_CURSOR")
			GameTooltip:SetHyperlink(abiSellLink)
			GameTooltip:Show()
		end
		abiHighlightTheText(passed)
		abiSellHelp(10)
	end
end



function abiHighlightTheText(passed)
	local t
	getglobal("abiSellingName"..passed):SetTextColor(1,1,1,1)
	getglobal("abiSellingName"..passed):SetFontObject("GameFontNormalLarge")

	t=abiSellBuyoutPrice[passed+abiSellTableOffset]

	if t~=nil then
		AbigailMoneyFrame_Update(getglobal("abiSellingBuy"..passed),t,0,"|cffff4040")
	end

	t=abiSellBidPrice[passed+abiSellTableOffset]

	if t~=nil then
		AbigailMoneyFrame_Update(getglobal("abiSellingBid"..passed),t,0,"|cffff4040")
	end
end



function abiSellMessageFrame_OnLeave(passed)
	local t
	getglobal("abiSellingName"..passed):SetTextColor(1,0.9,0,0.9)
	getglobal("abiSellingName"..passed):SetFontObject("GameFontNormal")

	t=abiSellBuyoutPrice[passed+abiSellTableOffset]

	if t~=nil then
		AbigailMoneyFrame_Update(getglobal("abiSellingBuy"..passed),t,0,"|cffffffff")
	end

	t=abiSellBidPrice[passed+abiSellTableOffset]

	if t~=nil then
		AbigailMoneyFrame_Update(getglobal("abiSellingBid"..passed),t,0,"|cffffffff")
	end
	GameTooltip:Hide()
	abiSellHelp(1)
end



function abiSellMouseDown(passed,button)
	local abiSellName
	local t=passed+abiSellTableOffset
	if t<=#abiSellAllTable then
		abiSellName,_,_,_,_=abiDecodeSellAllTable(abiSellAllTable[t])
		if abiSellName~="This Item Auctioned" and button=="LeftButton" then
			if IsShiftKeyDown()==1 then
				abiSellName=abiShortenName(abiSellName)
			end

			--Put the item name into the BrowseName field of main AH window
			BrowseName:SetText(abiSellName)

			if (IsAddOnLoaded("Auctionator")) then
				Atr_Search_Box:SetText(abiSellName)
			end
		end
		if button=="RightButton" then
			abiSellShowTooltip=1-abiSellShowTooltip
			abiSellMessageFrame_OnEnter(passed)
		end
	end
end



function abiSellButton_OnEnter(passed)
	abiSellHelp(9)
	abiHighlightTheText(passed)
end



function abiSellButton_OnLeave(passed)
	abiSellHelp(1)
	abiSellMessageFrame_OnLeave(passed)
end



function abiGetSellingPrices(passed)
	local aName,aCount,aBag,aSlot
	local Bhigh,Blow,Shigh,Slow,Rsold,Ratio,PriceHistory
	local Vendor
	local aAverage
	local percent=1-(abiSellingSlider1:GetValue()/100)
	local bought=1+(abiSellingSlider2:GetValue()/100)


	abiRealm=GetRealmName() -- just make sure

	if passed==0 then

		for abiloop=1,#abiSellAllTable do
			abiSellBuyoutPrice[abiloop]=0
			abiSellBidPrice[abiloop]=0
			aName,aCount,aBag,aSlot,_=abiDecodeSellAllTable(abiSellAllTable[abiloop])
			_,_,_,_,_,_,_,_,_,_,Vendor=GetItemInfo(aName)

			if aName~="This Item Auctioned" then

				if abiAHType==1 then
					aCount=1
				end
	
				if Vendor==nil then
					Vendor=10000 -- default 1 gold if never seen
				end
	
				if abiPriceIndex[abiRealm][aName]==nil then -- not seen before, needs adding to index file
					abiPriceIndex[abiRealm][aName]={}
					abiPriceIndex[abiRealm][aName]="0%0%0%0%0%0:0%"..abiMakeFullPrice(Vendor).."*1"
				end

				Bhigh,Blow,Shigh,Slow,Rsold,Ratio,PriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][aName])
				abiDecodePriceHistory(PriceHistory)
				aAverage=abiFindAveragePrice()

				if Shigh>0 then
					abiSellBuyoutPrice[abiloop]=Shigh*aCount
					abiSellPriceType[abiloop]="S"
					abiSellDefaultBuy[abiloop]=Shigh
				end

				if Shigh==0 and Bhigh>0 then
					abiSellBuyoutPrice[abiloop]=math.floor(Bhigh*aCount)
					abiSellPriceType[abiloop]="B"
					abiSellDefaultBuy[abiloop]=Bhigh
				end

				if Shigh==0 and Bhigh==0 then
					abiSellBuyoutPrice[abiloop]=aAverage*aCount
					abiSellPriceType[abiloop]="A"
					abiSellDefaultBuy[abiloop]=aAverage
				end

			else
				abiSellBuyoutPrice[abiloop]=0
				abiSellDefaultBuy[abiloop]=0
			end

				abiSellBuyoutPrice[abiloop]=math.floor(abiSellBuyoutPrice[abiloop]*bought)
				abiSellBidPrice[abiloop]=math.floor(abiSellBuyoutPrice[abiloop]*percent)
		end
	else
		for abiloop=1,#abiSellAllTable do
			aName,aCount,aBag,aSlot,_=abiDecodeSellAllTable(abiSellAllTable[abiloop])

			if aName~="This Item Auctioned" then

				if abiAHType==1 then
					aCount=1
				end

				abiSellBuyoutPrice[abiloop]=math.floor(abiSellDefaultBuy[abiloop]*aCount*bought)
				abiSellBidPrice[abiloop]=math.floor(abiSellBuyoutPrice[abiloop]*percent)
			else
				abiSellBuyoutPrice[abiloop]=0
				abiSellBidPrice[abiloop]=0
			end
		end
	end

end



function abiSellingLowestPriceButtonClicked()
	for abiloop=1,#abiSellAllTable do
		abiSellCheapestPrice[abiloop]=0
	end

	abiReadWhichItem=1
	abiActuallyReadTheItem()
end



function abiActuallyReadTheItem()
	local temp=0
	abiDoingARead=0
	local aName,aCount,_,_,_=abiDecodeSellAllTable(abiSellAllTable[abiReadWhichItem])

	if aName~="This Item Auctioned" then

		for abiloop=1,#abiAHImage do
			abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid=abiDecodeImage(abiAHImage[abiloop])
			abiImagePrice=math.floor(abiImagePrice/abiImageCount)

			if aName==abiImageName and ((abiImagePrice<temp) or temp==0) then
				temp=abiImagePrice
			end

			abiSellCheapestPrice[abiReadWhichItem]=temp
		end
	end

	abiReadWhichItem=abiReadWhichItem+1

	if abiReadWhichItem<=#abiSellAllTable then
		abiDisplayTheSellingItems()
		abiDoingARead=1
		return
	end

	abiDisplayTheSellingItems()
	abiDoingARead=2
end



function abiSellingMakeFrames()

	for abiloop=1,12 do
		f=abiSellingFrame:CreateFontString("abiSellingName"..abiloop)
		f:SetPoint("TOPLEFT",abiSellingFrame,"TOPLEFT",48,0-(abiloop*20))
		f:SetFontObject(GameFontNormal)
		f:SetWidth(240)
		f:SetHeight(20)
		f:SetJustifyH("LEFT")
		f:Hide()

		framename="abiSellingBuy"..abiloop
		f=CreateFrame("Frame",framename,abiSellingFrame,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiSellingFrame,"TOPLEFT",423,0-(abiloop*20))
		f:Hide()

		framename="abiSellingBid"..abiloop
		f=CreateFrame("Frame",framename,abiSellingFrame,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiSellingFrame,"TOPLEFT",298,0-(abiloop*20))
		f:Hide()

		framename="abiSellingCheap"..abiloop
		f=CreateFrame("Frame",framename,abiSellingFrame,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiSellingFrame,"TOPLEFT",558,0-(abiloop*20))
		f:Hide()

		f=abiSellingFrame:CreateFontString("abiPriceType"..abiloop)
		f:SetPoint("TOPLEFT",abiSellingFrame,"TOPLEFT",563,0-(abiloop*20))
		f:SetFontObject(GameFontNormal)
		f:SetWidth(15)
		f:SetHeight(20)
		f:SetJustifyH("LEFT")
		f:Hide()

		f=getglobal("abiUC"..abiloop)
		f:Hide()

		f=getglobal("abiSellingButton"..abiloop)
		f:Hide()
	end

end



function abiSellingMakeHeaders()
	CreateFrame("Button","abiSH1",abiSellingFrame,"AbigailButtonTemplate")
	abiSH1:SetWidth(259)
	abiSH1:SetHeight(20)
	abiSH1:SetPoint("TOPLEFT",AuctionFrame,"TOP",-357,-54)
	abiSH1:SetText("Item Name")

	CreateFrame("Button","abiSH2",abiSellingFrame,"AbigailButtonTemplate")
	abiSH2:SetWidth(130)
	abiSH2:SetHeight(20)
	abiSH2:SetPoint("TOPLEFT",AuctionFrame,"TOP",-101,-54)
	abiSH2:SetText("Start Bid")

	CreateFrame("Button","abiSH3",abiSellingFrame,"AbigailButtonTemplate")
	abiSH3:SetWidth(130)
	abiSH3:SetHeight(20)
	abiSH3:SetScript("OnClick",abiRoundBuyout)
	abiSH3:SetScript("OnEnter",abiHelp2)
	abiSH3:SetScript("OnLeave",abiHelp1)
	abiSH3:SetPoint("TOPLEFT",AuctionFrame,"TOP",27,-54)
	abiSH3:SetText("Buyout")

	CreateFrame("Button","abiSH4",abiSellingFrame,"AbigailButtonTemplate")
	abiSH4:SetWidth(20)
	abiSH4:SetHeight(20)
	abiSH4:SetPoint("TOPLEFT",AuctionFrame,"TOP",156,-54)
	abiSH4:SetText("?")


	CreateFrame("Button","abiSH5",abiSellingFrame,"AbigailButtonTemplate")
	abiSH5:SetWidth(130)
	abiSH5:SetHeight(20)
	abiSH5:SetPoint("TOPLEFT",AuctionFrame,"TOP",174,-54)
	abiSH5:SetText("Snapshot")
	
end



function abiHelp2()

	if abiSearchDone==1 then
		abiSellHelp(2)
	end

end



function abiHelp1()
	abiSellHelp(1)
end



function abiSellingScrollFrameUpdate()

	if #abiSellAllTable~=0 then
		FauxScrollFrame_Update(abiSellingScrollFrame,#abiSellAllTable,12,15)
		-- #abiSellAllTable is max entries, 12 is number of lines, 15 is pixel height of each line
		abiSellTableOffset=FauxScrollFrame_GetOffset(abiSellingScrollFrame)
		abiDisplayTheSellingItems()
		abiSellingScrollFrame:Show()
	end

end



function abiSellingSlider1_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "Percentage the Start Bid price is lower than the Buyout price.";
	getglobal(slider.."Low"):SetText("1");
	getglobal(slider.."High"):SetText("50");
	getglobal(slider.."Text"):SetText("10%");
end



function abiSellingSlider2_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "Percentage Adjustment of Buyout Prices.";
	getglobal(slider.."Low"):SetText("-90");
	getglobal(slider.."High"):SetText("500");
	getglobal(slider.."Text"):SetText("0%");
end



function abiSellingSlider3_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "Percentage to undercut cheapest auction by.";
	getglobal(slider.."Low"):SetText("1");
	getglobal(slider.."High"):SetText("50");
	getglobal(slider.."Text"):SetText("10%");
end



function abiSellingSlider1ValueChanged()
	local percent
	abiSellingSlider1Text:SetText(abiSellingSlider1:GetValue().."%")
	percent=1-(abiSellingSlider1:GetValue()/100)

	if abiSearchDone==1 then

		for abiloop=1,#abiSellAllTable do
			abiSellBidPrice[abiloop]=math.floor(abiSellBuyoutPrice[abiloop]*percent)
		end

		abiDisplayTheSellingItems()
	end

end



function abiSellingSlider2ValueChanged()
	abiSellingSlider2Text:SetText(abiSellingSlider2:GetValue().."%")
	if abiSearchDone==1 then
		abiGetSellingPrices(1)
		abiDisplayTheSellingItems()
	end

end


function abiSellingSlider3ValueChanged()
	abiSellingSlider3Text:SetText(abiSellingSlider3:GetValue().."%")

end


function abiResetSlider1()
	abiSellingSlider1:SetValue(10)
	abiSellingSlider1Text:SetText("10%")
end


function abiResetSlider2()
	abiSellingSlider2:SetValue(0)
	abiSellingSlider2Text:SetText("0%")
end


function abiResetSlider3()
	abiSellingSlider3:SetValue(5)
	abiSellingSlider3Text:SetText("5%")
end



function abiUnderCutting_OnClick(passed)
	passed=passed+abiSellTableOffset
	local percent1=(100-abiSellingSlider1:GetValue())/100
	local percent3=(100-abiSellingSlider3:GetValue())/100
	local percent2=1+(abiSellingSlider2:GetValue()/100)
	
	local _,aCount,_,_,_=abiDecodeSellAllTable(abiSellAllTable[passed])
	if abiAHType==1 then
		aCount=1
	end

	abiSellDefaultBuy[passed]=math.floor(abiSellCheapestPrice[passed]*percent3)--*aCount

	abiSellBuyoutPrice[passed]=math.floor(abiSellDefaultBuy[passed]*percent2*aCount)

	percent=(100-abiSellingSlider1:GetValue())/100
	abiSellBidPrice[passed]=math.floor(abiSellBuyoutPrice[passed]*percent1)
	abiSellPriceType[passed]="U"
	abiDisplayTheSellingItems()
end



function abiSellingTimeButtonClicked()
	abiDuration=abiDuration+1

	if abiDuration==4 then
		abiDuration=1
	end

	abiSellingTimeButton:SetText(abiDurTable[abiDuration])
end



function abiRoundBuyout()
	local t, abipercent

	for abiloop=1,#abiSellAllTable do
		t=abiSellBuyoutPrice[abiloop]
		t=(math.floor((t/1000)+0.5))*1000
		abiSellBuyoutPrice[abiloop]=t
		percent=(100-abiSellingSlider1:GetValue())/100
		abiSellBidPrice[abiloop]=math.floor(abiSellBuyoutPrice[abiloop]*percent)
	end

	abiDisplayTheSellingItems()
end



function abiSellingFrameUpdate(self,elapsed)
	if abiDoingARead==1 then
		abiSellFrameHelp:SetText("|cffffffffFound AH Prices for item "..abiReadWhichItem.." / "..#abiSellAllTable)
		abiActuallyReadTheItem(abiReadWhichItem)
	end

	if abiDoingARead==2 then
		abiSellFrameHelp:SetText("|cffffffffFound all AH Prices for items in bags.")
		abiDoingARead=0
	end
end


function abiSellingButton_OnClick(passed)
	-- need buyout price, bid price, stack size, num stacks, duration
	local abiSelling=passed+abiSellTableOffset
	local abiSellName,abiSellCount,abiSellBag,abiSellSlot,abiSellLink
	local abiAuctionStackSize
	local abiAuctionNumStacks
	local t1,t2,t3

	abiSellName,abiSellCount,abiSellBag,abiSellSlot,abiSellLink=abiDecodeSellAllTable(abiSellAllTable[abiSelling])

	-- get item onto cursor
	ClearCursor()
	PickupContainerItem(abiSellBag,abiSellSlot)

	-- Set the duration
	-- This is done and stored in abiDuration as 1,2 or 3
	AuctionFrameAuctions.duration=abiDuration

	-- Set Stack Size - if needed
	-- "Per Unit" - abiAHType==1
	-- "Per Stack" - abiAHType==2
	abiAuctionStackSize=1

	if abiAHType==2 then
		abiAuctionStackSize=abiSellCount
	end

	AuctionsStackSizeEntry:SetText(abiAuctionStackSize)


	-- Set Number of Stacks - if needed
	abiAuctionNumStacks=1

	if abiAHType==1 then
		abiAuctionNumStacks=abiSellCount
	end

	AuctionsNumStacksEntry:SetText(abiAuctionNumStacks)



	-- put Starting Bid price into Starting Price slot
	abiAuctionBid=abiSellBidPrice[abiSelling]
	MoneyInputFrame_SetCopper(StartPrice, abiAuctionBid)


	-- put Buyout Price into Buyout Price Slot
	abiAuctionBuy=abiSellBuyoutPrice[abiSelling]
	MoneyInputFrame_SetCopper(BuyoutPrice, abiAuctionBuy)

	t1,t2,t3=GetCursorInfo()
	if t1~="item" then
		print("Bag contents have changed. Please do another Read Bags.")
		ClearCursor()
		return
	end
	t3=abiDecodeItemLink(t3)
	if string.sub(t3,1,#abiSellName)~=abiSellName then
		print("Bag contents have changed. Please do another Read Bags.")
		ClearCursor()
		return
	end

	-- put item into Auction Item Slot
	ClickAuctionSellItemButton()


	-- create the auction.
	StartAuction(abiAuctionBid,abiAuctionBuy,abiDuration,abiAuctionStackSize,abiAuctionNumStacks)
	print("Auction Created for : "..abiSellName)
	abiSellAllTable[abiSelling]="This Item Auctioned%1%0%0%"..abiSellLink
	abiPriceIndex[abiRealm]["This Item Auctioned"]="0%0%0%0%0%0:0%0000000000*1" -- creates price-index record for 'This Item Auctioned'
	--table.remove(abiSellAllTable,abiSelling)

	abiSellBuyoutPrice[abiSelling]=0
	--table.remove(abiSellBuyoutPrice,abiSelling)

	abiSellBidPrice[abiSelling]=0
	--table.remove(abiSellBidPrice,abiSelling)

	abiSellCheapestPrice[abiSelling]=0
	--table.remove(abiSellCheapestPrice,abiSelling)
	abiDisplayTheSellingItems()
end
