-- Shopping page for Abigail 1.21
-- 13/6/12

local abiScrollList1={}
local abiScrollList2={}
local abiHelpText={}
local abiCostingButtonText={}

abiHelpText[1]="Items here can be added to the Shopping List"
abiHelpText[2]="Your Shopping List - add/remove items or alter prices"
abiHelpText[3]="General Price History for an Item"
abiHelpText[4]="Use / Don't Use Class selections from Options Screen"
abiHelpText[5]="Which Price to use in Shopping List"
abiHelpText[6]="Construct a Shopping List of favourite items"
abiHelpText[7]="Sort the Shopping List alphabetically"
abiHelpText[8]="Compare auctions by Buyout or Unit price"
abiHelpText[9]="Show Items that can be added to Shopping List"
abiHelpText[10]="Search Snapshot for items in the Shopping List"
abiHelpText[11]="Finished Editing price Changes"
abiHelpText[12]="Search Shopping List using Prices"
abiHelpText[13]="Search Shopping List by ignoring Prices"

abiCostingButtonText[1]="Use : Buy Hi"
abiCostingButtonText[2]="Use : Buy Lo"
abiCostingButtonText[3]="Use : Sold Hi"
abiCostingButtonText[4]="Use : Sold Lo"

local abiScrollTableOffset1=0
local abiScrollTableOffset2=0
local abiShoppingTarget=0
local abiRemovingNumber=0
local abiRemovingName=""
local abiShopCosting=1
local abiUsingClasses=1
local abiShopStack=0
local abiMessageWait=0
local abiIgnoreShopPrice=0

function abiShoppingFrame_OnLoad()
	abiShoppingFrame:Hide()
	abiPartFrame1:SetBackdropBorderColor(1,1,1,0.5)
	abiPartFrame2:SetBackdropBorderColor(1,1,1,0.5)
	abiPartFrame3:SetBackdropBorderColor(1,1,1,0.5)
	abiPartFrame4:SetBackdropBorderColor(1,1,1,0.5)
end



function abiCreateScrollList2()
	abiRealm=GetRealmName()
	-- this function called from main Abigail file when Shopping tab pressed
	-- abiShoppingList = [Realm][ItemName] = costtype..%..max-spend-value
	abiShoppingTarget=0
	local k,k2,v2
	abiScrollList2=table.wipe(abiScrollList2)

	for k,v in pairs(abiShoppingList) do
		--k is the realm name

		if abiRealm==k then

			for k2,v2 in pairs(abiShoppingList[k]) do
				--k2 is name field, v2 is shopping list price field
				abiScrollList2[#abiScrollList2+1]=k2.."%"..v2
			end

		end

	end

	if #abiScrollList2>0 then

		abiShoppingScroll2Update()
		abiDisplayScroll2Items(#abiShoppingList)
	end
	abiEmptyFrame3()
end



function abiDisplayScroll1Items(passed)

	local abiStart
	local abiFinish
	local abiOneToTen

	abiStart=1+abiScrollTableOffset1
	abiFinish=10+abiScrollTableOffset1

	if abiFinish>passed then
		abiFinish=passed
	end

	if abiStart<=abiFinish then

		for abidisplayloop=abiStart,abiFinish do
			abiOneToTen=abidisplayloop-abiStart+1
			getglobal("abiShopFrame1String"..abiOneToTen):SetText(string.sub(abiScrollList1[abidisplayloop],1,35))
		end

	end

end



function abiDisplayScroll2Items(passed)
	local abiStart
	local abiFinish
	local abiOneToTen
	local t1,t2,t3

	abiStart=1+abiScrollTableOffset2
	abiFinish=10+abiScrollTableOffset2

	if abiFinish>passed then
		abiFinish=passed
	end

	if abiStart<=abiFinish then

		for abidisplayloop=abiStart,abiFinish do
			abiOneToTen=abidisplayloop-abiStart+1
			t1,t2,t3=strsplit("%",abiScrollList2[abidisplayloop])
			-- t1=name, t2=costtype, t3=percentprice
			t3=tonumber(t3)
			getglobal("abiShopFrame2String"..abiOneToTen):SetText(string.sub(t1,1,30))
			getglobal("abiShopFrame2String"..abiOneToTen):SetTextColor(1,0.9,0,0.9)
			getglobal("abiShopFrame2Cash"..abiOneToTen):SetText(abiCreatePriceStringIcons(t3,0))
		end

	end

end



function abiShopMessageFrame1_OnLeave(passed)

	if abiShoppingTarget==0 then
		getglobal("abiShopFrame1String"..passed):SetTextColor(1,0.9,0,0.9)
		getglobal("abiShopFrame1String"..passed):SetFontObject("GameFontNormal")
		abiEmptyFrame3()
	end

end



function abiShopMessageFrame2_OnLeave(passed)

	if abiShoppingTarget==0 then
		abiEmptyFrame3()
		getglobal("abiShopFrame2String"..passed):SetTextColor(1,0.9,0,0.9)
		getglobal("abiShopFrame2String"..passed):SetFontObject("GameFontNormal")
	end

end



function abiShopMessageFrame1_OnEnter(passed)

	if abiScrollTableOffset1~=nil and passed<=#abiScrollList1 and abiShoppingTarget==0 then
		abiRealm=GetRealmName() --just make sure
		local abiItemName=abiScrollList1[passed+abiScrollTableOffset1]
		abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiItemName])
		abiFillFrame3(abiItemName,abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRatio1,0)
		getglobal("abiShopFrame1String"..passed):SetTextColor(1,1,1,1)
		getglobal("abiShopFrame1String"..passed):SetFontObject("GameFontNormalLarge")
	end

	abiShowFrameHelp(1)
end



function abiShopMessageFrame2_OnEnter(passed)

	if abiScrollTableOffset2~=nil and passed<=#abiScrollList2 and abiShoppingTarget==0 then
		abiRealm=GetRealmName() --just make sure
		local abiItemName,abiWhich,_=strsplit("%",abiScrollList2[passed+abiScrollTableOffset2])
		abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiItemName])
		abiFillFrame3(abiItemName,abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRatio1,abiWhich)
		getglobal("abiShopFrame2String"..passed):SetTextColor(1,1,1,1)
		getglobal("abiShopFrame2String"..passed):SetFontObject("GameFontNormalLarge")
	end

	abiShowFrameHelp(2)
end



function abiEmptyFrame3()
	abiShopFrame3ItemNameString:SetText("----------")
	abiShopFrame3Cash1:SetText("----------")
	abiShopFrame3Cash2:SetText("----------")
	abiShopFrame3Cash3:SetText("----------")
	abiShopFrame3Cash4:SetText("----------")
	abiShopFrame3Ratio:SetText("0 sold : 0 auctioned")
	abiShopFrame3String1:SetText("|cffffffffBuy-Hi :")
	abiShopFrame3String2:SetText("|cffffffffBuy-Lo :")
	abiShopFrame3String3:SetText("|cffffffffSold-Hi :")
	abiShopFrame3String4:SetText("|cffffffffSold-Lo :")
end



function abiEmptyFrame1()

	for abiloop=1,10 do
		getglobal("abiShopFrame1String"..abiloop):SetText("")
	end

end



function abiEmptyFrame2()

	for abiloop=1,10 do
		getglobal("abiShopFrame2String"..abiloop):SetText("")
		getglobal("abiShopFrame2Cash"..abiloop):SetText("")
	end

end



function abiFillFrame3(item,t1,t2,t3,t4,ratio,which)
	local abiRat1,abiRat2
	abiRat1,abiRat2=abiDecodeRatio(ratio)
	abiShopFrame3ItemNameString:SetText("|cffffffff"..string.sub(item,1,35))

	if t1>0 then
		abiShopFrame3Cash1:SetText(abiCreatePriceStringIcons(t1,0))
	end

	if t2>0 then
		abiShopFrame3Cash2:SetText(abiCreatePriceStringIcons(t2,0))
	end

	if t3>0 then
		abiShopFrame3Cash3:SetText(abiCreatePriceStringIcons(t3,0))
	end

	if t4>0 then
		abiShopFrame3Cash4:SetText(abiCreatePriceStringIcons(t4,0))
	end

	abiShopFrame3Ratio:SetText(abiRat1.." sold : "..abiRat2.." auctioned")
	abiShopFrame3String1:SetText("|cffffffffBuy-Hi :")
	abiShopFrame3String2:SetText("|cffffffffBuy-Lo :")
	abiShopFrame3String3:SetText("|cffffffffSold-Hi :")
	abiShopFrame3String4:SetText("|cffffffffSold-Lo :")
	which=tonumber(which)

	if which==1 then
		abiShopFrame3String1:SetText"|cffff4040Buy-Hi :"
	end

	if which==2 then
		abiShopFrame3String2:SetText"|cffff4040Buy-Lo :"
	end

	if which==3 then
		abiShopFrame3String3:SetText"|cffff4040Sold-Hi :"
	end

	if which==4 then
		abiShopFrame3String4:SetText"|cffff4040Sold-Lo :"
	end

end



function abiShopFrame1Click(passed,button)

	if abiShoppingTarget~=0 then
		return
	end

	abiRealm=GetRealmName() --just make sure
	local abiItemName,abiNewItem,abiItemPercentPrice
	local abiItemPrice={}
	local abiList2Name
	local abiInfo
	local abitemppassed=passed
	passed=passed+abiScrollTableOffset1

	if passed>#abiScrollList1 then
		return
	end

	abiItemName=abiScrollList1[passed]

	if button=="RightButton" then
		-- get the item name
		abiItemPrice[1],abiItemPrice[2],abiItemPrice[3],abiItemPrice[4],_,_,_=abiDecodeIndex(abiPriceIndex[abiRealm][abiItemName])

		-- see if abiItemName already in scroll list 2
		abiNewItem=1

		for abiloop=1,#abiScrollList2 do
			abiList2Name,_,_=strsplit("%",abiScrollList2[abiloop])

			if abiItemName==abiList2Name then
				abiNewItem=0
			end

		end

		if abiNewItem==1 then
			abiItemPercentPrice=tonumber(math.floor(abiItemPrice[abiShopCosting]*abiShopSlider1:GetValue()/100))

			if abiItemPercentPrice<1 then
				abiItemPercentPrice=1
			end

			abiInfo=abiItemName.."%"..tostring(abiShopCosting).."%"..tostring(abiItemPercentPrice)
			abiShoppingList[abiRealm][abiItemName]=tostring(abiShopCosting).."%"..tostring(abiItemPercentPrice)
			table.insert(abiScrollList2,1,abiInfo)
			abiShoppingScrollFrame2:SetVerticalScroll(0)
			abiShoppingScroll2Update()
			abiDisplayScroll2Items(#abiScrollList2)
			table.remove(abiScrollList1,passed)
			abiEmptyFrame1()
			abiShoppingScroll1Update()
			abiDisplayScroll1Items(#abiScrollList1)
			abiEmptyFrame3()
			abiShopMessageFrame1_OnEnter(abitemppassed)
		end

	end

	if button=="LeftButton" then

		if IsShiftKeyDown()==1 then
			abiItemName=abiShortenName(abiItemName)
		end
		--Put the item name into the BrowseName field of main AH window
		BrowseName:SetText(abiItemName)

		if (IsAddOnLoaded("Auctionator")) then
			Atr_Search_Box:SetText(abiItemName)
		end

		return
	end

end



function abiGenerateButtonClicked()

	if abiShoppingTarget==0 then
		abiRealm=GetRealmName()
		local k,k2,v2,rat1,rat2
		abiScrollList1=table.wipe(abiScrollList1)

		for k,v in pairs(abiPriceIndex) do
			--k is the realm name

			if abiRealm==k then

				for k2,v2 in pairs(abiPriceIndex[k]) do
					--k2 is name field, v2 is price index field
					abiBhigh1,_,abiShigh1,_,_,_,_=strsplit("%",v2)
					abiBhigh1=tonumber(abiBhigh1)
					abiShigh1=tonumber(abiShigh1)

-- originally the shopping list could only contain those items that had been purchased and sold through the Auction House - or AH addons.
--					if abiBhigh1>0 and abiShigh1>0 and abiShoppingList[abiRealm][k2]==nil then

-- now we allow the shopping list to be made from just those items that have been sucessfully sold.
					if abiShigh1>0 and abiShoppingList[abiRealm][k2]==nil then

						abiScrollList1[#abiScrollList1+1]=k2
					end

				end

			end

		end

		table.sort(abiScrollList1,abiLowHigh)
		abiShoppingScroll1Update()
		abiDisplayScroll1Items(#abiScrollList1)

		if #abiScrollList1==0 then
			abiShopFrame1Help3:SetText("|cffffffffNo items found")
			abiMessageWait=time()+3
		else
			k=" item"
			if #abiScrollList1>1 then
				k=" items"
			end
			abiShopFrame1Help3:SetText("|cffffffff"..#abiScrollList1..k.." can be added to Shopping List")
			abiMessageWait=time()+3
		end
	end
end



function abiShoppingSearchButton_OnClick()

	if abiShoppingTarget~=0 then
		return
	end

	local t1,t2,t3
	local abiType

	abiBargains=table.wipe(abiBargains)

	for abiloop=1,#abiAHImage do
		abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid=abiDecodeImage(abiAHImage[abiloop])

		if abiShopStack==1 then
			abiImagePrice=math.floor(abiImagePrice/abiImageCount)
		end

		_,_,_,_,_,abiType,_,_,_,_=GetItemInfo(abiItemLink)

		if (abiCheckTheType(abiType)==1 and abiUsingClasses==1) or abiUsingClasses==0 then

			for abiloop2=1,#abiScrollList2 do
				t1,t2,t3=strsplit("%",abiScrollList2[abiloop2])
				-- t1=name, t2=costtype, t3=percentprice
				t3=tonumber(t3)

				if t1==abiImageName and (abiImagePrice<=t3 or abiShoppingPricesButton:GetChecked()==1) then
					abiBargains[#abiBargains+1]=abiMakeFullPrice(abiImagePrice).."%"..tostring(abiloop)
				end

			end

		end

	end

	if #abiBargains>0 then
		t1="|cffffffff"..#abiBargains.." matching auction"

		if #abiBargains>1 then
			t1=t1.."s"
		end

		t1=t1.." found"
		abiShopFrame1Help3:SetText(t1)
		abiMessageWait=time()+3
	else
		abiShopFrame1Help3:SetText("|cffffffffNo matching auctions found")
		abiMessageWait=time()+3
	end
end



function abiShoppingScroll1Update()

	if #abiScrollList1~=0 then
		FauxScrollFrame_Update(abiShoppingScrollFrame1,#abiScrollList1,10,15)
		-- #abiScrollList1 is max entries, 10 is number of lines, 15 is pixel height of each line
		abiScrollTableOffset1=FauxScrollFrame_GetOffset(abiShoppingScrollFrame1)
		abiDisplayScroll1Items(#abiScrollList1)
		abiShoppingScrollFrame1:Show()
	end

end



function abiShoppingScroll2Update()

	if abiShoppingTarget==0 then
		for abiloop=1,10 do
			getglobal("abiShopFrame2String"..abiloop):SetFontObject("GameFontNormal")
		end

		abiShoppingButton3:Disable()

		if #abiScrollList2~=0 then
			FauxScrollFrame_Update(abiShoppingScrollFrame2,#abiScrollList2,10,15)
			-- #abiScrollList2 is max entries, 10 is number of lines, 15 is pixel height of each line
			abiScrollTableOffset2=FauxScrollFrame_GetOffset(abiShoppingScrollFrame2)
			abiDisplayScroll2Items(#abiScrollList2)
			abiShoppingScrollFrame2:Show()
		end
	end
end



function abiShopFrame2Click(passed,button)
	local itemname
	local t1,t2,t3

	if passed>#abiScrollList2 or abiShoppingTarget~=0 then
		return
	end

	if button=="LeftButton" then
		abiShoppingTarget=passed
		abiShoppingButton3:Enable()
		abiGenerateButton:Disable()
		abiShoppingSearchButton:Disable()
		t1,t2,t3=strsplit("%",abiScrollList2[passed+abiScrollTableOffset2])
		abiShopCosting=tonumber(t2)
		abiShopCostingButton:SetText(abiCostingButtonText[abiShopCosting])
		return
	end

	if button=="RightButton" then
		AuctionFrame:SetAlpha(0.5)
		abiShoppingTarget=passed
		abiRemovingNumber=passed+abiScrollTableOffset2
		itemname,_,_=strsplit("%",abiScrollList2[passed+abiScrollTableOffset2])
		abiRemovingName=itemname
		StaticPopup_Show("abiRemoveShoppingListConfirm",itemname)
	end
end



StaticPopupDialogs["abiRemoveShoppingListConfirm"]={
	text="Remove %s|nfrom the shopping list?",
	button1="Accept",
	button2="Cancel",

	OnAccept = function(self)
		table.remove(abiScrollList2,abiRemovingNumber)
		abiShoppingList[abiRealm][abiRemovingName]=nil
		abiRemovingNumber=0
		abiRemovingName=""
	end,

	OnCancel = function(self)
	end,

	OnHide = function(self)
		AuctionFrame:SetAlpha(1)
		getglobal("abiShopFrame2String"..abiShoppingTarget):SetTextColor(1,0.9,0,0.9)
		getglobal("abiShopFrame2String"..abiShoppingTarget):SetFontObject("GameFontNormal")
		abiShoppingTarget=0
		abiEmptyFrame3()
		abiShoppingScroll2Update()
		abiEmptyFrame2()
		abiDisplayScroll2Items(#abiScrollList2)
	end,

	showAlert = 1,
	timeout=0,
}



function abiShowFrameHelp(passed)
	if time()>abiMessageWait then
		abiShopFrame1Help3:SetText("|cffffffff"..abiHelpText[passed])
	end
end



function abiShopCostingChange()
	abiRealm=GetRealmName()
	abiShopCosting=abiShopCosting+1

	if abiShopCosting==5 then
		abiShopCosting=1
	end

	abiShopCostingButton:SetText(abiCostingButtonText[abiShopCosting])

	if abiShoppingTarget~=0 then

		local abiItemPrice={}
		local abiItemName
		local abiNewPrice
		abiItemName,_,_=strsplit("%",abiScrollList2[abiShoppingTarget+abiScrollTableOffset2])
		abiItemPrice[1],abiItemPrice[2],abiItemPrice[3],abiItemPrice[4],_,_,_=abiDecodeIndex(abiPriceIndex[abiRealm][abiItemName])
		abiNewPrice=abiItemPrice[abiShopCosting]*abiShopSlider1:GetValue()
		abiNewPrice=math.floor(abiNewPrice/100)

		if abiNewPrice<1 then
			abiNewPrice=1
		end

		abiScrollList2[abiShoppingTarget+abiScrollTableOffset2]=abiItemName.."%"..tostring(abiShopCosting).."%"..tostring(abiNewPrice)
		getglobal("abiShopFrame2Cash"..abiShoppingTarget):SetText(abiCreatePriceStringIcons(abiNewPrice,0))
		abiShoppingList[abiRealm][abiItemName]=tostring(abiShopCosting).."%"..tostring(abiNewPrice)

	end

end



function abiShopSlider1_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "Adjust price for the selected item";
	getglobal(slider.."Low"):SetText("");
	getglobal(slider.."High"):SetText("");
	getglobal(slider.."Text"):SetText("100");
end



function abiSliderValueChanged()
	abiRealm=GetRealmName()
	local abiWhich,abiValue
	local t1,t2,t3
	local abiItemPrice={}
	abiShopSlider1Text:SetText(abiShopSlider1:GetValue())

	if abiShoppingTarget==0 then
		return
	end

	abiWhich=abiShoppingTarget+abiScrollTableOffset2
	abiValue=abiShopSlider1:GetValue()
	t1,t2,_=strsplit("%",abiScrollList2[abiWhich])
	t2=tonumber(t2)
	abiItemPrice[1],abiItemPrice[2],abiItemPrice[3],abiItemPrice[4],_,_,_=abiDecodeIndex(abiPriceIndex[abiRealm][t1])
	t3=math.floor((abiItemPrice[t2]*abiValue)/100)

	if t3<1 then
		t3=1
	end

	abiScrollList2[abiWhich]=t1.."%"..tostring(t2).."%"..tostring(t3)
	getglobal("abiShopFrame2Cash"..abiShoppingTarget):SetText(abiCreatePriceStringIcons(t3,0))
	abiShoppingList[abiRealm][t1]=tostring(t2).."%"..tostring(t3)
end



function abiShopUseClassChange()
	abiUsingClasses=1-abiUsingClasses

	if abiUsingClasses==1 then
		abiShopUseClassButton:SetText("Use Classes")
	else
		abiShopUseClassButton:SetText("Don't Use")
	end

end



function abiShoppingButton3_OnClick()
	abiShoppingButton3:Disable()
	getglobal("abiShopFrame2String"..abiShoppingTarget):SetTextColor(1,0.9,0,0.9)
	getglobal("abiShopFrame2String"..abiShoppingTarget):SetFontObject("GameFontNormal")
	abiShoppingTarget=0
	abiEmptyFrame3()
	abiShoppingSearchButton:Enable()
	abiGenerateButton:Enable()
	abiShoppingScroll2Update()
end



function abiShopStackButton_OnClick()
	abiShopStack=1-abiShopStack
	if abiShopStack==0 then
		abiShopStackButton:SetText("Buyout Price")
	else
		abiShopStackButton:SetText("Unit Price")
	end
end



function abiSortShoppingList()

	if abiShoppingTarget==0 then
		table.sort(abiScrollList2,abiLowHigh)
		abiDisplayScroll2Items(#abiScrollList2)
	end

end



function abiShoppingPricesButton_OnClick()

	if abiShoppingPricesButton:GetChecked()==1 then
		abiIgnoreShopPrice=1
	else
		abiIgnoreShopPrice=0
	end
	abiShoppingPricesShowHelp()
end



function abiShoppingPricesShowHelp()
	abiShowFrameHelp(12+abiIgnoreShopPrice)
end