--Functions for Abigail 1.21
--13/06/12


function abiMakeFullPrice(passed)
	local p
	p=tostring(passed)
	-- convert p to a number string ie 0000001234
	p=string.rep("0",10-#p)..p
	return p
end



function abiPutTextBackToNormal()

	for abiloop=1,8 do
		getglobal("abiFS"..abiloop.."1"):SetTextColor(1,0.9,0,0.9)
		getglobal("abiFS"..abiloop.."1"):SetFontObject("GameFontNormal")
	end

end



function abiDecodeItemLink(t)
	_,_,_,t,_=strsplit("|",t)
	t=string.sub(t,3,-2)
	return t
end



function abiShortenName(ret1)
	local temp1
	temp1,_=string.find(ret1," of ")
	if temp1~=nil then
		ret1=string.sub(ret1,1,temp1)
	end
	return ret1
end



function abiDecodeSellAllTable(passed)
	local ret1,ret2,ret3,ret4,ret5=strsplit("%",passed)
	ret2=tonumber(ret2)
	ret3=tonumber(ret3)
	ret4=tonumber(ret4)
	return ret1,ret2,ret3,ret4,ret5
end



function abiUpdatePriceHistory(t)
	local abiFoundPlace=0

	for l=1,#abiHistoryCost do

		if t>=(abiHistoryCost[l]*0.9) and t<=(abiHistoryCost[l]*1.1) then
			abiHistorySeen[l]=abiHistorySeen[l]+1
			return
		end

	end

	--need to check if 15 price records already kept for this item.
	--if not, put price in the next available space.

	if #abiHistoryCost<15 then
		abiHistoryCost[#abiHistoryCost+1]=t
		abiHistorySeen[#abiHistorySeen+1]=1
		return
	end

	-- OR, no spaces available, so slot inbetween nearest prices

	for loop=2,15 do
		if t<abiHistoryCost[loop-1] and t>abiHistoryCost[loop] then
			abiFoundPlace=loop
		end
	end

	if abiFoundPlace~=0 then
		table.insert(abiHistoryCost,abiFoundPlace,t)
		table.insert(abiHistorySeen,abiFoundPlace,1)

		if abiFoundPlace>7 then
			table.remove(abiHistoryCost,1)
			table.remove(abiHistorySeen,1)
		else
			table.remove(abiHistoryCost,16)
			table.remove(abiHistorySeen,16)
		end

		return
	end

	if t>abiHistoryCost[1] then
		table.insert(abiHistoryCost,1,t)
		table.insert(abiHistorySeen,1,1)
		table.remove(abiHistoryCost,16)
		table.remove(abiHistorySeen,16)
		return
	end

	if t<abiHistoryCost[15] then
		abiHistoryCost[16]=t
		abiHistorySeen[16]=1
		table.remove(abiHistoryCost,1)
		table.remove(abiHistorySeen,1)
	end

end



function abiDecodeImage(t)
	local ret1,ret2,ret3,ret4,ret5,ret6
	--Name, Stack, Price, ItemLink,BidTime,BidAmount
	ret1,ret2,ret3,ret4,ret5,ret6=strsplit("%",t)
	ret2=tonumber(ret2)
	ret3=tonumber(ret3)
	ret5=tonumber(ret5)
	ret6=tonumber(ret6)
	return ret1,ret2,ret3,ret4,ret5,ret6
end



function abiDecodeIndex(t)
	local ret1,ret2,ret3,ret4,ret5,ret6,ret7
	--BHigh,Blow,Shigh,Slow,RecentSold,Ratio,PriceHistory
	ret1,ret2,ret3,ret4,ret5,ret6,ret7=strsplit("%",t)
	ret1=tonumber(ret1)
	ret2=tonumber(ret2)
	ret3=tonumber(ret3)
	ret4=tonumber(ret4)
	ret5=tonumber(ret5)
	return ret1,ret2,ret3,ret4,ret5,ret6,ret7
end



function abiDecodePriceHistory(t)
	abiHistoryCost=table.wipe(abiHistoryCost)
	abiHistorySeen=table.wipe(abiHistorySeen)

	for k,v in string.gmatch(t,"(%w+)*(%w+)") do
		abiHistoryCost[#abiHistoryCost+1]=tonumber(k)
		abiHistorySeen[#abiHistorySeen+1]=tonumber(v)
	end

end



function abiEncodePriceHistory()
	local ret1=""
	local temptable={}

	for l=1,#abiHistoryCost do
		temptable[l]=abiMakeFullPrice(abiHistoryCost[l]).."*"..tostring(abiHistorySeen[l])
	end

	table.sort(temptable,abiHighLow)

	for l=1,#temptable do
		ret1=ret1..temptable[l]

		if l~=#temptable then 
			ret1=ret1..","
		end

	end

	return ret1
end



function abiConsolodatePrices()
	local abiHalfIt=0

	for l=1,#abiHistoryCost do

		if abiHistorySeen[l]>8000 then
			abiHalfIt=1
		end

	end

	if abiHalfIt==1 then

		for l=1,#abiHistoryCost do
			abiHistorySeen[l]=math.floor(abiHistorySeen[l]/2)

			if abiHistorySeen[l]<1 then
				abiHistorySeen[l]=1

			end

		end

	end

end



function abiFindHighestPrice()
	local t=0
	local v=0

	for k=1,#abiHistoryCost do

		if abiHistoryCost[k]>v then
			v=abiHistoryCost[k]
			t=k
		end

	end

	k=abiHistoryCost[1]
	abiHistoryCost[1]=abiHistoryCost[t]
	abiHistoryCost[t]=k
	k=abiHistorySeen[1]
	abiHistorySeen[1]=abiHistorySeen[t]
	abiHistorySeen[t]=k
end



function abiFindAveragePrice()
	-- returns abiAverage
	--should have already used abiDecodePriceHistory to get all details into History Cost and Seen arrays
	local abiAverage=0
	local abiSeen=0

	for l=1,#abiHistoryCost do
		abiAverage=abiAverage+(abiHistoryCost[l]*abiHistorySeen[l])
		abiSeen=abiSeen+abiHistorySeen[l]
	end

	abiAverage=math.floor(abiAverage/abiSeen)
	return abiAverage
end



function abiClearExtraInformation(passed)

	if passed==0 then

		for abiloop=1,15 do
			getglobal("abiCB"..abiloop):SetChecked(0)
			getglobal("abiPS"..abiloop):Hide()
			getglobal("abiCB"..abiloop):Hide()
		end

	end

end



function abiCreatePriceString(passed)
	local abiGold=floor(passed/10000)
	local abiSilver=string.format("%02d",floor((passed-(abiGold*10000))/100))
	local abiCopper=string.format("%02d",mod(passed,100))
	return abiGold.."g, "..abiSilver.."s, "..abiCopper.."c"
end



function abiCreatePriceStringIcons(passed,prefix)
	local abiGold=floor(passed/10000)
	local abiSilver=floor((passed-(abiGold*10000))/100)
	local abiCopper=mod(passed,100)

	ret1=format(GOLD_AMOUNT_TEXTURE,abiGold,0,0).."  "

	if abiSilver<10 then
		ret1=ret1.."0"
	end

	ret1=ret1..format(SILVER_AMOUNT_TEXTURE,abiSilver,0,0).."  "

	if abiCopper<10 then
		ret1=ret1.."0"
	end

	ret1=ret1..format(COPPER_AMOUNT_TEXTURE,abiCopper,0,0)

	if prefix~=0 then
		ret1=prefix.." "..ret1
	end

	return ret1
end	



function abiMakeTheHeaders()
	
	CreateFrame("Button","abiTH1",AuctionFrame,"AbigailButtonTemplate")
	abiTH1:SetWidth(264)
	abiTH1:SetHeight(20)
	abiTH1:SetPoint("TOPLEFT",AuctionFrame,"TOP",-330,-54)
	abiTH1:SetText("Items For Sale")

	CreateFrame("Button","abiTH2",AuctionFrame,"AbigailButtonTemplate")
	abiTH2:SetWidth(130)
	abiTH2:SetHeight(20)
	abiTH2:SetScript("OnClick",abiSortByBuyout)
	abiTH2:SetPoint("TOPLEFT",AuctionFrame,"TOP",-69,-54)
	abiTH2:SetText("Buyout")

	CreateFrame("Button","abiTH3",AuctionFrame,"AbigailButtonTemplate")
	abiTH3:SetWidth(130)
	abiTH3:SetHeight(20)
	abiTH3:SetPoint("TOPLEFT",AuctionFrame,"TOP",59,-54)
	abiTH3:SetText("Average")

	CreateFrame("Button","abiTH4",AuctionFrame,"AbigailButtonTemplate")
	abiTH4:SetWidth(130)
	abiTH4:SetHeight(20)
	abiTH4:SetScript("OnClick",abiSortByProfit)
	abiTH4:SetPoint("TOPLEFT",AuctionFrame,"TOP",188,-54)
	abiTH4:SetText("Profit")
	
	CreateFrame("Button","abiTH5",AuctionFrame,"AbigailButtonTemplate")
	abiTH5:SetWidth(60)
	abiTH5:SetHeight(20)
	abiTH5:SetScript("OnClick",abiSortByPercent)
	abiTH5:SetPoint("TOPLEFT",AuctionFrame,"TOP",317,-54)
	abiTH5:SetText("%age")

	abiOptionsHeader=abiHomeScreenFrame:CreateFontString()
	abiBargainsHeader=abiDataFrame:CreateFontString()
	abiShoppingHeader=abiShoppingFrame:CreateFontString()
	abiSellingHeader=abiSellingFrame:CreateFontString()
	abiOptionsHeader:SetPoint("TOPLEFT",abiHomeScreenFrame,"TOPLEFT",300,50)
	abiOptionsHeader:SetFontObject(GameFontNormal)
	abiOptionsHeader:SetText("Abigail 1.21 - Options Screen")
	abiBargainsHeader:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",300,50)
	abiBargainsHeader:SetFontObject(GameFontNormal)
	abiBargainsHeader:SetText("Abigail 1.21 - Bargain Search Results")
	abiShoppingHeader:SetPoint("TOPLEFT",abiShoppingFrame,"TOPLEFT",300,50)
	abiShoppingHeader:SetFontObject(GameFontNormal)
	abiShoppingHeader:SetText("Abigail 1.21 - Shopping Screen")
	abiSellingHeader:SetPoint("TOPLEFT",abiSellingFrame,"TOPLEFT",300,50)
	abiSellingHeader:SetFontObject(GameFontNormal)
	abiSellingHeader:SetText("Abigail 1.21 - Selling Screen")


	abiDisplayTheFiveHeader=abiDataFrame:CreateFontString()
	abiDisplayTheFiveHeader:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",80,-215)
	abiDisplayTheFiveHeader:SetFontObject(GameFontNormal)
	abiDisplayTheFiveHeader:SetText("|cffffffffItem Name                                                      Buyout Value            Bid Value                  Buyout per Unit")
	abiDisplayTheFiveHeader:Hide()


end



function MinSpendSlider_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "This is the Minimum Gold you want to spend per auction.";
	getglobal(slider.."Low"):SetText("");
	getglobal(slider.."High"):SetText("");
	getglobal(slider.."Text"):SetText("0");
end



function MaxSpendSlider_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "This is the Maximum Gold you want to spend per auction.";
	getglobal(slider.."Low"):SetText("");
	getglobal(slider.."High"):SetText("");
	getglobal(slider.."Text"):SetText("0");
end



function ProfitMarginSlider_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "This is the Minimum Percentage Profit Margin you are looking for.";
	getglobal(slider.."Low"):SetText("");
	getglobal(slider.."High"):SetText("");
	getglobal(slider.."Text"):SetText("30");
end



function CashProfitSlider_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "This is the Minimum Gold Profit you are looking for.";
	getglobal(slider.."Low"):SetText("");
	getglobal(slider.."High"):SetText("");
	getglobal(slider.."Text"):SetText("0");
end



function DeviationSlider_OnLoad(slider)
	local sl=getglobal(slider)
	sl.tooltipText = "This is the Maximum Price Deviation allowed.";
	getglobal(slider.."Low"):SetText("");
	getglobal(slider.."High"):SetText("");
	getglobal(slider.."Text"):SetText("0");
end



function AbigailMoneyFrame_Update(frameName, money, quantity, colour)
	local frame

	if ( type(frameName) == "table" ) then
		frame = frameName
		frameName = frame:GetName()
	else
		frame = getglobal(frameName)
	end

	-- Breakdown the money into denominations
	local gold=floor(money/10000)
	local silver=floor((money-(gold*10000))/100)
	local copper=mod(money,100)

	local goldButton = getglobal(frameName.."GoldButton")
	local silverButton = getglobal(frameName.."SilverButton")
	local copperButton = getglobal(frameName.."CopperButton")

	if quantity~=0 then
		gold=tostring(quantity).."  x  "..tostring(gold)
	end

	-- Set values for each denomination
	goldButton:SetText(colour..gold)
	goldButton:SetWidth(goldButton:GetTextWidth() + 13)
	goldButton:Show()
	silverButton:SetText(colour..silver)
	silverButton:SetWidth(30)
	silverButton:Show()
	copperButton:SetText(colour..copper)
	copperButton:SetWidth(30)
	copperButton:Show()

end



function CheckIfOneOfMyAuctions(passedname,passedcount,passedprice)
	-- returns zero if not one of my auctions

	if (#abiMyTempAuctions==0) or (#abiMyTempAuctions==nil) then
		return 0
	end

	for i=1,#abiMyTempAuctions do

		if abiMyTempAuctions[i]==passedname.."%"..passedcount.."%"..passedprice then
			table.remove(abiMyTempAuctions,i)
			return 1
		end

	end

	return 0

end



function CheckIfOneOfMyBids(passedname,passedcount,passedprice)
	-- returns zero if I have not bid on this item

	if (#abiMyTempBids==0) or (#abiMyTempBids==nil) then
		return 0
	end

	for i=1,#abiMyTempBids do

		if abiMyTempBids[i]==passedname.."%"..passedcount.."%"..passedprice then
			table.remove(abiMyTempBids,i)
			return 1
		end

	end

	return 0

end



function abiCheckDeviation(passed) -- the image price
	local abiTemporaryNumber=DeviationSlider:GetValue()

	if abiTemporaryNumber==0 then
		return 1
	end

	if passed>(abiHistoryCost[1]*(100+abiTemporaryNumber)/100) then
		return 0
	end

	if passed<abiHistoryCost[#abiHistoryCost]*(1-(abiTemporaryNumber/100)) then
		return 0
	end

	return 1
end



function abiCheckTheType(passed)
	-- checks for each item type	

	for abiloop=1,10 do

		if getglobal("abiTypeCheck"..abiloop):GetChecked()==1 and passed==abiTypeTable[abiloop] then
			return 1
		end

	end
	return 0
end



function abiCheckThePrice(ItemPrice,AveragePrice,ActualBuyoutPrice)
	-- if abiBidBuyoutButton is checked - the AveragePrice is actually the Buyout Price of the item
	local tempcount=ActualBuyoutPrice/ItemPrice
	if ItemPrice>=AveragePrice then
		return 0
	end

	if ActualBuyoutPrice<MinSpendSlider:GetValue()*10000 or
	ActualBuyoutPrice>(MaxSpendSlider:GetValue()*10000) and MaxSpendSlider:GetValue()~=0 then
		return 0
	end

	if ((AveragePrice-ItemPrice)/ItemPrice)<(ProfitMarginSlider:GetValue()/100) or
	((AveragePrice*tempcount)-ActualBuyoutPrice)<CashProfitSlider:GetValue()*10000 then
		return 0
	end

	return 1
end



function HowmanySecondsDelay(passed)
	local delay
	delay=time()+passed
	while time()<delay do
	end
end



function abiCalculateStackSize(passed)
	local abitemp
	if string.sub(passed,-1)~=")" then
		return 1
	end

	abitemp=tonumber(string.sub(passed,string.find(passed,"%(")+1,#passed-1))
	if abitemp==nil then
		abitemp=1
	end
	return abitemp

end



function abiCreateExtraBits()

	f=CreateFrame("Button","abiCreateSnapShotButton",AuctionFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",584,-409)
	f:SetScript("OnClick",abiCreateSnapShotButton_OnClick)
	f:SetWidth(122)
	f:SetHeight(24)
	f:SetText("Take Snapshot")
	f:Hide()

	f=CreateFrame("Button","abiBargainSearchButton",AuctionFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",704,-409)
	f:SetScript("OnClick",abiBargainSearchButton_OnClick)
	f:SetWidth(122)
	f:SetHeight(24)
	f:SetText("Search Bargains")
	f:Disable()
	f:Hide()

	f=CreateFrame("Button","abiDeleteSelectedButton",AuctionFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",584,-409)
	f:SetScript("OnClick",abiDeleteSelectedButton_OnClick)
	f:SetWidth(81)
	f:SetHeight(24)
	f:SetText("Delete")
	f:Disable()
	f:Hide()

	f=CreateFrame("Button","abiCancelDeleteButton",AuctionFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",665,-409)
	f:SetScript("OnClick",abiCancelDeleteButton_OnClick)
	f:SetWidth(81)
	f:SetHeight(24)
	f:SetText("Cancel")
	f:Disable()
	f:Hide()

	f=CreateFrame("Button","abiForcePriceButton",AuctionFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",746,-409)
	f:SetScript("OnClick",abiForceButton_OnClick)
	f:SetWidth(81)
	f:SetHeight(24)
	f:SetText("Force")
	f:Disable()
	f:Hide()

	f=CreateFrame("Button","abiNoBargainsFoundButton",AuctionFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",584,-409)
	f:SetWidth(242)
	f:SetHeight(24)
	f:SetText("No Bargains Have Been Found")
	f:Disable()
	f:Hide()

	f=CreateFrame("Button","abiNoSnapshotTakenButton",AuctionFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",584,-409)
	f:SetWidth(242)
	f:SetHeight(24)
	f:SetText("No Snapshot Has Been Taken")
	f:Disable()
	f:Hide()

	f=CreateFrame("Button","abiUseOtherAddonScanButton",AuctionFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",514,-44)
	f:SetScript("OnClick",abiUseOtherAddonScan_OnClick)
	f:SetWidth(240)
	f:SetHeight(24)
	f:SetText("Use Other Addon Scan / 00000")
	f:Disable()
	f:Hide()

	f=CreateFrame("Button","abiSelectWhichBidToUseButton",abiHomeScreenFrame,"UIPanelButtonTemplate2")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",514,-336)
	f:SetScript("OnClick",abiSelectWhichBidToUseButton_OnClick)
	f:SetWidth(150)
	f:SetHeight(24)
	f:SetText("Bids Under 30 Mins")
	f:Enable()
	f:Hide()

	f=AuctionFrame:CreateFontString("abiShowingWhichBargainsString")
	f:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",490,-35)
	f:SetFontObject(GameFontNormal)
	f:SetWidth(289)
	f:SetHeight(20)
	f:SetJustifyH("RIGHT")
	f:SetText(" ")
	f:Hide()

end


