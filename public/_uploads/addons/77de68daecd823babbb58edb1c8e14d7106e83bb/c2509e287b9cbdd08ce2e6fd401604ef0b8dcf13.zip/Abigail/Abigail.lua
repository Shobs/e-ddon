-- Author      : Phil Lawson
-- Create Date : 13/6/2012
-- Abigail 1.21 addon
-- Works with 4.3 and Auctionator 3.0.0
-- Adapted to attempt solve problem of having 42000+ auctions

-- Updated to work with Auctionator
-- Now takes note of Auctionators Full Scan and greys-out the Take Snapshot Button.
-- Also, if a full scan is done by Auctionator, Abigail will use that information to create a snaphot.
-- This addon may be freely distributed. It may not be distributed for profit, and it must declare the author to be Phil Lawson.

-- No addon libraries used.
-- Massive thanks to J.Whitehead II for the help given through wowprogramming.com, the website that accompanies the World of Warcraft Programming books.

-- abiVariables[1-25]
-- time,minspend,maxspend,profit,cashprofit,deviation
-- TooltipCB1,TooltipCB2,TooltipCB3,TooltipCB4,TooltipCB5,TooltipCB6
-- (2 spare - used to be classes Quiver and Projectile),10 item classes
-- 25 is the last version number that needed the price history file upgrading, checked against abiLastPHUpgradeVersion and if not the same then upgrade routine is called.

-- *****************************************************

-- after every blizzard update and/or auctionator update, must check that the following variables, labels, sub.strings still work accurately.
-- Blizzards Texts - GOLD_AMOUNT_TEXTURE, SILVER_AMOUNT_TEXTURE, COPPER_AMOUNT_TEXTURE, LAST_ITEM_BUYOUT, LAST_ITEM_AUCTIONED, LAST_ITEM_START_BID


-- From Blizzards own code - OpenMailFrame.money, BrowseName:SetText, MoneyInputFrame_SetCopper(BuyoutPrice, abiShigh1), MoneyInputFrame_SetCopper(StartPrice, abiShigh1)


-- From Auctionator - Atr_Search_Box:SetText, gAtr_FullScanStart = time(), gAtr_FullScanDur = nil

-- Functions hooked - GameTooltip:"OnTooltipSetItem", GameTooltip:"OnTooltipCleared", GameTooltip:"SetBagItem",GameTooltip:"SetInventoryItem"
-- OpenMailMoneyButton:GetScript("OnClick"), OpenMailAttachmentButton1:GetScript("OnClick")
-- AuctionFrameTab_OnClick:abiFrameTab_OnClick
-- Atr_FullScanDone:HookScript("OnClick",abiAuctionatorScanned)
-- Atr_FullScanStartButton:HookScript("OnClick",abiAuctionatorStarted)

-- Make sure the classes list is the same (Use GetAuctionItemClasses()) to see full list.

-- *****************************************************


local abiStackSize
local abiLastPHUpgradeVersion=1.09
local abiBidTime=1
local abiAuctionatorScanStarted=0
local abiSetForLookingAtNextPage=0
local abiBuyThisItem
local abiHolding=nil
local abiBuyThisPrice
local abiHowSorted=0
local abiDoingABuyout=0
local abiPopupShown=0
local abiSearchingWhichPage=0
local abiOptionsTabNum
local abiBargainsTabNum
local abiShoppingTabNum
local abiSellingTabNum
local abiEditingPrices=0
local abiTableOffset=0
local abiname,abicount,abibuyoutPrice,abiminBid,abiminIncrement,abibidAmount
local abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid
local abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory

local abiImageNumber,abiIndexNumber
local abiHowManyAuctions
local abiAreWeReadingTheAH=0
local abiCanTakeSnapShot=0
local abiTooltipAdded=false
local abiMailBox=0
local abiRealm=GetRealmName()
local abiBuyoutFound=0
local abiMyAuctionPlaced=0
local abiTablePosition
local abiOnTheButton=0
local abiSortingByPercent=0
local abiMultiBuyTotal=0
local abiMultiBuyValue=0
local abiBuyoutType
local abiButtonHook
local abiInboxHook
local abiAuctionatorCreateAuctionHook
local abiItemInAuctionSlot

local abiDisplayingFiveAuctions=0
local abiDisplayFivePage=0

local abiBuying={}
local abiFiveAuctions={}



function abiHomeScreenFrame_OnLoad()
	abiAHImage={}
	abiBargains={}
	abiMyAuctions={}
	abiHistoryCost={}
	abiHistorySeen={}
	abiMyTempAuctions={}
	abiMyBids={}
	abiMyTempBids={}
	abiOptionsHelpText={}
	abiBargainsHelpText={}
	abiOptionsHelpText[1]="A Snapshot is required"
	abiOptionsHelpText[2]="Reading Auction House - takes upto 30 seconds"
	abiOptionsHelpText[3]="Search for Bargains or Manage Shopping Lists"

	abiBargainsHelpText[1]="The Bargains Screen - Buy items or Edit Price History"
	abiBargainsHelpText[2]="Select Prices to Delete  or  Force price into list"
	abiBargainsHelpText[3]="Show Tooltip of 'Per-Unit' prices"
	abiBargainsHelpText[4]="Toggles History prices by Stack Size"
	abiBargainsHelpText[5]="L-Click = Name to Browse,  R-Click = Edit Prices"
	abiBargainsHelpText[6]="L-Click = Buy Item,  R-Click = Toggle Stack"
	abiBargainsHelpText[7]="L-Click = Bid on Item, R-Click = Toggle Stack"
	abiBargainsHelpText[8]="Tick to show five best auctions when Left-Clicking"

	abiTypeTable={"Weapon","Armor","Container","Consumable","Glyph","Trade Goods","Recipe","Gem","Miscellaneous","Quest"}
	abiBidTimeTable={"Bids Under 30 Mins","Bids Under 2 Hrs","Bids Under 12 hrs","All Bids"}
	abiDisplayDurTable={"Short","Medium","Long","V.Long"}
	abiHomeScreenFrame:Hide()
	abiHowManyBargains=0
	DoTheRegistering()
	GameTooltip:HookScript("OnTooltipSetItem",abiTooltipSetItem)
	GameTooltip:HookScript("OnTooltipCleared",abiTooltipCleared)

	if abiVariables==nil then
		abiVariables={}
	end

	if abiPriceIndex==nil then
		abiPriceIndex={}
	end

	if abiPriceIndex[abiRealm]==nil then
		abiPriceIndex[abiRealm]={}
	end
end



function abiDataFrame_OnLoad()
	abiDataFrame:Hide()
end



function abiCreateSnapShotButton_OnClick()
	local abiCanDoWholeQuery
	abiCanTakeSnapShot=0
   
	if (time()-abiVariables[1])<901 then
		return
	end
	abiOptionsFrameHelp(2)

	abiBargains=table.wipe(abiBargains)
	abiBargainsString:SetText("Bargains Found : Nil")
	abiBidBuyoutButton:SetChecked(0)
	abiBidButton:SetChecked(0)
	abiTH3:SetText("Average")

	abiCreateSnapShotButton:Disable()
	abiBargainSearchButton:Disable()
	_,abiCanDoWholeQuery=CanSendAuctionQuery("list")

	while abiCanDoWholeQuery~=1 do
		HowmanySecondsDelay(2) -- just prevents hammering the CanSendAuctionQuery
		_,abiCanDoWholeQuery=CanSendAuctionQuery("list")
	end 

	abiAreWeReadingTheAH=1 -- sets as waiting for event
	abiAHImage=table.wipe(abiAHImage)
	abiVariables[1]=time()


	-- if needed, start the Auctionator timer countdowns

	if (IsAddOnLoaded("Auctionator")) then
		gAtr_FullScanStart = time()
		gAtr_FullScanDur   = nil
	end

	QueryAuctionItems("",0,0,0,0,0,0,false,0,true)
--	QueryAuctionItems("",0,0,0,0,0,112) -- this line used for testing only

	-- routine finishes and waits for the event handler to call the routine to actually read the AH data

end



function abiReadTheAuctionHouse()
	abiAreWeReadingTheAH=0 -- trying to stop abigail reading the AH twice
	abiAHImage=table.wipe(abiAHImage) -- if it is read twice, at least only store it once.
	local abiDuration
	local abiBid
	abiMyTempAuctions=abiMyAuctions
	abiMyTempBids=abiMyBids
	for abiScannedItem=1,abiHowManyAuctions do

		abiname,_,abicount,_,_,_,_,abiminBid,abiminIncrement,abibuyoutPrice,abibidAmount,_,_,_=GetAuctionItemInfo("list",abiScannedItem)
		abiDuration=GetAuctionItemTimeLeft("list",abiScannedItem)

		if (abicount~=nil) and (abibuyoutPrice~=nil) and (abibuyoutPrice~=0)then
			abiItemLink=GetAuctionItemLink("list",abiScannedItem)
			abiBid=abiminBid

			if abibidAmount>0 then
				abiBid=abibidAmount+abiminIncrement
			end

			if CheckIfOneOfMyAuctions(abiname,abicount,abibuyoutPrice)==0 and CheckIfOneOfMyBids(abiname,abicount,abibidAmount)==0 then
				abiAHImage[#abiAHImage+1]=abiname.."%"..abicount.."%"..abibuyoutPrice.."%"..abiItemLink.."%"..abiDuration.."%"..abiBid
			end

		end

	end
	abiAreWeReadingTheAH=0
	abiAddSnapShotToPriceIndex()
	abiBargainSearchButton:Enable()
	abiOptionsFrameHelp(3)
	abiHomeScreenFrame:RegisterEvent("AUCTION_ITEM_LIST_UPDATE")
end



function abiAddSnapShotToPriceIndex()
	if abiPriceIndex[abiRealm]==nil then
		abiPriceIndex[abiRealm]={}
	end

	if #abiAHImage==0 or #abiAHImage==nil then
		return
	end

	for abiLoop=1,#abiAHImage do
		abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid=abiDecodeImage(abiAHImage[abiLoop])

		if (abiImageCount>1) then
			abiImagePrice=math.floor(abiImagePrice/abiImageCount)
			if abiImagePrice<1 then
				abiImagePrice=1 -- price per unit, not per stack
        		end
		end

		if abiPriceIndex[abiRealm][abiImageName]==nil then -- not seen before, needs adding to index file
			abiPriceIndex[abiRealm][abiImageName]={}
			abiPriceIndex[abiRealm][abiImageName]="0%0%0%0%0%0:0%"..abiMakeFullPrice(abiImagePrice).."*1"
		else
			abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])
			abiDecodePriceHistory(abiPriceHistory)
			abiConsolodatePrices()

			if abiCheckDeviation(abiImagePrice)==1 then
				abiUpdatePriceHistory(abiImagePrice)
				abiPriceHistory=abiEncodePriceHistory()				
				abiPriceIndex[abiRealm][abiImageName]=tostring(abiBhigh1).."%"..tostring(abiBlow1).."%"..tostring(abiShigh1).."%"..tostring(abiSlow1).."%"..tostring(abiRsold1).."%"..abiRatio1.."%"..abiPriceHistory
			end

		end

	end
end



function abiBargainSearchButton_OnClick()
	abiTableOffset=0

	if abiPriceIndex[abiRealm]==nil then
		abiPriceIndex[abiRealm]={}
	end --just making sure

	local abiItemAverage
	local abiType
	local abiTempBuyout
	local abiTempBid
	abiBargains=table.wipe(abiBargains)
	abiScrollFrame1:SetVerticalScroll(0)
	abiBidorBuyout()

	if abiBidButton:GetChecked()==1 then
		abiTH2:SetText("Bid Needed")
		abiTH3:SetText("Average")
		if abiBidBuyoutButton:GetChecked()==1 then
			abiTH3:SetText("Buyout")
		end
	else
		abiTH2:SetText("Buyout")
		abiTH3:SetText("Average")
	end

	abiTH4:SetText("Profit")

	for abiScannedItem=1,#abiAHImage do

		abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid=abiDecodeImage(abiAHImage[abiScannedItem])

		_,_,_,_,_,abiType,_,_,_,_=GetItemInfo(abiItemLink)

		abiTempBuyout=abiImagePrice
		abiTempBid=abiImageBid
		if abiCheckTheType(abiType)==1 and abiImageName~="This Item No Longer Available" then

			if abiImageCount>1 then
				abiImagePrice=math.floor(abiImagePrice/abiImageCount)
				abiImageBid=math.floor(abiImageBid/abiImageCount)
			end --this used to make the price per unit and not per stack

			abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])
			abiDecodePriceHistory(abiPriceHistory)
			abiFindHighestPrice()
			abiItemAverage=abiFindAveragePrice() -- price index average price
			-- abiImagePrice is the buyout price per unit .

			if abiCheckThePrice(abiImagePrice,abiItemAverage,abiTempBuyout)==1 and abiBidButton:GetChecked()~=1 then
				abiBargains[#abiBargains+1]=abiMakeFullPrice(abiItemAverage-abiImagePrice).."%"..tostring(abiScannedItem)
			end

			if abiCheckThePrice(abiImageBid,abiItemAverage,abiTempBid)==1 and abiBidButton:GetChecked()==1 and abiBidBuyoutButton:GetChecked()~=1 and abiImageTime<=abiBidTime then
				abiBargains[#abiBargains+1]=abiMakeFullPrice(abiItemAverage-abiImageBid).."%"..tostring(abiScannedItem)
			end

			if abiCheckThePrice(abiImageBid,abiImagePrice,abiTempBid)==1 and abiBidButton:GetChecked()==1 and abiBidBuyoutButton:GetChecked()==1 and abiImageTime<=abiBidTime then
				abiBargains[#abiBargains+1]=abiMakeFullPrice(abiImagePrice-abiImageBid).."%"..tostring(abiScannedItem)
			end

		end

	end

	if #abiBargains==0 then

		if abiBidButton:GetChecked()~=1 then
			abiBargainsString:SetText("Bargains Found : Nil")
		else
			abiBargainsString:SetText("Bids Found : Nil")
		end

		return
	end

	if abiBidButton:GetChecked()~=1 then
		abiBargainsString:SetText("Bargains Found : "..#abiBargains)
	else
		abiBargainsString:SetText("Bids Found : "..#abiBargains)
	end

	-- sort the abiBargains file - hence sorting by profit - largest first.
	table.sort(abiBargains,abiHighLow)
end



function abiShowTheBargains() --got the desired items in abiBargains()
	abiScrollFrame1Update()
	abiCheckButton1:Show()
	abiCheckButton2:Show()
	abiDisplayTheItems()
end



function abiDeleteSelectedButton_OnClick()
	local abiTempTable={}
	local abiTemporayString=""

	for abiloop=1,15 do

		if getglobal("abiCB"..abiloop):GetChecked()~=1 and abiHistoryCost[abiloop] ~=nil then
			abiTempTable[#abiTempTable+1]=abiMakeFullPrice(abiHistoryCost[abiloop]).."*"..tostring(abiHistorySeen[abiloop])
		end

	end			

	if #abiTempTable>0 then -- stops user from deleting ALL the prices
		abiTemporaryString=abiTempTable[1]

		for abiloop=2,15 do
			if abiTempTable[abiloop]~=nil then
				abiTemporaryString=abiTemporaryString..","..abiTempTable[abiloop]
			end
		end

		_,abiImageNumber=strsplit("%",abiBargains[abiEditingPrices+abiTableOffset])
		abiImageNumber=tonumber(abiImageNumber)
		abiImageName,_,_,_,_,_=abiDecodeImage(abiAHImage[abiImageNumber])
		abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])
		abiPriceIndex[abiRealm][abiImageName]=abiBhigh1.."%"..abiBlow1.."%"..abiShigh1.."%"..abiSlow1.."%"..abiRsold1.."%"..abiRatio1.."%"..abiTemporaryString
	end

	abiPutTextBackToNormal()
	abiDeleteSelectedButton:Disable()
	abiCancelDeleteButton:Disable()
	abiEditingPrices=0
	abiScrollFrame1Update()
	abiDisplayTheItems()
	abiForcePriceButton:Disable()
end



function abiCheckButton1_OnClick()
	abiDisplayTheItems()
end



function abiCheckButton2_OnClick()
	if abiEditingPrices~=0 then
		abiDisplayExtraInformation(abiEditingPrices)
	end
end



function abiDisplayTheItems()
	abiCheckButton1:Show()
	abiCheckButton2:Show()
	abiCreatePricingFrames()
	local abiPercent
	local abiStart
	local abiFinish
	local abiOneToEight
	local abiFullName
	abiClearExtraInformation(abiEditingPrices)

	for abiloop=1,8 do
		getglobal("abiFS"..abiloop.."1"):SetText("empty")
		getglobal("abiFS"..abiloop.."2"):Hide()
		getglobal("abiFS"..abiloop.."3"):Hide()
		getglobal("abiFS"..abiloop.."4"):Hide()
		getglobal("abiFS"..abiloop.."5"):Hide()
		getglobal("abiButton"..abiloop):Disable()
		getglobal("abiButton"..abiloop):Show()
	end

	abiStart=1+abiTableOffset
	abiFinish=8+abiTableOffset

	if abiFinish>#abiBargains then
		abiFinish=#abiBargains
	end

	if abiStart<=abiFinish then

		for abidisplayloop=abiStart,abiFinish do
			abiOneToEight=abidisplayloop-abiStart+1
			
			_,abiImageNumber=strsplit("%",abiBargains[abidisplayloop])
			abiImageNumber=tonumber(abiImageNumber)

			-- Get info from abiAHImage File
			abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid=abiDecodeImage(abiAHImage[abiImageNumber])
			-- Get info from abiPriceIndex File
			if abiImageName=="This Item No Longer Available" then
				abiFullName="This Item No Longer Available"
				abiImagePrice=0
				abiIndexAverage=0
				getglobal("abiButton"..abiOneToEight):Disable()
				abiPercent=0
			else
				abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])
				abiFullName=tostring(abiImageCount).." x "..abiImageName
				if abiEditingPrices==0 then
					getglobal("abiButton"..abiOneToEight):Enable()
				end
				abiDecodePriceHistory(abiPriceHistory)
				abiIndexAverage=abiFindAveragePrice()*abiImageCount
				if abiBidButton:GetChecked()~=1 then
					abiPercent=((abiIndexAverage-abiImagePrice)/abiImagePrice)
				else
					if abiBidBuyoutButton:GetChecked()~=1 then
						abiPercent=((abiIndexAverage-abiImageBid)/abiImageBid)
					else
						abiPercent=((abiImagePrice-abiImageBid)/abiImageBid)
					end
				end

				abiPercent=math.floor(abiPercent*100)
	
				if abiBidBuyoutButton:GetChecked()==1 then
					-- turn it into the Buyout price instead of the average price
					abiIndexAverage=abiImagePrice
				end

			end

			getglobal("abiFS"..abiOneToEight.."1"):SetText(abiFullName)
	
			if abiBidButton:GetChecked()~=1 then
				AbigailMoneyFrame_Update(getglobal("abiFS"..abiOneToEight.."2"),abiImagePrice,0,"|cffffffff")
				AbigailMoneyFrame_Update(getglobal("abiFS"..abiOneToEight.."4"),abiIndexAverage-abiImagePrice,0,"|cffffffff")
			else
				if abiBidBuyoutButton:GetChecked()~=1 then
					AbigailMoneyFrame_Update(getglobal("abiFS"..abiOneToEight.."2"),abiImageBid,0,"|cffffffff")
					AbigailMoneyFrame_Update(getglobal("abiFS"..abiOneToEight.."4"),abiIndexAverage-abiImageBid,0,"|cffffffff")
				else
					AbigailMoneyFrame_Update(getglobal("abiFS"..abiOneToEight.."2"),abiImageBid,0,"|cffffffff")
					AbigailMoneyFrame_Update(getglobal("abiFS"..abiOneToEight.."4"),abiImagePrice-abiImageBid,0,"|cffffffff")
				end
			end

			AbigailMoneyFrame_Update(getglobal("abiFS"..abiOneToEight.."3"),abiIndexAverage,0,"|cffffffff")
			getglobal("abiFS"..abiOneToEight.."5"):SetText(abiPercent)


			getglobal("abiFS"..abiOneToEight.."2"):Show()
			getglobal("abiFS"..abiOneToEight.."3"):Show()
			getglobal("abiFS"..abiOneToEight.."4"):Show()
			getglobal("abiFS"..abiOneToEight.."5"):Show()

		end

	end

	abiShowingWhichBargainsString:SetText("|cffffffff".." Showing "..tostring(abiStart).." to "..tostring(abiFinish).." of "..#abiBargains.." ")
	abiShowingWhichBargainsString:Show()
end



function abiScrollFrame1Update()
	local f
	if #abiBargains~=0 and abiEditingPrices==0 then
		FauxScrollFrame_Update(abiScrollFrame1,#abiBargains,8,23)
		-- #abiBargains is max entries, 8 is number of lines, 23 is pixel height of each line
		abiTableOffset=FauxScrollFrame_GetOffset(abiScrollFrame1)
--		abiDisplayTheItems(#abiBargains)
		abiDisplayTheItems()
		abiScrollFrame1:Show()
		f=GetMouseFocus()
		if f then
			f=f:GetName() or tostring(f)
			if f~=nil then
				if string.sub(f,1,15)=="abiMessageFrame" then
					f=string.sub(f,#f)
					abiDisplayExtraInformation(f)
				end
			end
		end
	end


end



function abiMessageFrame_OnEnter(value,passed)

	if abiEditingPrices==0 and abiPopupShown==0 and abiDisplayingFiveAuctions==0 then
		local abiImageNumber
		local abiLinkNumber
		local abiProfit
		getglobal("abiFS"..value.."1"):SetTextColor(1,1,1,1)
		getglobal("abiFS"..value.."1"):SetFontObject("GameFontNormalLarge")
		abiLinkNumber=value+abiTableOffset

		if abiLinkNumber<=#abiBargains then
			abiDisplayExtraInformation(value)
			abiBargainsFrameHelp(5)

			_,abiImageNumber,_=strsplit("%",abiBargains[abiLinkNumber])
			abiImageNumber=tonumber(abiImageNumber)

			-- Get info from abiAHImage File
			_,abiStackSize,_,abiItemLink,_,_=abiDecodeImage(abiAHImage[abiImageNumber])

			if passed==1 then

				if abiBidButton:GetChecked()==1 then
					abiBargainsFrameHelp(7)
				else
					abiBargainsFrameHelp(6)
				end

				abiOnTheButton=1

				-- show the tooltip for this item
				GameTooltip:SetOwner(abiDataFrame,"ANCHOR_CURSOR")
				GameTooltip:SetHyperlink(abiItemLink)
				GameTooltip:Show()
			end

			if passed==0 and abiStackSize>1 and abiCheckButton1:GetChecked()==1 then
				GameTooltip:SetOwner(abiDataFrame,"ANCHOR_CURSOR")

				GameTooltip:AddLine("Price Per Unit")
				abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid=abiDecodeImage(abiAHImage[abiImageNumber])
				abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])

				if abiBidButton:GetChecked()==1 then
					GameTooltip:AddDoubleLine("Bid Price : ",abiCreatePriceStringIcons(abiImageBid/abiImageCount,""),1,1,1,1,1,1)
					GameTooltip:AddDoubleLine("Buy Price : ",abiCreatePriceStringIcons(abiImagePrice/abiImageCount,""),1,1,1,1,1,1)
					abiProfit=abiFindAveragePrice()-(abiImageBid/abiImageCount)
				else
					GameTooltip:AddDoubleLine("Buy Price : ",abiCreatePriceStringIcons(abiImagePrice/abiImageCount,""),1,1,1,1,1,1)

					abiProfit=abiFindAveragePrice()-(abiImagePrice/abiImageCount)
				end
				GameTooltip:AddDoubleLine("Average : ",abiCreatePriceStringIcons(abiFindAveragePrice(),""),1,1,1,1,1,1)
				GameTooltip:AddDoubleLine("Profit : ",abiCreatePriceStringIcons(abiProfit,""),1,1,1,1,1,1)
				GameTooltip:Show()

			end

		end
	end
end



function abiDisplayExtraInformation(passed) --passed is 1-8
	abiDisplayTheFiveHeader:Hide()
	for abiloop=1,5 do
		getglobal("abiDisplayDur"..abiloop):Hide()
		getglobal("abiDisplayName"..abiloop):Hide()
		getglobal("abiDisplayBid"..abiloop):Hide()
		getglobal("abiDisplayBuy"..abiloop):Hide()
		getglobal("abiDisplayUnit"..abiloop):Hide()
	end
	abiFadeBargains(1)
	local abiTempCost
	local abiHighlightDone=0
	-- function needs to show the (upto) 15 prices stored for this item
	_,abiImageNumber=strsplit("%",abiBargains[passed+abiTableOffset])
	abiImageNumber=tonumber(abiImageNumber)
	abiImageName,abiImageCount,abiImagePrice,_,_,_=abiDecodeImage(abiAHImage[abiImageNumber])
	abiImagePrice=math.floor(abiImagePrice/abiImageCount) -- now per unit
	
	if abiImageName~="This Item No Longer Available" then
		_,_,_,_,_,_,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])
		abiDecodePriceHistory(abiPriceHistory)

		for abiloop=1,15 do

			abiTempCost=abiHistoryCost[abiloop]

			if (abiHistorySeen[abiloop]~=nil) and (abiHistorySeen[abiloop]>0) then

				if abiCheckButton2:GetChecked()==1 then
					abiTempCost=abiTempCost*abiImageCount
				end

				if (abiImagePrice>=abiHistoryCost[abiloop]*0.9) and (abiImagePrice<=abiHistoryCost[abiloop]*1.1) and abiHighlightDone==0 then
					AbigailMoneyFrame_Update(getglobal("abiPS"..abiloop),abiTempCost,abiHistorySeen[abiloop],"|cffff4040")
					abiHighlightDone=1
				else
					AbigailMoneyFrame_Update(getglobal("abiPS"..abiloop),abiTempCost,abiHistorySeen[abiloop],"|cffffffff")
				end

				getglobal("abiPS"..abiloop):Show()
				getglobal("abiCB"..abiloop):Show()
			end

		end

	end
end



function abiMessageFrame_OnLeave(value)

	if abiEditingPrices==0 and abiPopupShown==0 then
		abiPutTextBackToNormal()
		abiClearExtraInformation(abiEditingPrices)
		GameTooltip:FadeOut()
		abiOnTheButton=0
		abiBargainsFrameHelp(1)
		abiDisplayTheFiveHeader:Hide()

		abiDisplayingFiveAuctions=0

		for abiloop=1,5 do
			getglobal("abiDisplayDur"..abiloop):Hide()
			getglobal("abiDisplayName"..abiloop):Hide()
			getglobal("abiDisplayBid"..abiloop):Hide()
			getglobal("abiDisplayBuy"..abiloop):Hide()
			getglobal("abiDisplayUnit"..abiloop):Hide()
		end
		abiFadeBargains(1)

	end
end



function abiBuyButtonClicked(passed,button)
	-- could also be a Bid
	abiMyAuctionPlaced=0 --just make sure
	if abiPopupShown==1 then
		return
	end

	if button=="RightButton" then

		if abiCheckButton2:GetChecked()==nil then
			abiCheckButton2:SetChecked(1)
		else
			abiCheckButton2:SetChecked(0)
		end
		
		abiDisplayExtraInformation(passed)

		return
	end

	local abiCanDoSearchQuery=0
	GameTooltip:FadeOut()
	_,abiBuyoutNumber=strsplit("%",abiBargains[passed+abiTableOffset])
	abiBuyoutNumber=tonumber(abiBuyoutNumber)
	abiBuying.name,abiBuying.count,abiBuying.price,_,_,abiBuying.bid=abiDecodeImage(abiAHImage[abiBuyoutNumber])

	while abiCanDoSearchQuery~=1 do
		HowmanySecondsDelay(1) -- just prevents hammering the CanSendAuctionQuery
		abiCanDoSearchQuery,_=CanSendAuctionQuery("list")
	end

	abiDoingABuyout=1
	abiBuyoutFound=0
	QueryAuctionItems(abiBuying.name)
	-- gets 1st page of this item, and waits for event to fire
end



function abiLookForTheItem()
	abiDoingABuyout=0 --stop the onevent / onupdate routines firing
	local abiDuration
	local abiBid
	b,_=GetNumAuctionItems("list")

	if b==0 then

		if abiBuyoutFound==0 then
			StaticPopup_Show("abiNoLongerInAH")
			abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid=strsplit("%",abiAHImage[abiBuyoutNumber])
			abiImageName="This Item No Longer Available"
			abiAHImage[abiBuyoutNumber]=abiImageName.."%0%0%0%0%0"
			abiPriceIndex[abiRealm][abiImageName]="0%0%0%0%0%0:0%0000000000*1" -- creates price-index record for This Item No Longer Available
--			abiDisplayTheItems(#abiBargains)
			abiDisplayTheItems()
			abiMyAuctionPlaced=0
		end
			abiPopupShown=0
			return

	end

	for abiloop=1,b do
		abiname,_,abicount,_,_,_,_,abiminBid,abiminIncrement,abibuyoutPrice,abibidAmount=GetAuctionItemInfo("list",abiloop)
		abiDuration=GetAuctionItemTimeLeft("list",abiloop)
			abiBid=abiminBid
			if abibidAmount>0 then
				abiBid=abibidAmount+abiminIncrement
			end

		if abiname==abiBuying.name and abicount==abiBuying.count and abibuyoutPrice==abiBuying.price and abiBidButton:GetChecked()~=1 then
			--abiMyAuctionPlaced=1 -- so CHAT_MSG event can check it was my auction that occurred
			abiBuyThisItem=abiloop
			abiBuyThisPrice=abibuyoutPrice
			abiPopupShown=1
			AuctionFrame:SetAlpha(0.5)
			StaticPopup_Show("abiBuyoutConfirm",abiCreatePriceStringIcons(abiBuyThisPrice,""))
			abiBuyoutFound=1
			return
		end

		if abiname==abiBuying.name and abicount==abiBuying.count and abiBid==abiBuying.bid and abiBidButton:GetChecked()==1 then
			--abiMyAuctionPlaced=0 -- only needed if actual BUYOUT
			abiBuyThisItem=abiloop
			abiBuyThisPrice=abiBid
			abiPopupShown=1
			AuctionFrame:SetAlpha(0.5)
			StaticPopup_Show("abiBidConfirm",abiCreatePriceStringIcons(abiBuyThisPrice,""))
			abiBuyoutFound=1
			return
		end

	end

	abiSearchingWhichPage=abiSearchingWhichPage+1
	abiSetForLookingAtNextPage=1
	abiDoingABuyout=1 --restarts the onupdate fire
end



StaticPopupDialogs["abiBuyoutConfirm"]={
	text="Buyout auction for :|n%s",
	button1="Accept",
	button2="Cancel",

	OnAccept = function(self)
		abiMyAuctionPlaced=1
		PlaceAuctionBid("list",abiBuyThisItem,abiBuyThisPrice)
		abiPopupShown=0
	end,

	OnCancel = function(self)
		abiDoingABuyout=0
		abiPopupShown=0
		abiEditingPrices=0
--		abiDisplayTheItems(#abiBargains)
		abiDisplayTheItems()
	end,

	OnHide = function(self)
		abiPutTextBackToNormal()
		AuctionFrame:SetAlpha(1)
	end,

	showAlert = 1,
	timeout=0,
}



StaticPopupDialogs["abiBidConfirm"]={
	text="Bid on this auction for :|n%s",
	button1="Accept",
	button2="Cancel",

	OnAccept = function(self)
		PlaceAuctionBid("list",abiBuyThisItem,abiBuyThisPrice)
		abiPopupShown=0
		abiImageName="This Item No Longer Available"	
		abiAHImage[abiBuyoutNumber]=abiImageName.."%0%0%0%0%0"
		abiPriceIndex[abiRealm][abiImageName]="0%0%0%0%0%0:0%0000000000*1" -- creates price-index record for 'This Item No Longer Available'
		abiDoingABuyout=0
		abiEditingPrices=0
--		abiDisplayTheItems(#abiBargains)
		abiDisplayTheItems()
	end,

	OnCancel = function(self)
		abiDoingABuyout=0
		abiPopupShown=0
		abiEditingPrices=0
--		abiDisplayTheItems(#abiBargains)
		abiDisplayTheItems()
	end,

	OnHide = function(self)
		abiPutTextBackToNormal()
		AuctionFrame:SetAlpha(1)
	end,

	showAlert = 1,
	timeout=0,
}



StaticPopupDialogs["abiNoLongerInAH"]={
	text="Item No Longer in AH",
	button1="Accept",

	OnAccept = function(self)
		abiDoingABuyout=0
		abiPopupShown=0
		abiEditingPrices=0
--		abiDisplayTheItems(#abiBargains)
		abiDisplayTheItems()
		AuctionFrame:SetAlpha(1)
	end,

	OnHide = function(self)
		abiPutTextBackToNormal()
		abiPopupShown=0
	end,
	showAlert = 1,
	timeout=0,
}




function abiPriceChanging(passed,button)
	if getglobal("abiFS"..passed.."1"):GetText()=="empty" or
	getglobal("abiFS"..passed.."1"):GetText()=="This Item No Longer Available" or
	abiPopupShown==1 or
	abiDisplayingFiveAuctions==2 then
		return
	end	

	_,abiBuyoutNumber=strsplit("%",abiBargains[passed+abiTableOffset])
	abiBuyoutNumber=tonumber(abiBuyoutNumber)
	-- Get info from abiAHImage File
	abiImageName,_,_,_,_,_=abiDecodeImage(abiAHImage[abiBuyoutNumber])

	if button=="LeftButton" then

		if IsShiftKeyDown()==1 then
			abiImageName=abiShortenName(abiImageName)
		end

		--Put the item name into the BrowseName field of main AH window
		BrowseName:SetText(abiImageName)

		if (IsAddOnLoaded("Auctionator")) then
			Atr_Search_Box:SetText(abiImageName)
		end

		if abiEditingPrices==0 then
			local abiCanDoSearchQuery,_=CanSendAuctionQuery("list")

			while abiCanDoSearchQuery~=1 do
				HowmanySecondsDelay(1) -- just prevents hammering the CanSendAuctionQuery
				abiCanDoSearchQuery,_=CanSendAuctionQuery("list")
			end

			if abiCheckButton3:GetChecked()==1 then
				abiDisplayFivePage=0
				abiDisplayingFiveAuctions=1
				abiFiveAuctions=table.wipe(abiFiveAuctions)
				QueryAuctionItems(abiImageName,0,0,0,0,0,abiDisplayFivePage)
			end
		end

		return
	end

	-- Gets here if right button pressed

	for abiloop=1,8 do
		getglobal("abiButton"..abiloop):Disable()
	end

	if abiEditingPrices==0 then
		abiEditingPrices=passed
		abiDeleteSelectedButton:Enable()
		abiCancelDeleteButton:Enable()
		abiForcePriceButton:Enable()
		GameTooltip:FadeOut()
		abiBargainsFrameHelp(2)
	end
end



function abiCancelDeleteButton_OnClick()
	abiPutTextBackToNormal()
	abiDeleteSelectedButton:Disable()
	abiCancelDeleteButton:Disable()
	abiEditingPrices=0
	abiScrollFrame1Update()
	abiDisplayTheItems()
	abiForcePriceButton:Disable()
	abiBargainsFrameHelp(1)
end



function abiFindTheFiveAuctions()
-- first page of 'itemname' is loaded - read all items into abiFiveAuctions, then get next page if needed
	local abiDuration
	local b,t
	local abiUnitCost

	abiDisplayingFiveAuctions=0 -- stop the update firing
	b,_=GetNumAuctionItems("list")

	if b==0 then
		abiDisplayingFiveAuctions=2
		abiShowFiveAuctions()
		return
	end



	for abiloop=1,b do
		abiname,_,abicount,_,_,_,_,abiminBid,abiminIncrement,abibuyoutPrice,abibidAmount=GetAuctionItemInfo("list",abiloop)
		if abibidAmount~=0 then
			abiminBid=abibidAmount
		end
		abiUnitCost=math.floor(abibuyoutPrice/abicount)

		abiDuration=GetAuctionItemTimeLeft("list",abiloop)
		

		if string.sub(abiname,1,#abiImageName)==abiImageName then
			abiFiveAuctions[#abiFiveAuctions+1]=abiMakeFullPrice(abiUnitCost).."%"..abiname.."%"..abiminBid.."%"..abibuyoutPrice.."%"..abicount.."%"..abiDuration

		end

	end

	if b<50 then
		abiShowFiveAuctions()
		abiDisplayingFiveAuctions=2
		return
	end

	abiDisplayFivePage=abiDisplayFivePage+1
	abiSetForLookingAtNextPage=1
	abiDisplayingFiveAuctions=1 --restarts the onupdate fire
end



function abiShowFiveAuctions()

	local abinumber=#abiFiveAuctions
	local abiName,abiUnit,abiBuy,abiBid,abiTime,abiCount

	--abiDisplayingFiveAuctions=0 --just make sure its turned off

	table.sort(abiFiveAuctions,abiLowHigh)

	abiBargainsHelpFrame:SetText("|cffffffff"..abinumber.." matching items")

	for abiloop=1,15 do
		getglobal("abiPS"..abiloop):Hide()
		getglobal("abiCB"..abiloop):Hide()
	end


	if abinumber>5 then
		abinumber=5
	end

	for abiloop=1,5 do
		getglobal("abiDisplayDur"..abiloop):Hide()
		getglobal("abiDisplayName"..abiloop):Hide()
		getglobal("abiDisplayBid"..abiloop):Hide()
		getglobal("abiDisplayBuy"..abiloop):Hide()
		getglobal("abiDisplayUnit"..abiloop):Hide()
	end


	for abiloop=1,abinumber do
		-- abiUnitCost.."%"..abiname.."%"..abiminBid.."%"..abibuyoutPrice.."%"..abicount.."%"..abiDuration

		abiUnit,abiName,abiBid,abiBuy,abiCount,abiTime=strsplit("%",abiFiveAuctions[abiloop])
		abiBuy=tonumber(abiBuy)
		abiBid=tonumber(abiBid)
		abiCount=tonumber(abiCount)
		abiTime=tonumber(abiTime)

		getglobal("abiDisplayDur"..abiloop):SetText(abiDisplayDurTable[abiTime])
		getglobal("abiDisplayName"..abiloop):SetText(abiCount.." x "..abiName)

		AbigailMoneyFrame_Update(getglobal("abiDisplayBid"..abiloop),abiBid,0,"|cffffffff")
		AbigailMoneyFrame_Update(getglobal("abiDisplayBuy"..abiloop),abiBuy,0,"|cffffffff")
		AbigailMoneyFrame_Update(getglobal("abiDisplayUnit"..abiloop),abiUnit,0,"|cffffffff")

		getglobal("abiDisplayDur"..abiloop):Show()
		getglobal("abiDisplayName"..abiloop):Show()
		getglobal("abiDisplayBid"..abiloop):Show()
		getglobal("abiDisplayBuy"..abiloop):Show()
		getglobal("abiDisplayUnit"..abiloop):Show()
	end

	abiFadeBargains(0.5)
	abiDisplayTheFiveHeader:Show()
end



function abiFadeBargains(passed)
	for abiloop=1,8 do
		getglobal("abiFS"..abiloop.."2"):SetAlpha(passed)
		getglobal("abiFS"..abiloop.."3"):SetAlpha(passed)
		getglobal("abiFS"..abiloop.."4"):SetAlpha(passed)
		getglobal("abiMessageFrame"..abiloop):SetAlpha(passed)
	end
end



-- this function used to reverse sort the table abiBargains, so the greatest profit comes first
function abiHighLow(a,b)
	return a>b
end



function abiLowHigh(a,b)
	return b>a
end



function abiHomeScreenFrameUpdate(self,elapsed)
-- note - 901 is seconds in 15min 01secs, delay between allowing complete read of AH
	local abiTime1
	local abiTime2
	local abiTimeLeft
	local abiT
	_,abiT=GetNumAuctionItems("list")
	if abiT>42554 then
		abiT=42554
	end
	abiUseOtherAddonScanButton:SetText("Use Other Addon Scan / "..abiMake5(abiT))
	abiTimeLeft=901-(time()-abiVariables[1])
	
	if (abiTimeLeft<0) and (abiCanTakeSnapShot==0) then
		abiCreateSnapShotButton:SetText("|cffe0e000".."Take Snapshot")
		abiCreateSnapShotButton:Enable()
		abiUseOtherAddonScanButton:Enable()
		abiCanTakeSnapShot=1
		return
	end

	if abiTimeLeft>0 then	
		abiTime1=math.floor(abiTimeLeft/60) --abiTime1=Mins
		abiTime2=abiTimeLeft-(abiTime1*60) -- Seconds

		if abiTime2<10 then
			abiCreateSnapShotButton:SetText("Wait "..abiTime1..":0"..abiTime2)
		else
			abiCreateSnapShotButton:SetText("Wait "..abiTime1..":"..abiTime2)
		end

		abiCreateSnapShotButton:Disable()
		abiUseOtherAddonScanButton:Disable()
	end

end



function abiMake5(t)
	t=tostring(t)
	t=string.rep("0",5-#t)..t
	return t
end



function abiDataFrameUpdate(self,elapsed)
	abiCanDoSearchQuery,_=CanSendAuctionQuery("list")

	if abiSetForLookingAtNextPage==1 and abiCanDoSearchQuery==1 and abiDisplayingFiveAuctions==0 then

		abiSetForLookingAtNextPage=0
		QueryAuctionItems(abiBuying.name,0,0,0,0,0,abiSearchingWhichPage)
	end

	if abiSetForLookingAtNextPage==1 and abiCanDoSearchQuery==1 and abiDisplayingFiveAuctions==1 then

		abiSetForLookingAtNextPage=0
		QueryAuctionItems(abiImageName,0,0,0,0,0,abiDisplayFivePage)
	end

end



function abiGetMyAuctions()
	local abiMyNumAuctions
	local abiTemporaryNumber
	local abiTemp1
	local abiTemp2
	local abiTemp3
	_,abiTemporaryNumber=GetNumAuctionItems("owner")

	abiMyAuctions=table.wipe(abiMyAuctions)
	GetOwnerAuctionItems(0)

	if abiTemporaryNumber>0 then

		for i=1,abiTemporaryNumber do
			abiTemp1,_,abiTemp2,_,_,_,_,_,_,abiTemp3,_,_,_,_=GetAuctionItemInfo("owner",i)
			-- name, count, buyout

			if abiTemp1==nil then
				abiTemp1="error"
			end

			abiMyAuctions[#abiMyAuctions+1]=abiTemp1.."%"..abiTemp2.."%"..abiTemp3
		end
	end
end



function abiGetMyBids()
	local abiMyNumBids
	local abiTemporaryNumber
	local abiTemp1
	local abiTemp2
	local abiTemp3
	_,abiTemporaryNumber=GetNumAuctionItems("bidder")

	abiMyBids=table.wipe(abiMyBids)
	GetBidderAuctionItems(0)

	if abiTemporaryNumber>0 then

		for i=1,abiTemporaryNumber do
			abiTemp1,_,abiTemp2,_,_,_,_,_,_,_,abiTemp3,_,_,_=GetAuctionItemInfo("bidder",i)
			-- name, count, bidamount

			if abiTemp1==nil then
				abiTemp1="error"
			end

			abiMyBids[#abiMyBids+1]=abiTemp1.."%"..abiTemp2.."%"..abiTemp3
		end
	end
end



function DoTheRegistering()
	abiHomeScreenFrame:RegisterEvent("AUCTION_ITEM_LIST_UPDATE")
	abiHomeScreenFrame:RegisterEvent("AUCTION_HOUSE_SHOW")
	abiHomeScreenFrame:RegisterEvent("AUCTION_HOUSE_CLOSED")
	abiHomeScreenFrame:RegisterEvent("CHAT_MSG_SYSTEM")
	abiHomeScreenFrame:RegisterEvent("UI_ERROR_MESSAGE")
	abiHomeScreenFrame:RegisterEvent("NEW_AUCTION_UPDATE")
	abiHomeScreenFrame:RegisterEvent("ADDON_LOADED")
	abiHomeScreenFrame:RegisterEvent("MODIFIER_STATE_CHANGED")
end



function abiHomeScreenFrame_OnEvent(frame,event,arg1,arg2,...)

	if event=="ADDON_LOADED" and arg1=="Abigail" then

-- These three lines make sure the PriceIndex file has been upgraded to latest version
		if abiVariables[25]~=abiLastPHUpgradeVersion then
			abiPriceIndexUpgrade()
		end


		-- Hook the Blizzard functions to get the stack size of object mouse is over

		--This Hook Does Standard Bag Items
		hooksecurefunc (GameTooltip, "SetBagItem",
		function(tip, whichbag, whichslot)
			_, abiStackSize = GetContainerItemInfo(whichbag, whichslot);
		end
		);


		--This Hook Does The Bank Slots and Bags
		hooksecurefunc (GameTooltip, "SetInventoryItem",
		function (tip, whichunit, whichslot)
			abiStackSize=GetInventoryItemCount(whichunit,whichslot)
		end
		);

		--This Hook Does The AH Browse and Bids Screen
		hooksecurefunc (GameTooltip, "SetAuctionItem",
		function (tip, whichtype, whichindex)
			_, _, abiStackSize = GetAuctionItemInfo(whichtype, whichindex);
			
		end
		);

		abiHomeScreenFrame:UnregisterEvent("ADDON_LOADED")


		--Hook the Mailbox to find when taking money from a sale
		abiInboxHook1=OpenMailMoneyButton:GetScript("OnClick")
		local function abiNewFunc1(...)
			local abiAmount,Rat1,Rat2,abiVendorPrice
			local abiWhichItem=InboxFrame.openMailID
			-- cash can be - successful auction (iType==type), outbid on item (iType==nil), money from other player (iType==nil)
			local iType,iName,_,Bid,Buyout=GetInboxInvoiceInfo(abiWhichItem)
			local _,_,_,subject=GetInboxHeaderInfo(abiWhichItem)

			if iType=="seller" then

				if Buyout==0 or Bid<Buyout then
					abiAmount=Bid
				else
					abiAmount=Buyout
				end
-- get the amount / stack size
				abiAmount=math.floor(abiAmount/abiCalculateStackSize(subject))

				if abiAmount<1 then
					abiAmount=1
				end

				abiVendorPrice=math.floor(abiAmount/2)

				if abiVendorPrice<1 then
					abiVendorPrice=1
				end

				if abiPriceIndex[abiRealm][iName]~=nil then
					abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][iName])

					Rat1,Rat2=abiDecodeRatio(abiRatio1)
					Rat1=Rat1+1
-- this next bit needed incase of a successful sell of an item we have not recorded as been auctioned
					if Rat1>Rat2 then
						Rat2=Rat1
					end

					if abiAmount>abiShigh1 then
						abiShigh1=abiAmount
					end

					if abiAmount<abiSlow1 or abiSlow1==0 then
						abiSlow1=abiAmount
					end

					abiRsold1=tostring(abiAmount)
					abiRatio1=tostring(Rat1)..":"..tostring(Rat2)
					abiPriceIndex[abiRealm][iName]=abiBhigh1.."%"..abiBlow1.."%"..abiShigh1.."%"..abiSlow1.."%"..abiRsold1.."%"..abiRatio1.."%"..abiPriceHistory
				else
					abiPriceIndex[abiRealm][iName]="0%0%"..abiAmount.."%"..abiAmount.."%"..abiAmount.."%1:1%"..abiVendorPrice.."*1"
	
				end

			end
			return abiInboxHook1(...)
		end

		OpenMailMoneyButton:SetScript("OnClick",abiNewFunc1)



		--Hook the Mailbox to find when taking item
		abiInboxHook2=OpenMailAttachmentButton1:GetScript("OnClick")
		local function abiNewFunc2(...)
			local abiItemLink,abiItemName,abiVendorPrice
			local Rat1,Rat2
			local abiWhichItem=InboxFrame.openMailID
			-- item can be - successful bid/buyout (iType==type), unsuccessful auction returned item (iType==nil), item from other player (iType==nil)
			local iType,_,_,Bid,Buyout=GetInboxInvoiceInfo(abiWhichItem)
			local _,_,_,subject=GetInboxHeaderInfo(abiWhichItem)

			abiItemName,abiItemLink=GameTooltip:GetItem()	
			_,_,_,_,_,_,_,_,_,_,abiVendorPrice=GetItemInfo(abiItemLink)
			abiVendorPrice=math.floor(abiVendorPrice/2)

			if string.sub(subject,1,15)=="Auction expired" then

				if abiPriceIndex[abiRealm][abiItemName]~=nil then
					abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiItemName])
					Rat1,Rat2=abiDecodeRatio(abiRatio1)
					Rat2=Rat2+1
					abiRatio1=tostring(Rat1)..":"..tostring(Rat2)
					abiPriceIndex[abiRealm][abiItemName]=abiBhigh1.."%"..abiBlow1.."%"..abiShigh1.."%"..abiSlow1.."%"..abiRsold1.."%"..abiRatio1.."%"..abiPriceHistory
				else
					abiPriceIndex[abiRealm][abiItemName]="0%0%0%0%0%0:1%"..abiVendorPrice.."*1"
				end

			end

			if iType=="buyer" then

				if Buyout==0 or Bid<Buyout then
					abiAmount=Bid
				else
					abiAmount=Buyout
				end
-- get the amount / stack size
				abiAmount=math.floor(abiAmount/abiCalculateStackSize(subject))
				if abiAmount<1 then
					abiAmount=1
				end

				if abiPriceIndex[abiRealm][abiItemName]~=nil then
					abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiItemName])

					if abiBhigh1<abiAmount then
						abiBhigh1=abiAmount
					end

					if abiBlow1>abiAmount or abiBlow1==0 then
						abiBlow1=abiAmount
					end
					abiPriceIndex[abiRealm][abiItemName]=abiBhigh1.."%"..abiBlow1.."%"..abiShigh1.."%"..abiSlow1.."%"..abiRsold1.."%"..abiRatio1.."%"..abiPriceHistory
				else
					abiPriceIndex[abiRealm][abiItemName]=abiAmount.."%"..abiAmount.."%0%0%0%0:0%"..abiVendorPrice.."*1"
				end

			end
			return abiInboxHook2(...)
		end

		OpenMailAttachmentButton1:SetScript("OnClick",abiNewFunc2)


		abiRealm=GetRealmName()
		if abiShoppingList==nil then
			abiShoppingList={}
		end
		if abiShoppingList[abiRealm]==nil then
			abiShoppingList[abiRealm]={}
		end
	end
	
	if event=="AUCTION_ITEM_LIST_UPDATE" then
		if abiDisplayingFiveAuctions==1 then
			abiFindTheFiveAuctions()
			return
		end

		if abiAreWeReadingTheAH==1 then
			abiHomeScreenFrame:UnregisterEvent("AUCTION_ITEM_LIST_UPDATE")
			_,abiHowManyAuctions=GetNumAuctionItems("list")
--			abiHowManyAuctions=50
			if abiHowManyAuctions>42554 then
				abiHowManyAuctions=42554
			end
			abiReadTheAuctionHouse()
			return
		end

		if abiDoingABuyout==1 then
			abiLookForTheItem()
		end

	end

	if event=="AUCTION_HOUSE_SHOW" then
		abiInitialise()
		abiHomeScreenFrame:UnregisterEvent("AUCTION_HOUSE_SHOW")
		abiHomeScreenFrame:SetParent"AuctionFrame"
		abiDataFrame:SetParent"AuctionFrame"
		abiShoppingFrame:SetParent"AuctionFrame"
		abiSellingFrame:SetParent"AuctionFrame"
		abiOptionsTabNum=AuctionFrame.numTabs+1
		abiBargainsTabNum=abiOptionsTabNum+1
		abiShoppingTabNum=abiBargainsTabNum+1
		abiSellingTabNum=abiShoppingTabNum+1

		abiMakeTheTab("Options",abiOptionsTabNum)
		abiMakeTheTab("Bargains",abiBargainsTabNum)
		abiMakeTheTab("Shopping",abiShoppingTabNum)
		abiMakeTheTab("Selling",abiSellingTabNum)
		abiMakeTheHeaders()
		abiTH1:Hide()
		abiTH2:Hide()
		abiTH3:Hide()
		abiTH4:Hide()
		abiTH5:Hide()
		hooksecurefunc("AuctionFrameTab_OnClick",abiFrameTab_OnClick)


		-- Hook the Auctionator functions

		if (IsAddOnLoaded("Auctionator")) then
			Atr_FullScanDone:HookScript("OnClick",abiAuctionatorScanned)
			Atr_FullScanStartButton:HookScript("OnClick",abiAuctionatorStarted)
		end
	end

	if event=="AUCTION_HOUSE_CLOSED" then
		abiVariables[2]=MinSpendSlider:GetValue()
		abiVariables[3]=MaxSpendSlider:GetValue()
		abiVariables[4]=ProfitMarginSlider:GetValue()
		abiVariables[5]=CashProfitSlider:GetValue()
		abiVariables[6]=DeviationSlider:GetValue()
		abiVariables[7]=abiTooltipCB1:GetChecked()
		abiVariables[8]=abiTooltipCB2:GetChecked()
		abiVariables[9]=abiTooltipCB3:GetChecked()
		abiVariables[10]=abiTooltipCB4:GetChecked()
		abiVariables[11]=abiTooltipCB5:GetChecked()
		abiVariables[12]=abiTooltipCB6:GetChecked()
		abiVariables[13]="Unused"
		abiVariables[14]="Unused"

		for abiloop=15,24 do
			abiVariables[abiloop]=getglobal("abiTypeCheck"..(abiloop-14)):GetChecked()

			if abiVariables[abiloop]==nil then
				abiVariables[abiloop]=0
			end

		end

		abiBargains=table.wipe(abiBargains)
		abiScrollFrame1:SetVerticalScroll(0)

		if abiHolding~=nil then
			abiPriceIndex=abiHolding
			abiHolding=nil
		end

		abiCurrentHistoricButton:SetChecked(0)
		abiOnTheButton=0

	end

	if event=="CHAT_MSG_SYSTEM" and string.sub(arg1,1,18)=="You won an auction" and abiMyAuctionPlaced==1 then
		abiImageName,abiImageCount,abiImagePrice,abiItemLink,abiImageTime,abiImageBid=strsplit("%",abiAHImage[abiBuyoutNumber])
		abiImageName="This Item No Longer Available"	
		abiAHImage[abiBuyoutNumber]=abiImageName.."%0%0%0%0%0"
		abiPriceIndex[abiRealm][abiImageName]="0%0%0%0%0%0:0%0000000000*1" -- creates price-index record for This Item No Longer Available
		abiDisplayTheItems()
		abiMyAuctionPlaced=0
	end

	if (event == "UI_ERROR_MESSAGE" and arg1) then

		if (arg1 == ERR_ITEM_NOT_FOUND or arg1 == ERR_NOT_ENOUGH_MONEY or arg1 == ERR_AUCTION_BID_OWN) and abiMyAuctionPlaced==1 then
			print(arg1)
			abiMyAuctionPlaced=0
		end

	end

	-- this event to show stack-size prices on tooltip when in AH sell item slot
	if event=="MODIFIER_STATE_CHANGED" and (arg1=="LSHIFT" or arg1=="RSHIFT") then
		local f,n
		f=GetMouseFocus()
		n=f:GetName()

		if n~="AuctionsItemButton" then
			return
		end

		n,_,abiStackSize=GetAuctionSellItemInfo()

		if arg2==0 then
			abiStackSize = 1
		end

		if n~=nil then
			GameTooltip:SetAuctionSellItem()
		end

	end


	if event=="NEW_AUCTION_UPDATE" and abiSuggestButton:GetChecked()==1 then
		local n, stack,vendor
		n,_,stack,_,_,_,vendor=GetAuctionSellItemInfo()

		if n==nil then
			return
		end

		abiRealm=GetRealmName() --just make sure

		if abiPriceIndex[abiRealm][n]==nil then -- not seen before, needs adding to index file
			abiPriceIndex[abiRealm][n]={}
			abiPriceIndex[abiRealm][n]="0%0%0%0%0%0:0%"..abiMakeFullPrice(vendor).."*1"
			return
		end

		abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][n])

		if abiShigh1==0 and abiSuggestBuyoutButton:GetChecked()~=1 then
			LAST_ITEM_AUCTIONED = ""
			LAST_ITEM_COUNT = 0
			return
		end
		if abiBhigh1==0 and abiSuggestBuyoutButton:GetChecked()==1 then
			LAST_ITEM_AUCTIONED = ""
			LAST_ITEM_COUNT = 0
			return
		end

		LAST_ITEM_AUCTIONED = n
		LAST_ITEM_COUNT = stack

		if UIDropDownMenu_GetSelectedValue(PriceDropDown)==2 then
			abiShigh1=abiShigh1*stack
			abiBhigh1=abiBhigh1*stack
		end

		if abiSuggestBuyoutButton:GetChecked()~=1 then
			MoneyInputFrame_SetCopper(BuyoutPrice, abiShigh1)
			LAST_ITEM_BUYOUT = abiShigh1
			abiShigh1=abiShigh1*.9
			MoneyInputFrame_SetCopper(StartPrice, abiShigh1)
			LAST_ITEM_START_BID=abiShigh1
		else
			MoneyInputFrame_SetCopper(BuyoutPrice, abiBhigh1)
			LAST_ITEM_BUYOUT = abiBhigh1
			abiBhigh1=abiBhigh1*.9
			MoneyInputFrame_SetCopper(StartPrice, abiBhigh1)
			LAST_ITEM_START_BID=abiBhigh1
		end

	else
		LAST_ITEM_AUCTIONED = ""
		LAST_ITEM_COUNT = 0
	end
end



function abiAuctionatorScanned(self,index)

	if abiAuctionatorScanStarted==1 then
		print("Auctionator GETALL Scan data has been sent to Abigail.")
		_,abiHowManyAuctions=GetNumAuctionItems("list")
		if abiHowManyAuctions>42554 then
			abiHowManyAuctions=42554
		end
		abiAHImage=table.wipe(abiAHImage)
		abiReadTheAuctionHouse()
	end
	abiAuctionatorScanStarted=0
end



function abiAuctionatorStarted(self,index)
	abiAuctionatorScanStarted=1 -- so that pressing the Done button is only acted upon if the scan has been done first.
	abiVariables[1]=time()
	abiCanTakeSnapShot=0
end



function abiMakeTheTab(name,tabIndex)
	-- Create the tab itself.
	local tab = CreateFrame("Button", "AuctionFrameTab" .. tabIndex, AuctionFrame, "AuctionTabTemplate");
	tab:SetID(tabIndex);
	tab:SetText(name);
	tab:SetPoint("TOPLEFT", "AuctionFrameTab" .. (tabIndex - 1), "TOPRIGHT", -8, 0);
	-- Link it into the auction frame.
	PanelTemplates_DeselectTab(tab);
	PanelTemplates_SetNumTabs(AuctionFrame, tabIndex);
end



function abiFrameTab_OnClick(self, index)
	index = self:GetID();
	abiTH1:Hide()
	abiTH2:Hide()
	abiTH3:Hide()
	abiTH4:Hide()
	abiTH5:Hide()
	abiOnTheButton=0
	abiBargainSearchButton:Hide()
	abiCreateSnapShotButton:Hide()
	abiUseOtherAddonScanButton:Hide()
	abiSelectWhichBidToUseButton:Hide()
	abiCancelDeleteButton:Hide()
	abiNoBargainsFoundButton:Hide()
	abiForcePriceButton:Hide()
	abiShowingWhichBargainsString:Hide()
	abiSellingFrame:Hide()
	abiHomeScreenFrame:UnregisterEvent("AUCTION_ITEM_LIST_UPDATE")

	if index~=abiBargainsTabNum then
		abiMyAuctionPlaced=0
		abiPutTextBackToNormal()
		abiDataFrame:Hide()
		abiEditingPrices=0
		abiDeleteSelectedButton:Disable()
		abiCancelDeleteButton:Disable()
		abiForcePriceButton:Disable()
		abiDeleteSelectedButton:Hide()
		abiCheckButton1:Hide()
		abiCheckButton2:Hide()
	end

	if index~=abiShoppingTabNum then
		abiGenerateButton:Hide()
		abiShoppingSearchButton:Hide()
		abiShoppingButton3:Hide()
		abiNoSnapshotTakenButton:Hide()
		abiShoppingButton3:Disable()
		abiGenerateButton:Enable()
		abiShoppingSearchButton:Enable()
	end

	if index<abiOptionsTabNum then
		abiHomeScreenFrame:Hide()
		abiDataFrame:Hide()
		abiShoppingFrame:Hide()
		--abiSellingFrame:Hide()
		return
	else
		AuctionFrameTopLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-TopLeft");
		AuctionFrameTop:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Auction-Top");
		AuctionFrameTopRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Auction-TopRight");
		AuctionFrameBotLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-BotLeft");
		AuctionFrameBotRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-BotRight");
		abiHomeScreenFrame:Hide()
		abiDataFrame:Hide()
		abiShoppingFrame:Hide()
		AuctionFrameAuctions:Hide()
		AuctionFrameBrowse:Hide()
		AuctionFrameBid:Hide()
	end

	if index==abiOptionsTabNum then
		abiHomeScreenFrame:RegisterEvent("AUCTION_ITEM_LIST_UPDATE")

		local abiTemporaryNumber
		abiDataFrame:Hide()
		abiShoppingFrame:Hide()
		--abiSellingFrame:Hide()
		abiHomeScreenFrame:Show()
		abiHomeScreenFrame:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",15,-68)
		abiBargainSearchButton:Show()
		abiCreateSnapShotButton:Show()
		abiUseOtherAddonScanButton:Show()
		abiSelectWhichBidToUseButton:Show()
		abiTemporaryNumber=math.floor(GetMoney()/10000)
		MaxSpendSlider:SetMinMaxValues(0,abiTemporaryNumber)

		if #abiBargains==0 then

			if abiBidButton:GetChecked()~=1 then
				abiBargainsString:SetText("Bargains Found : Nil")
			else
				abiBargainsString:SetText("Bids Found : Nil")
			end

		else

			if abiBidButton:GetChecked()~=1 then
				abiBargainsString:SetText("Bargains Found : "..#abiBargains)
			else
				abiBargainsString:SetText("Bids Found : "..#abiBargains)
			end

		end
		abiGetMyAuctions()
		abiGetMyBids()

		if #abiAHImage==0 then
			abiOptionsFrameHelp(1)
		else
			abiOptionsFrameHelp(3)
		end
		AuctionFrameMoneyFrame:Show()

	end

	if index==abiBargainsTabNum then
		abiHomeScreenFrame:RegisterEvent("AUCTION_ITEM_LIST_UPDATE")

		if #abiBargains~=0 then
			abiHomeScreenFrame:Hide()
			abiShoppingFrame:Hide()
			--abiSellingFrame:Hide()
			abiDataFrame:Show()
			abiDataFrame:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",15,-68)
			abiShowTheBargains()
			abiTH1:Show()
			abiTH2:Show()
			abiTH3:Show()
			abiTH4:Show()
			abiTH5:Show()
			abiDeleteSelectedButton:Show()
			abiCheckButton1:Show()
			abiCheckButton2:Show()
			abiCancelDeleteButton:Show()
			abiForcePriceButton:Show()
			abiBargainsFrameHelp(1)
		else
			abiNoBargainsFoundButton:Show()
		end
		AuctionFrameMoneyFrame:Show()
	end

	if index==abiShoppingTabNum then
		if #abiAHImage~=0 then
			abiHomeScreenFrame:Hide()
			abiDataFrame:Hide()
			--abiSellingFrame:Hide()
			abiShoppingFrame:Show()
			abiShoppingFrame:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",15,-68)
			abiGenerateButton:Show()
			abiShoppingSearchButton:Show()
			abiShoppingButton3:Show()
			abiShowFrameHelp(6)
			abiCreateScrollList2()
		else
			abiNoSnapshotTakenButton:Show()
		end
		AuctionFrameMoneyFrame:Show()
	end

	if index==abiSellingTabNum then

		if #abiAHImage~=0 then
			abiHomeScreenFrame:Hide()
			abiDataFrame:Hide()
			abiShoppingFrame:Hide()
			abiSellingFrame:Show()
			abiSellingFrame:SetPoint("TOPLEFT",AuctionFrame,"TOPLEFT",15,-68)
			abiSellHelp(1)
			abiSH1:Show()
			abiSH2:Show()
			abiSH3:Show()
		else
			abiNoSnapshotTakenButton:Show()
		end
		AuctionFrameMoneyFrame:Show()
	end
end



function abiInitialise() -- Auction House opened and event handler has called this routine
	local abiTemporaryNumber

	for abiLoop=1,25 do

		if abiVariables[abiLoop]==nil then
			abiVariables[abiLoop]=0
		end
	end

	MinSpendSlider:SetValue(abiVariables[2])
	abiTemporaryNumber=math.floor(GetMoney()/10000)
	MaxSpendSlider:SetMinMaxValues(0,abiTemporaryNumber)

	if abiVariables[3]>abiTemporaryNumber then
		abiVariables[3]=abiTemporaryNumber
	end

	MaxSpendSlider:SetValue(abiVariables[3])
	ProfitMarginSlider:SetValue(abiVariables[4])
	CashProfitSlider:SetValue(abiVariables[5])
	DeviationSlider:SetValue(abiVariables[6])

	--Setup the tooltip check buttons
	for abiLoop=1,6 do
		getglobal("abiTooltipCB"..abiLoop):SetChecked(abiVariables[abiLoop+6])
	end

-- Note abiVariables[13,14] currently unused - were previously Quiver and Projectile

	--Setup item type check buttons
	for abiLoop=1,10 do
		getglobal("abiTypeCheck"..abiLoop):SetChecked(abiVariables[abiLoop+14])
	end

	abiCreatePriceHistoryFrames()
	abiCreateExtraBits()
	abiSellingMakeFrames()
	abiSellingMakeHeaders()
end



function abiTooltipSetItem(tooltip,...)

	if not abiTooltipAdded then
		abiAddTooltipData(tooltip)
		abiTooltipAdded=true
	end

end



function abiTooltipCleared(tooltip,...)
	abiTooltipAdded=false
end



function abiAddTooltipData(tooltip)
	local abiRat1,abiRat2
	local abimultiplier=1
	local abiItemLink
	if abiStackSize==nil or abiStackSize==0 then
		abiStackSize=1
	end
	if abiPriceIndex[abiRealm]==nil then
		abiPriceIndex[abiRealm]={}
	end --just making sure

	abiImageName,_=tooltip:GetItem()

	if abiPriceIndex[abiRealm][abiImageName]~=nil then
		abiBhigh1,abiBlow1,abiShigh1,abiSlow1,abiRsold1,abiRatio1,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])
	else
		tooltip:AddLine("Item not in database")
		return
	end

	if IsShiftKeyDown()==1 then
		abiBhigh1=abiBhigh1*abiStackSize
		abiBlow1=abiBlow1*abiStackSize
		abiShigh1=abiShigh1*abiStackSize
		abiSlow1=abiSlow1*abiStackSize
		abiRsold1=abiRsold1*abiStackSize

		abimultiplier=abiStackSize
	end

	if abimultiplier==1 then
		tooltip:AddLine("Abigail Pricing",0.5,0.5,1)
	else
		tooltip:AddLine("Abigail Pricing ("..abimultiplier..")",0.5,0.5,1)
	end

	if abiVariables[7]==1 then

		if abiBhigh1>0 then
			tooltip:AddDoubleLine("Buy-Hi :",abiCreatePriceStringIcons(abiBhigh1,""),1,1,1,1,1,1)
		else
			tooltip:AddDoubleLine("Buy-Hi :","-------------- ",1,1,1,1,1,1)
		end

		if abiBlow1>0 then
			tooltip:AddDoubleLine("Buy-Lo :",abiCreatePriceStringIcons(abiBlow1,""),1,1,1,1,1,1)
		else
			tooltip:AddDoubleLine("Buy-Lo :","-------------- ",1,1,1,1,1,1)
		end

	end

	if abiVariables[9]==1 then

		if abiShigh1>0 then
			tooltip:AddDoubleLine("Sold-Hi :",abiCreatePriceStringIcons(abiShigh1,""),1,1,1,1,1,1)
		else
			tooltip:AddDoubleLine("Sold-Hi :","-------------- ",1,1,1,1,1,1)
		end

		if abiSlow1>0 then
			tooltip:AddDoubleLine("Sold-Lo :",abiCreatePriceStringIcons(abiSlow1,""),1,1,1,1,1,1)
		else
			tooltip:AddDoubleLine("Sold-Lo :","-------------- ",1,1,1,1,1,1)
		end

	end

	if abiVariables[8]==1 then

		if abiRsold1>0 then
			tooltip:AddDoubleLine("Recent-Sold :",abiCreatePriceStringIcons(abiRsold1,""),1,1,1,1,1,1)
		else
			tooltip:AddDoubleLine("Recent-Sold :","-------------- ",1,1,1,1,1,1)
		end
	end

	if abiVariables[10]==1 then
		abiRat1,abiRat2=abiDecodeRatio(abiRatio1)
		tooltip:AddDoubleLine("Selling Ratio :",abiRat1.." sold from "..abiRat2.." auctions",1,1,1,1,1,1)
	end


	if abiVariables[11]==1 then
		abiDecodePriceHistory(abiPriceHistory)
		tooltip:AddDoubleLine("AH-Avg :",abiCreatePriceStringIcons(abiFindAveragePrice()*abimultiplier,""),1,1,1,1,1,1)
	end

	if abiOnTheButton==1 or abiVariables[12]~=1 then
		return
	end

	if abimultiplier==1 then
		tooltip:AddLine("Abigail Price History",0.5,0.5,1)
	else
		tooltip:AddLine("Abigail Price History ("..abimultiplier..")",0.5,0.5,1)
	end

	abiDecodePriceHistory(abiPriceHistory)
	local abiTotal=0
	local abiCount=0

	for abiloop=1,15 do

		if (abiHistorySeen[abiloop]~=nil) and (abiHistorySeen[abiloop]>0) then
			abiCount=abiCount+1
			abiTotal=abiTotal+abiHistorySeen[abiloop]
		end

	end

	if abiCount>0 then
		abiTotal=(abiTotal/abiCount)*1.5
	end

	for abiloop=1,15 do

		if (abiHistorySeen[abiloop]~=nil) and (abiHistorySeen[abiloop]>0) then

			if abiHistorySeen[abiloop]>=abiTotal and abiTotal>0 then
				tooltip:AddDoubleLine(abiHistorySeen[abiloop].." times at :",abiCreatePriceStringIcons(abiHistoryCost[abiloop]*abimultiplier,""),1,1,0,1,1,0)
			else
				tooltip:AddDoubleLine(abiHistorySeen[abiloop].." times at :",abiCreatePriceStringIcons(abiHistoryCost[abiloop]*abimultiplier,""),1,1,1,1,1,1)
			end

		end			

	end
	tooltip:Show()
end



function abiTooltipSelection()

	for abiloop=1,6 do
		abiVariables[abiloop+6]=getglobal("abiTooltipCB"..abiloop):GetChecked()
	end

end



function abiDecodeRatio(t)
	local ret1,ret2
	--Sold Number, Auctioned Number
	ret1,ret2=strsplit(":",t)
	ret1=tonumber(ret1)
	ret2=tonumber(ret2)
	return ret1,ret2
end



function abiCreatePricingFrames()
-- check if the frames already made

	if (abiFS12) then
		return
	end

	local frameName1,frameName2,frameName3

	for abiloop=1,8 do
		frameName1="abiFS"..abiloop.."2"
		frameName2="abiFS"..abiloop.."3"
		frameName3="abiFS"..abiloop.."4"
		f=CreateFrame("Frame",frameName1,abiMessageFrame9,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiMessageFrame9,"TOPLEFT",-15,22-(24*abiloop))
		f:Show()
		f=CreateFrame("Frame",frameName2,abiMessageFrame9,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiMessageFrame9,"TOPLEFT",115,22-(24*abiloop))
		f:Show()
		f=CreateFrame("Frame",frameName3,abiMessageFrame9,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiMessageFrame9,"TOPLEFT",245,22-(24*abiloop))
		f:Show()
	end

end



function abiCreatePriceHistoryFrames()
	local framename,checkname

	for abiColumn=0,2 do

		for abiPriceFrame=1,5 do
			framename="abiPS"..(abiColumn*5)+abiPriceFrame
			checkname="abiCB"..(abiColumn*5)+abiPriceFrame
			f=CreateFrame("Frame",framename,abiDataFrame,"AbigailMoneyFrameTemplate")
			f:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",(abiColumn*230)+65,0-(195+(abiPriceFrame*22)))
			f=CreateFrame("CheckButton",checkname,abiDataFrame,"UICheckButtonTemplate")
			f:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",(abiColumn*230)+202,0-(190+(abiPriceFrame*22)))
		end

	end

	for abiloop=1,5 do
		f=abiDataFrame:CreateFontString("abiDisplayName"..abiloop)
		f:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",80,0-(210+(abiloop*20)))
		f:SetFontObject(GameFontNormal)
		f:SetWidth(240)
		f:SetHeight(20)
		f:SetJustifyH("LEFT")
		f:SetText(" ")
		f:Hide()

		f=abiDataFrame:CreateFontString("abiDisplayDur"..abiloop)
		f:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",15,0-(210+(abiloop*20)))
		f:SetFontObject(GameFontNormal)
		f:SetWidth(60)
		f:SetHeight(20)
		f:SetJustifyH("LEFT")
		f:SetText(" ")
		f:Hide()

		framename="abiDisplayBuy"..abiloop
		f=CreateFrame("Frame",framename,abiDataFrame,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",330,0-(210+(abiloop*20)))
		f:Hide()

		framename="abiDisplayBid"..abiloop
		f=CreateFrame("Frame",framename,abiDataFrame,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",460,0-(210+(abiloop*20)))
		f:Hide()

		framename="abiDisplayUnit"..abiloop
		f=CreateFrame("Frame",framename,abiDataFrame,"AbigailMoneyFrameTemplate")
		f:SetPoint("TOPLEFT",abiDataFrame,"TOPLEFT",590,0-(210+(abiloop*20)))
		f:Hide()
	end
end



function abiSortByBuyout()
	-- Could be a bid sort
	abiHowSorted=1-abiHowSorted
	local abiImageNumber

	for loop=1,#abiBargains do
		_,abiImageNumber=strsplit("%",abiBargains[loop])
		abiImageNumber=tonumber(abiImageNumber)
		_,abiImageCount,abiImagePrice,_,_,abiImageBid=abiDecodeImage(abiAHImage[abiImageNumber])

		if abiBidButton:GetChecked()~=1 then
			abiBargains[loop]=abiMakeFullPrice(abiImagePrice).."%"..tostring(abiImageNumber)
		else
			abiBargains[loop]=abiMakeFullPrice(abiImageBid).."%"..tostring(abiImageNumber)
		end

	end

	if abiHowSorted==1 then
		table.sort(abiBargains,abiHighLow)
	else
		table.sort(abiBargains,abiLowHigh)
	end

	abiScrollFrame1:SetVerticalScroll(0)
	abiTableOffset=0
	abiDisplayTheItems()
end



function abiSortByProfit()
	abiHowSorted=1-abiHowSorted
	local abiImageNumber
	abiRealm=GetRealmName()

	for loop=1,#abiBargains do
		_,abiImageNumber=strsplit("%",abiBargains[loop])
		abiImageNumber=tonumber(abiImageNumber)
		abiImageName,abiImageCount,abiImagePrice,_,_,abiImageBid=abiDecodeImage(abiAHImage[abiImageNumber])

		_,_,_,_,_,_,abiPriceHistory=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])
		abiDecodePriceHistory(abiPriceHistory)
		abiItemAverage=abiFindAveragePrice()

		if abiImageCount>1 then

			abiItemAverage=abiItemAverage*abiImageCount

		end

		if abiBidButton:GetChecked()~=1 then

			abiTemporaryNumber=abiItemAverage/abiImagePrice
		else

			if abiBidBuyoutButton:GetChecked()~=1 then
				abiTemporaryNumber=abiItemAverage/abiImageBid

			else

				abiTemporaryNumber=abiImagePrice/abiImageBid

			end

		end

		abiTemporaryNumber=math.floor(abiTemporaryNumber*100)

		if abiSortingByPercent==0 then

			if abiBidButton:GetChecked()~=1 then
				abiBargains[loop]=abiMakeFullPrice(abiItemAverage-abiImagePrice).."%"..tostring(abiImageNumber)

			else

				if abiBidBuyoutButton:GetChecked()~=1 then
					abiBargains[loop]=abiMakeFullPrice(abiItemAverage-abiImageBid).."%"..tostring(abiImageNumber)

				else
					abiBargains[loop]=abiMakeFullPrice(abiImagePrice-abiImageBid).."%"..tostring(abiImageNumber)

				end

			end

		else
			abiBargains[loop]=abiMakeFullPrice(abiTemporaryNumber).."%"..tostring(abiImageNumber)
		end

	end

	if abiHowSorted==0 then
		table.sort(abiBargains,abiHighLow)
	else
		table.sort(abiBargains,abiLowHigh)
	end

	abiScrollFrame1:SetVerticalScroll(0)
	abiTableOffset=0
	abiDisplayTheItems()
end



function abiSortByPercent()
	abiSortingByPercent=1
	abiSortByProfit()
	abiSortingByPercent=0
end



function abiCurrentHistoricButton_OnClick()
	abiBargains=table.wipe(abiBargains)

	if abiHolding==nil then
		abiHolding=abiPriceIndex
		abiPriceIndex={}
		abiAddSnapShotToPriceIndex()
	else
		abiPriceIndex=abiHolding
		abiHolding=nil
	end
end



function abiBidorBuyout()
	
	if abiBidButton:GetChecked()==1 then
		abiButton1:SetText("|cffffffffBid")
		abiButton2:SetText("|cffffffffBid")
		abiButton3:SetText("|cffffffffBid")
		abiButton4:SetText("|cffffffffBid")
		abiButton5:SetText("|cffffffffBid")
		abiButton6:SetText("|cffffffffBid")
		abiButton7:SetText("|cffffffffBid")
		abiButton8:SetText("|cffffffffBid")
	else
		abiButton1:SetText("|cffffffffBuy")
		abiButton2:SetText("|cffffffffBuy")
		abiButton3:SetText("|cffffffffBuy")
		abiButton4:SetText("|cffffffffBuy")
		abiButton5:SetText("|cffffffffBuy")
		abiButton6:SetText("|cffffffffBuy")
		abiButton7:SetText("|cffffffffBuy")
		abiButton8:SetText("|cffffffffBuy")
	end
end



function abiBidButton_OnClick()
	abiBargains=table.wipe(abiBargains)

	if abiBidButton:GetChecked()~=1 then
		abiBargainsString:SetText("Bargains Found : Nil")
		abiBidBuyoutButton:SetChecked(0)
		abiBidBuyoutButton:Disable()
		abiBargainSearchButton:SetText("Search Bargains")
	else
		abiBargainsString:SetText("Bids Found : Nil")
		abiBidBuyoutButton:Enable()
		abiBargainSearchButton:SetText("Search Bids")
	end

end



function abiBidBuyoutButton_OnClick()

	if abiBidButton:GetChecked()~=1 then
		abiBidBuyoutButton:SetChecked(0)
		return
	end

	abiBargains=table.wipe(abiBargains)
	abiBargainsString:SetText("Bids Found : Nil")

	if abiBidBuyoutButton:GetChecked()==1 then
		abiTH3:SetText("Buyout")
	else
		abiTH3:SetText("Average")
	end
end



function abiForceButton_OnClick()
	local t
	local t1,t2,t3,t4,t5,t6,t7
	_,abiImageNumber=strsplit("%",abiBargains[abiEditingPrices+abiTableOffset])
	abiImageNumber=tonumber(abiImageNumber)
	abiImageName,abiImageCount,abiImagePrice,_,_,_=abiDecodeImage(abiAHImage[abiImageNumber])
	t=math.floor(abiImagePrice/abiImageCount)

	if t<1 then
		t=1
	end

	t1,t2,t3,t4,t5,t6,t7=abiDecodeIndex(abiPriceIndex[abiRealm][abiImageName])

	abiDecodePriceHistory(t7)
	abiUpdatePriceHistory(t)
	t7=abiEncodePriceHistory()				
	abiPriceIndex[abiRealm][abiImageName]=tostring(t1).."%"..tostring(t2).."%"..tostring(t3).."%"..tostring(t4).."%"..tostring(t5).."%"..t6.."%"..t7
	abiDisplayExtraInformation(abiEditingPrices)
end



function abiUseOtherAddonScan_OnClick()
	_,abiHowManyAuctions=GetNumAuctionItems("list")
	if abiHowManyAuctions>42554 then
		abiHowManyAuctions=42554
	end

	if abiHowManyAuctions>1000 then -- just a check to stop users hitting button by mistake (this should be over 10000 if a full scan has been done)
		abiUseOtherAddonScanButton:Disable()
		abiVariables[1]=time()
		abiAHImage=table.wipe(abiAHImage)
		abiReadTheAuctionHouse()
	end

end



function abiSelectWhichBidToUseButton_OnClick()
	abiBidTime=abiBidTime+1

	if abiBidTime==5 then
		abiBidTime=1
	end

	abiSelectWhichBidToUseButton:SetText(abiBidTimeTable[abiBidTime])

	if abiBidButton:GetChecked()==1 then
		abiBargains=table.wipe(abiBargains)
		abiBargainsString:SetText("Bids Found : Nil")
	end

end



function abiSuggestButton_OnClick()

	if abiSuggestButton:GetChecked()~=1 then
		abiSuggestBuyoutButton:SetChecked(0)
	end

end



function abiSuggestBuyoutButton_OnClick()

	if abiSuggestButton:GetChecked()~=1 then
		abiSuggestBuyoutButton:SetChecked(0)
	end

end



function abiOptionsFrameHelp(passed)
	abiOptionsHelpFrame:SetText("|cffffffff"..abiOptionsHelpText[passed])
end



function abiBargainsFrameHelp(passed)

	if passed==1 and abiEditingPrices==1 then
		abiBargainsHelpFrame:SetText("|cffffffff"..abiBargainsHelpText[2])
	else
		abiBargainsHelpFrame:SetText("|cffffffff"..abiBargainsHelpText[passed])
	end
end



-- function to upgrade the Price History file
function abiPriceIndexUpgrade()

	local t1,t2,t3,t4,t5,t6,t7
	local tempindex

	for k,v in pairs(abiPriceIndex) do
		--k is the realm name

		for k2,v2 in pairs(abiPriceIndex[k]) do
			--k2 is name field, v2 is price index field
			t1,t2,t3,t4,t5=strsplit("%",v2)
			t7=t5
			t5="0"
			t6="0:0"
			tempindex=t1.."%"..t2.."%"..t3.."%"..t4.."%"..t5.."%"..t6.."%"..t7
			abiPriceIndex[k][k2]=tempindex
		end
	end

	abiVariables[25]=abiLastPHUpgradeVersion
end

