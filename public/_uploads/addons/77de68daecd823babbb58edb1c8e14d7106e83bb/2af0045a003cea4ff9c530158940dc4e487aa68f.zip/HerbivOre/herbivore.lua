--[[----------------------------------
	Author: StingrayNine (Hipjipp @ WoWI)
	E-Mail: jeppa21@msn.com
	Credits for the awesome name goes to: Skydragon @ WoWInterface.com
----------------------------------]]--

------------------ CONFIG ------------------
local font = "FONTS\\FRIZQT__.ttf"
local size = 12
local _, ns = ...

-- Herb Frames
local azHerb = CreateFrame("Frame", "HerbivOre_Azeroth_Herb")
local ouHerb = CreateFrame("Frame", "HerbivOre_Outland_Herb")
local noHerb = CreateFrame("Frame", "HerbivOre_Northrend_Herb")
local caHerb = CreateFrame("Frame", "HerbivOre_Cataclysm_Herb")

local azOre = CreateFrame("Frame", "HerbivOre_Azeroth_Ore")
local ouOre = CreateFrame("Frame", "HerbivOre_Outland_Ore")
local noOre = CreateFrame("Frame", "HerbivOre_Northrend_Ore")
local caOre = CreateFrame("Frame", "HerbivOre_Cataclysm_Ore")

-- Just put all frames we use in a table for easy doings
local frames = {
	azHerb,
	ouHerb,
	noHerb,
	caHerb,
	
	azOre,
	ouOre,
	noOre,
	caOre,
}

local region = ns.Vanilla
local lastType = "herb"

local HerbTitle, OreTitle, Vtitle, Otitle, Ntitle

local HideAll = function(exeption)
	if not exeption then
		for _, frame in pairs(frames) do
			frame:Hide()
		end
	else
		for _, frame in pairs(frames) do
			if frame ~= exeption then
				frame:Hide()
			else 
				frame:Show()
			end
		end
	end
end

local Enter = function(zone, node, parent)
	GameTooltip:SetOwner(parent, "ANCHOR_NONE")
	GameTooltip:SetPoint("TOPLEFT", parent, "TOPRIGHT", 5, 0)
	GameTooltip:AddLine("|cffffffff"..node.."|r exists in these zones:\n|cff696969"..(zone or "not yet implemented"))
	
	GameTooltip:Show()
end

local lastLine = nil
local maxlength, newmax = 0, 0
local locate = function(region, type, name)
	local doodad
	if (type == "herb") then
		doodad = region.herb
	else
		doodad = region.ore
	end
	
	for i = 1, #doodad.node do
		local anchor = CreateFrame("frame", nil, name)
		anchor:SetScript("OnEnter", function() Enter(doodad.zone[i], doodad.node[i], name) end)
		anchor:SetScript("OnLeave", function() GameTooltip:Hide() end)
		anchor:SetScript("OnMouseDown", function() if (IsAltKeyDown()) then name:StartMoving() end end)
		anchor:SetScript("OnMouseUp", function() name:StopMovingOrSizing() end)
		
		local string, location
		local level, node = tostring(doodad.level[i]), doodad.node[i]
		if (type == "herb") then
			location = doodad.location[i]
			string = (("|cffff0000%s|r, |cff336633%s|r, |cff696969%s|r"):format(level, node, location))
		else
			string = (("|cffff0000%s|r, |cff336633%s|r"):format(level, node))
		end
		
		local text = anchor:CreateFontString(nil, "OVERLAY")
		text:SetFont(font, size)
		text:SetPoint("TOPLEFT", anchor, "TOPLEFT", 0, 0)
		text:SetText(string)
		
		anchor:SetHeight(size)
		anchor:SetWidth(text:GetWidth())
		
		if not lastLine then
			-- Initial Anchor
			anchor:SetPoint("TOPLEFT", name, "TOPLEFT", 8, -5)
		else
			-- Anchor the new line onto the previous one
			anchor:SetPoint("TOPLEFT", lastLine, "BOTTOMLEFT")
		end
		lastLine = anchor
		
		newmax = text:GetWidth()
		if (maxlength < newmax) then
			maxlength = newmax
		end
	end
			
	if (type == "herb") then
		name:SetHeight((size * #doodad.node) + 10)
		name:SetWidth(maxlength + 15)
	else
		name:SetHeight((size * #doodad.node) + 10)
		name:SetWidth((maxlength/2) + 15)
	end
end

local Click = function(name, type)
	region = name
	lastType = type
	if (region == ns.Vanilla) then
		if (lastType == "herb") then
			--Herbframe
			HideAll(azHerb)
		else
			--Oreframe
			HideAll(azOre)
		end
	elseif (region == ns.Outland) then
		if (lastType == "herb") then
			--Herbframe
			HideAll(ouHerb)
		else
			--Oreframe
			HideAll(ouOre)
		end
	elseif (region == ns.Northrend) then
		if (lastType == "herb") then
			--Herbframe
			HideAll(noHerb)
		else
			--Oreframe
			HideAll(noOre)
		end
	else
		if (lastType == "herb") then
			--Herbframe
			HideAll(caHerb)
		else
			--Oreframe
			HideAll(caOre)
		end
	end
end

local CreateButtons = function(name, type, region)

	------------------------------------------------------------------
	-------------------------- Type Buttons --------------------------
	------------------------------------------------------------------
	
	local HerbButton = CreateFrame("Button", "HerbivOre_HerbTab", name)
	HerbButton:SetPoint("BOTTOMLEFT", name, "TOPLEFT", 5, 0)
	
	HerbTitle = HerbButton:CreateFontString(nil, "OVERLAY")
	HerbTitle:SetFont(font, size)
	HerbTitle:SetPoint("TOPLEFT", HerbButton, "TOPLEFT", 0, 0)
	HerbTitle:SetText("Herb")
	
	HerbButton:SetHeight(size)
	HerbButton:SetWidth(HerbTitle:GetWidth())
	HerbButton:SetScript("OnClick", function() Click(region, "herb") end)
	
	------------------------------------------------------------------
	----------------------- in-between string ------------------------
	------------------------------------------------------------------
	
	-- We do this because it adds a "twist" to the title =)
	local bind = HerbButton:CreateFontString(nil, "OVERLAY")
	bind:SetFont(font, size)
	bind:SetPoint("TOPLEFT", HerbTitle, "TOPRIGHT", 0, 0)
	bind:SetText("iv")
	bind:SetHeight(size)
	bind:SetWidth(bind:GetWidth())
	
	------------------------------------------------------------------
	----------------------- /in-between string ------------------------
	------------------------------------------------------------------

	local OreButton = CreateFrame("Button", "HerbivOre_OreTab", name)
	OreButton:SetPoint("TOPLEFT", bind, "TOPRIGHT", 0, 0)
	
	OreTitle = OreButton:CreateFontString(nil, "OVERLAY")
	OreTitle:SetFont(font, size)
	OreTitle:SetPoint("TOPLEFT", OreButton, "TOPLEFT", 0, 0)
	OreTitle:SetText("Ore")
	
	OreButton:SetHeight(size)
	OreButton:SetWidth(OreTitle:GetWidth())
	OreButton:SetScript("OnClick", function() Click(region, "ore") end)
	
	
	------------------------------------------------------------------
	-------------------------- Area Buttons --------------------------
	------------------------------------------------------------------

	local VanillaButton = CreateFrame("Button", "HerbivOre_AzerothTab", name)
	VanillaButton:SetPoint("TOPLEFT", name, "BOTTOMLEFT", 5, 0)
	
	Vtitle = VanillaButton:CreateFontString(nil, "OVERLAY")
	Vtitle:SetFont(font, size)
	Vtitle:SetPoint("TOPLEFT", VanillaButton, "TOPLEFT", 0, 0)
	Vtitle:SetText(ns.Vanilla.title)
	
	VanillaButton:SetHeight(size)
	VanillaButton:SetWidth(Vtitle:GetWidth())
	VanillaButton:SetScript("OnClick", function() Click(ns.Vanilla, type) end)
	
	------------------------------------------------------------------
	
	local OutlandButton = CreateFrame("Button", "HerbivOre_OutlandTab", name)
	OutlandButton:SetPoint("TOPLEFT", Vtitle, "TOPRIGHT", 5, 0)
	
	Otitle = OutlandButton:CreateFontString(nil, "OVERLAY")
	Otitle:SetFont(font, size)
	Otitle:SetPoint("TOPLEFT", OutlandButton, "TOPLEFT", 0, 0)
	Otitle:SetText(ns.Outland.title)
	
	OutlandButton:SetHeight(size)
	OutlandButton:SetWidth(Otitle:GetWidth())
	OutlandButton:SetScript("OnClick", function() Click(ns.Outland, type) end)
	
	------------------------------------------------------------------
	
	local NorthrendButton = CreateFrame("Button", "HerbivOre_NorthrendTab", name)
	NorthrendButton:SetPoint("TOPLEFT", Otitle, "TOPRIGHT", 5, 0)
	
	Ntitle = NorthrendButton:CreateFontString(nil, "OVERLAY")
	Ntitle:SetFont(font, size)
	Ntitle:SetPoint("TOPLEFT", NorthrendButton, "TOPLEFT", 0, 0)
	Ntitle:SetText(ns.Northrend.title)
	
	NorthrendButton:SetHeight(size)
	NorthrendButton:SetWidth(Ntitle:GetWidth())
	NorthrendButton:SetScript("OnClick", function() Click(ns.Northrend, type) end)
	
	------------------------------------------------------------------
	
	local CataclysmButton = CreateFrame("Button", "HerbivOre_CataclysmTab", name)
	CataclysmButton:SetPoint("TOPLEFT", Ntitle, "TOPRIGHT", 5, 0)
	
	Ctitle = CataclysmButton:CreateFontString(nil, "OVERLAY")
	Ctitle:SetFont(font, size)
	Ctitle:SetPoint("TOPLEFT", CataclysmButton, "TOPLEFT", 0, 0)
	Ctitle:SetText(ns.Cataclysm.title)
	
	CataclysmButton:SetHeight(size)
	CataclysmButton:SetWidth(Ctitle:GetWidth())
	CataclysmButton:SetScript("OnClick", function() Click(ns.Cataclysm, type) end)
	
end

local init = function(name, region, type)
	local self = name
	self:Hide()
	
	self:SetMovable(true)
	self:EnableMouse(true)
	self:SetUserPlaced(true)
	
	tinsert(UISpecialFrames, self:GetName())
	
	self:SetPoint("LEFT", UIParent, "LEFT", 5, 0)
	self:SetClampedToScreen(true)
	self:SetClampRectInsets(0, 0, 10, 0)
	self:SetHitRectInsets(0, 0, -10, 0)
	self:SetFrameStrata("BACKGROUND")
	
	self:SetBackdrop({
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", tile = true, tileSize = 16,
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16,
		insets = {left = 4, right = 4, top = 4, bottom = 4},
	})
	
	self:SetBackdropColor(0, 0, 0, 1)
	self:SetBackdropBorderColor(.5, .5, .5)
	
	self:SetScript("OnMouseDown", function(self) if(IsAltKeyDown()) then self:StartMoving() end end)
	self:SetScript("OnMouseUp", function(self) self:StopMovingOrSizing() end) 
	
	locate(region, type, name)
	CreateButtons(name, type, region)
	
	lastLine = nil
end

local HideShow = function(cmd)
	-- How it works for those interested;
	-- When the slash command is called, it can be called blank or with one or two parameters
	-- Called with /heor or /herbivore type location
	-- Example: /herbivore ore northrend
	-- Would open the northrend window for ores
	
	-- Arg1 is the type
	-- Arg2 is the location
	
	-- Making the arguments interchangable would be a waste since it's redundant to call a location
	-- without a type to track
	
	local arg1, arg2 = cmd:match("^([^%s]+)%s*(.*)$")
	arg1 = (arg1 and arg1:lower() or cmd:lower())
	arg2 = (arg2 and arg2:lower() or cmd:lower())
	
	if ((arg1 == "herb") or (arg1 == "ore")) then
		-- Leave it be
	else
		arg1 = ""
	end
	
	-- Arg2 marathon
	if ((arg2 == "vanilla") or (arg2 == "azeroth")) then
		arg2 = ns.Vanilla
	elseif (arg2 == "outland") then
		arg2 = ns.Outland
	elseif ((arg2 == "northrend") or (arg2 == "north")) then
		arg2 = ns.Northrend
	elseif ((arg2 == "cataclysm") or (arg2 == "cata")) then
		arg2 = ns.Cataclysm
	else
		arg2 = ""
	end
	
	-- If blank, open the last frame
	if (arg1 == "") then
		-- If any frame is shown, hide it.
		if (azHerb:IsShown() or ouHerb:IsShown() or noHerb:IsShown() or caHerb:IsShown() or azOre:IsShown() or ouOre:IsShown() or noOre:IsShown() or caOre:IsShown()) then
			HideAll()
		-- Otherwise, open the last window
		else
			Click(region, lastType)
		end
	else
		if (arg2 == "") then
			Click(region, arg1)
		else
			Click(arg2, arg1)
		end
	end
end

SLASH_HerbivOre1 = "/heor"
SLASH_HerbivOre2 = "/herbivore"

SlashCmdList["HerbivOre"] = HideShow

init(azHerb, ns.Vanilla, "herb")
init(ouHerb, ns.Outland, "herb")
init(noHerb, ns.Northrend, "herb")
init(caHerb, ns.Cataclysm, "herb")

init(azOre, ns.Vanilla, "ore")
init(ouOre, ns.Outland, "ore")
init(noOre, ns.Northrend, "ore")
init(caOre, ns.Cataclysm, "ore")
