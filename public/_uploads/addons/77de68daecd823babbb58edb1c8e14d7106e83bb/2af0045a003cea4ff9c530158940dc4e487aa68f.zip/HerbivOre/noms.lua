local _, ns = ...

-- 31 Herbs, 21 Ores
ns.Vanilla = {
	title = "|cffD9D919A|rzeroth",
	
	-- Herbs (31)
	herb = {
		node = {
			"Peacebloom",
			"Silverleaf",
			"Bloodthistle",
			"Earthroot",
			"Mageroyal", --[5]
			"Briarthorn",
			"Swifthistle",
			"Stranglekelp",
			"Bruiseweed",
			"Wild Steelbloom", --[10]
			"Grave Moss",
			"Kingsblood",
			"Liferoot",
			"Fadeleaf",
			"Goldthorn", --[15]
			"Khadgar's Whisker",
			"Dragon's Teeth",
			"Firebloom",
			"Purple Lotus",
			"Wildvine", --[20]
			"Arthas' Tears",
			"Sungrass",
			"Blindweed",
			"Ghost Mushroom",
			"Gromsblood", --[25]
			"Golden Sansam",
			"Dreamfoil",
			"Mountain Silversage",
			"Sorrowmoss",
			"Icecap", --[30]
			"Black Lotus",
		},
		
		level = {
			1,
			1,
			1,
			15,
			50,
			70,
			50,
			85,
			100,
			115,
			120,
			125,
			150,
			160,
			170,
			185,
			195,
			205,
			210,
			210,
			220,
			230,
			235,
			245,
			250,
			260,
			270,
			280,
			285,
			290,
			300
		},
		
		location = {
			"open",
			"near trees",
			"Eversong Woods", 
			"cliffs",
			"open", --[5]
			"near trees",
			"-",
			"in water",
			"near buildings or cliffs",
			"cliffs", --[10]
			"graveyard",
			"open",
			"edge of water/streams",
			"near trees",
			"cliffs", --[15]
			"near trees",
			"open",
			"open",
			"near ruins",
			"-", --[20]
			"open",
			"open",
			"near water",
			"caves",
			"open", --[25]
			"open",
			"open",
			"cliffs",
			"open",
			"cliffs", --[30]
			"open"
		},
		
		zone = {
			"Durotar\nTeldrassil\nTirisfal Glades\nMulgore\nDun Morogh\nElwynn Forest\nGilneas\nThe Lost Isles\nEversong Woods\nLoch Modan\nWestfall\nAzuremyst Isle\nAzshara\nGhostlands\nGilneas City\nDarkshore\nBloodmyst Isle\nNorthern Barrens",
			"Durotar\nTeldrassil\nTirisfal Glades\nMulgore\nDun Morogh\nElwynn Forest\nGilneas\nThe Lost Isles\nEversong Woods\nLoch Modan\nWestfall\nAzuremyst Isle\nAzshara\nGhostlands\nGilneas City\nDarkshore\nBloodmyst Isle\nNorthern Barrens",
			"Eversong Woods",
			"Durotar\nTeldrassil\nTirisfal Glades\nMulgore\nDun Morogh\nElwynn Forest\nGilneas\nThe Lost Isles\nEversong Woods\nLoch Modan\nWestfall\nAzuremyst Isle\nAzshara\nGhostlands\nGilneas City\nDarkshore\nBloodmyst Isle\nNorthern Barrens\nRedridge Mountains\nWailing Caverns",
			"Hillsbrad Foothills\nDarkshore\nNorthern Barrens\nSilverpine Forest\nAzshara\nWestfall\nRedridge Mountains\nWetlands\nStonetalon Mountains\nDuskwood\nLoch Modan\nTeldrassil\nAshenvale\nGhostlands\nWailing Caverns\nSouthern Barrens\nBloodmyst Isle", --[5]
			"Hillsbrad Foothills\nDarkshore\nNothern Barrens\nAzshara\nDuskwood\nWtslands\nWestfall\nRedridge Mountains\nStonetalon Mountains\nSilverpine Forest\nLoch Modan\nAshenvale\nGhostlands\nSouthern Barrens\nBloodmyst Islt\nRazorfen Kraul",
			"See above",
			"Thousand Needles\nWetlands\nWestern Plaguelands\nWestfall\nThe Cape of Stranglethorn\nNorthern Stranglethorn\nSwamp of Sorrows\nThe Hinterlands\nDustwallow March\nBlackfathom Deeps\nAshenvale\nDarkshore\nHillsbrad Foothills\nStranglethorn Vale\nBloodmyst Isle\nSilverpine Forest\nGhostlands\nMaraudon\nTanaris\nThe Veiled Sea\nArathi Highlands",
			"Nothern Stranglethorn\nAshenvale\nWetlands\nDuskwood\nThe Hinterlands\nRedridge Mountains\nWestfall\nHillsbrad Foothills\nStonetalon Mountains\nLoch Modan\nArathi Highlands\nGhostlands\nBlackfathom Deeps\nWailing Caverns",
			"Nothern Stranglethorn\nStonetalon Mountains\nAshenvale\nArathi Highlands\nDesolace\nWetlands\nDuskwood\nThe Hinterlands\nStranglethorn Vale\nTwilight Highlands", --[10]
			"Duskwood\nWetlands\nArathi Highlands\nHillsbrad Foothills\nRazorfen Downs\nScarlet Monastery",
			"Northern Stranglethorn\nWestern Plaguelands\nSouthern Barrens\nDesolace\nWetlands\nArathi Highlands\nThe Hinterlands\nDustwallow March\nFeralas\nDuskwoodvAshenvale\nScarlet Monsastery\nWailing Caverns",
			"Eastern Plaguelands\nWestern Plaguelands\nNothern Stranglethorn\nDustwallow March\nThousand Needles\nWetlands\nArathi Highlands\nSouthern Barrens\nThe Hinterlands\nAshenvale\nDesolace\nNetherstorm\nScarlet Monastery\nHillsbrad Foothills\nThe Cape of Stranglethorn\nStranglethorn Vale",
			"Feralas\nThe Cape of Stranglethorn\nDustwallow March\nWestern Plaguelands\nArathi Highlands\nThe Hinterlands\nScarlet Monastery\nStranglethorn Vale",
			"Arathi Highlands\nDustwallow March\nThe Hinterlands\nFeralas\nThe Cape of Stranglethorn\nDesolace\nScarlet Monastery", --[15]
			"Eastern Plaguelands\nWestern Plaguelands\nFeralas\nThe Cape of Stranglethorn\nArathi Highlands\nDustwallow March\nDesolace\nSouthern Barrens\nThe Hinterlands",
			"Badlands",
			"Tanaris\nBurning Steppes\nSearing Gorge\nBadlands",
			"Felwood\nThe Hinterlands",
			"See above", --[20]
			"Western Plaguelands\nEastern Plaguelands\nFelwood\nRazorfen Downs",
			"Eastern Plaguelands\nThousand Needless\nBadlands\nBurning Steppes\nSilithus\nTanaris\nSearing Gorge\nUn'Goro Crater\nSouthern Barrens",
			"Feralas\nZangarmarsh\nWestern Plaguelands\nThe Hinterlands\nUn'Goro Crater",
			"Zangarmarsh\nDire Maul\nThe Hinterlands",
			"Felwood\nBlasted Lands\nDesolace\nAshenvale", --[25]
			"Swamp of Sorrows\nFelwood\nHellfire Peninsula\nZangarmarsh\nSilithus\nBadlands\nUn'Goro Crater\nBlasted Lands\nNetherstorm",
			"Blasted Lands\nFelwood\nHellfire Peninsula\nZangarmarsh\nSilithus\nBurning Steppes\nUn'Goro Crater",
			"Winterspring\nHellfire Peninsula\nBlasted Lands\nUn'Goro Crater\nSilithus",
			"Swamp of Sorrows",
			"Winterspring", --[30]
			"Silithus\nWinterspring\nEastern Plaguelands\nBlasted Lands",
			
		},
	},
	
	-- Ores (21)
	ore = {
		node = {
			"Copper",
			"Incendicite",
			"Tin",
			"Lesser Bloodstone",
			"Ooze Covered Silver",
			"Silver",
			"Iron",
			"Indurium",
			"Gold",
			"Ooze Covered Gold",
			"Mithril",
			"Ooze Covered Mithril",
			"Ooze Covered Truesilver",
			"Truesilver",
			"Dark Iron",
			"Ooze Covered Thorium",
			"Small Thorium",
			"Ooze Covered Rich Thorium",
			"Rich Thorium",
			"Small Obsidian Chunk",
			"Large Obsidian Chunk",	
		},
		
		level = {
			1,
			65,
			65,
			75,
			75,
			75,
			125,
			150,
			155,
			155,
			175,
			175,
			205,
			205,
			230,
			230,
			230,
			255,
			255,
			255,
			305,
			305,
		},
		
		zone = {
			"Darkshore\nDurotar\nNothern Barrens\nAzshara\nElwynn Forest\nDun Morogh\nGilneas\nLoch Modan\nEversong Woods\nTirisfal Glades\nThe Lost Isles\nRedridge Mountains\nWestfall\nMulgore\nSilverpine Forest\nAzuremyst Isle\nDuskwood\nBloodmyst Isle\nGhostlands\nStonetalon Mountains\nGilneas City\nAshenvale\nWetlands\nSouthern Barrens\nWailing Caverns\nThe Deadmines\nThousand Needles\nBadlands",
			"Wetlands",
			"Ashenvale\nHillsbrad Foothills\nNorthern Stranglethorn\nStonetalon Mountains\nRedridge Mountains\nWetlands\nDuskwoodvLoch Modan\nArathi Highlands\nDarkshore\nSilverpine Forest\nThe Hinterlands\nNorthern Barrens\nBloodmyst Isle\nAzshara\nDustwallow Marsh\nGhostlands\nThe Deadmines\nWailing Caverns\nBlackfathom Deeps",
			"Arathi Highlands",
			"Thousand Needles",
			"Northern Stranglethorn\nHillsbrad Foothills\nFeralas\nStonetalon Mountains\nArathi Highlands\nThe Cape of Stranglethorn\nSouthern Barrens\nDesolace\nWetlands\nRedridge Mountains\nDuskwood\nThousand Needles\nLoch Modan\nThe Hinterlands\nSilverpine Forest\nDarkshore\nNothern Barrens\nDustwallow Marsh\nThe Deadmines\nBadlands\nAzshara\nBloodmyst Isle\nGhostlands\nStranglethorn Vale\nWastfall",
			"Feralas\nWestern Plaguelands\nDesolace\nEastern Plaguelands\nThe Cape of Stranglethorn\nSouthern Barrens\nArathi Highlands\nThousand Needles\nNorthern Stranglethorn\nThe Hinterlands\nDuskwood\nDustwallow Marsh\nWetlands\nBadlands\nUldaman\nHillsbrad Foothills\nRazorfen Kraul",
			"Uldaman",
			"Western Plaguelands\nEastern Plaguelands\nFelwood\nFeralas\nBurning Steppes\nThousand Needles\nBadlands\nTanaris\nDesolace\nSouthern Barrens\nNorthern Stranglethorn\nSearing Gorge\nThe Cape of Stranglethorn\nArathi Highlands\nUn'Goro Crater\nDuskwood\nDustwallow Marsh\nHillsbrad Foothills\nStranglethorn Vale",
			"Thousand Needles",
			"Thousand Needles\nBurning Steppes\nFelwood\nBadlands\nSearning Gorge\nEastern Plaguelands\nTanaris\nArathi Highlands\nUn'Goro Crater\nDustwallow Marsh\nFeralas\nUldaman\nMaraudon",
			"Thousand Needles\nFeralas",
			"Un'Goro Crater",
			"Winterspring\nFelwood\nBurning Steppes\nBadlands\nSearing Gorge\nThousand Needles\nBlasted Lands\nSilithus\nTanaris\nEastern Plaguelands\nSwamp of Sorrows\nUn'Goro Crater\nFeralas\nThe Hinterlands\nDustwallow Marsh\nArathi Highlands",
			"Molten Core\nBlackrock Depths\nSearing Gorge\nBurning Steppes",
			"Un'Goro Crater",
			"Winterspring\nSilithus\nUn'Goro Crater\nSwamp of Sorrows\nBlasted Lands\nFelwood\nThe Hinterlands",
			"Silithus",
			"Winterspring\nSilithus\nUn'Goro Crater\nSwamp of Sorrows\nBlasted Lands\nDire Maul",
			"Temple of Ahn'Qiraj\nRuins of Ahn'Qiraj",
			"Temple of Ahn'Qiraj\nRuins of Ahn'Qiraj",
		},
	}	
}

-- 9 Herbs, 6 Ores
ns.Outland = {
	title = "|cffD9D919O|rutland",
	
	-- Herbs (9)
	herb = {
		node = {
			"Felweed",
			"Dreaming Glory",
			"Terocone",
			"Ragveil",
			"Flame Cap",
			"Ancient Licen",
			"Netherbloom",
			"Nightmare Vine",
			"Mana Thistle"
		},
		
		level = {
			300,
			315,
			325,
			325,
			335,
			340,
			350,
			365,
			375
		},
		
		location = {
			"open",
			"cliffs",
			"near trees",
			"open",
			"open",
			"dungeon",
			"open",
			"open",
			"open"
		},
		
		zone = {
			"Hellfire Peninsula\nNagrand\nZangarmarsh\nTerokkar Forest\nBlade's Edge Mountains\nShadowmoon Valley\nNetherstorm\nThe Botanica\nThe Slavepens\nThe Steamvault\nThe Underbog",
			"Nagrand\nTerokkar Forest\nNetherstorm\nBlade's Edge Mountains\nHellfire Peninsula\nZangarmarsh\nShadowmoon Valley\nThe Botanica",
			"Terokkar Forest\nShadowmoon Valley\nThe Botanica",
			"Zangarmarsh\nThe Slave Pens\nThe Steamvault\nThe Underbog",
			"Zangarmarsh\nThe Slave Pens\nThe Steamvault\nThe Underbog",
			"Auchenai Crypts\nMana-Tombs\nSethekk Halls\nShadow Labyrinth\nThe Slave Pens\nThe Steamvault\nThe Underbog",
			"Netherstorm\nThe Botanica",
			"Shadowmoon Valley\nBlade's Edge Mountains\nHellfire Peninsula",
			"Terokkar Forest\nShadowmoon Valley\nNagrand\nIsle of Quel'Danas\nNetherstorm\nBlade's Edge Mountains",
		},
	},
	
	-- Ores (6)
	ore = {
		node = {
			"Fel Iron",
			"Nethercite",
			"Adamantite",
			"Rich Adamantite",
			"Ancient Gem",
			"Khorium",
		},
		
		level = {
			275,
			275,
			325,
			350,
			375,
			375,
		},
		
		zone = {
			"Hellfire Peninsula\nZangarmarsh\nShadowmoon Valley\nBlade's Edge Mountains\nTerokkar Forest\nNagrand\nNetherstorm\nThe Steamvault",
			"Shadowmoon Valley",
			"Nagrand\nBlade's Edge Mountains\nNetherstorm\nShadowmoon Valley\nTerokkar Forest\nZangarmarsh\nIsle of Quel'Danas\nAuchenai Crypts\nMana-Tombs\nSethekk Halls\nShadow Labyrinth\nThe Slave Pens\nThe Steamvault\nThe Underbog",
			"Nagrand\nShadowmoon Valley\nNetherstorm\nTerokkar Forest\nIsle of Quel'Danas\nBlade's Edge Mountains\nAuchenai Crypts\nMana-Tombs\nSethekk Halls\nShadow Labyrinth\nThe Slave Pens\nThe Underbog",
			"Hyjal Summit",
			"Nagrand\nBlade's Edge Mountains\nTerokkar Forest\nShadowmoon Valley\nNetherstorm\nIsle of Quel'Danas\nAuchenai Crypts\nMana-Tombs\nSethekk Halls\nShadow Labyrinth\nThe Slave Pens\nThe Steamvault\nThe Underbog",
		},
	}
}

-- 10 Herbs, 6 Ores
ns.Northrend = {
	title = "|cffD9D919N|rorthrend",
	
	-- Herbs (10)
	herb = {
		node = {
			"Goldclover",
			"Firethorn",
			"Tiger Lily",
			"Talandra's Rose",
			"Frozen Herb",
			"Adder's Tounge",
			"Deadnettle",
			"Lichbloom",
			"Icethorn",
			"Frost Lotus",
		},
		
		level = {
			350,
			360,
			375,
			385,
			400,
			400,
			400,
			425,
			435,
			450,
		},
		
		-- These "locations" are more or less estimates since blizzard hasn't updated their official
		-- herbalism "chart". Estimate locations gathered from wowwiki.com and wowhead.com
		location = {
			"Open",
			"Hot Liquids",
			"Around Rivers and Lakes",
			"Ruins?",
			"Snow/Ice covered areas",
			"Sholazar Basin",
			"-",
			"Icecrown, The Storm Peaks and Lake Wintergrasp.",
			"Icecrown, The Storm Peaks and Lake Wintergrasp. ",
			"Lake Wintergrasp",
		},
		
		zone = {
			"Howling Fjord\nSholazar Basin\nBorean Tundra\nGrizzly Hills\nDragonblight\nAzjol-Nerub",
			"Borean Tundra",
			"Sholazar Basin\nGrizzly Hills\nHowling Fjord\nBorean Tundra\nAzjol-Nerub",
			"Zul'Drak\nDragonblight\nDrak'Tharon Keep\nGrizzly Hills\nGundrak",
			"Dragonblight\nZul'Drak\nWintergrasp\nHillsbrad Foothills\nThe Nexus",
			"Sholazar Basin\nGundrak\nDrak'Tharon Keep",
			"See Frost Lotus, Goldclover, Tiger Lily or Talandra's Rose",
			"The Storm Peaks\nIcecrown\nWintergrasp\nUtgarde Pinnacle",
			"The Storm Peaks\nIcecrown\nWintergrasp\nUtgarde Pinnacle\nThe Oculus\nZul'Drak",
			"Wintergrasp\nUlduar",
		},
	},
	
	-- Ores (6)
	ore = {
		node = {
			"Cobalt",
			"Rich Cobalt",
			"Saronite",
			"Rich Saronite",
			"Pure Sarointe",
			"Titanium",
		},
		
		level = {
			350,
			375,
			400,
			425,
			450,
			450,
		},
		
		zone = {
			"Zul'Drak\nHowling Fjord\nBorean Tundra\nDragonblight\nGrizzly Hills\nUtgarde Keep\nThe Storm Peaks\nCrytalsong Forest",
			"Borean Tundra\nHowling Fjord\nZul'Drak\nDragonblight\nGrizzly Hills\nCrystalsong Forest\nUtgarde Keep\nThe Storm Peaks",
			"Icecrown\nSholazar Basin\nThe Storm Peaks\nWintergrasp\nDragonblight\nCrystalsong Forest\nHalls of Stone\nZul'Drak",
			"Icecrown\nSholazar Basin\nThe Storm Peaks\nWintergrasp\nDragonblight\nCrystalsong Forest",
			"Ulduar",
			"Icecrown\nSholazar Basin\nWintergrasp\nThe Storm Peaks\nDragonblight\nCrystalsong Forest",
		},
	}
}

-- 6 Herbs, 6 Ores
ns.Cataclysm = {
	title = "|cffD9D919C|rataclysm",
	
	-- Herbs (6)
	herb = {
		node = {
			"Azshara's Veil",
			"Cinderbloom",
			"Stormvine",
			"Heartblossom",
			"Whiptail",
			"Twilight Jasmine",
		},
		
		level = {
			425,
			425,
			425,
			475,
			500,
			525,
		},
		
		location = {
			"Watery areas",
			"Scorched areas",
			"Usually trees or large seaweed",
			"Deepholm",
			"Waterbanks",
			"Twilight Highlands",
		},
		
		zone = {
			"Shimmering Expanse\nTol Barad Peninsula\nAbyssal Depths\nKelp'thar Forest\nMount Hyjal",
			"Deepholm\nTwilight Highlands\nMount Hyjal\nUldum\nTol Barad Peninsula\nTol Barad",
			"Mount Hyjal\nAbyssal Depths\nShimmering Expanse\nKelp'thar Forest",
			"Deepholm",
			"Uldum\nTol Barad",
			"Twilight Highlands",
		},
	},
	
	-- Ores (6)
	ore = {
		node = {
			"Obsidium Deposit",
			"Rich Obsidium Deposit",
			"Elementium Vein",
			"Rich Elementium Vein",
			"Pyrite Deposit",
			"Rich Pyrite Deposit",
		},
		
		level = {
			425,
			450,
			475,
			500,
			525,
			525,
		},
		
		zone = {
			"Deepholm\nMount Hyjal\nAbyssal Depths\nShimmering Expanse\nKelp'thar Forest",
			"Deepholm",
			"Deepholm\nTwilight Highlands\nUldum\nTol Barad Peninsula\nTol Barad\nAhn'Qiraj: The Fallen Kingdom",
			"Deepholm\nTwilight Highlands\nUldum\nTol Barad Peninsula\nTol Barad\nAhn'Qiraj: The Fallen Kingdom",
			"Twilight Highlands\nUldum\nAhn'Qiraj: The Fallen Kingdom",
			"Tol Barad Peninsula\nTol Barad",
		},
	}
}
