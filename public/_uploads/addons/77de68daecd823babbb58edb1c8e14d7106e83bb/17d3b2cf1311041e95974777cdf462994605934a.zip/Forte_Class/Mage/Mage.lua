--ForteXorcist v1.976.2 by Xus 03-08-2012 for 4.3.4
-- Forte Mage Module attempt by Amros of Gilneas

if FW.CLASS == "MAGE" then
	local FW = FW;
	local FWL = FW.L;
	local MG = FW:ClassModule("Mage");
	
	local ST = FW:Module("Timer");
	local CA = FW:Module("Casting");
	local CD = FW:Module("Cooldown");
	
	if ST then
		local F = ST.F;
		ST:SetDefaultHasted(1)
		:AddChannel(10,0,1) -- Blizzard
	
		:AddSpell(  118,  50,"Crowd",	F.UNIQUE):SetDurationPVP(10) -- Polymorph
		:AddSpell(44457,  12,"Default",	F.TICKS) -- living bomb
		:AddSpell(11119,   4,"Default",	F.TICKS):SetTickSpeed(1) -- ignite
		:AddSpell(11069, 000,"Default"):SetTickSpeed(2) -- fireball
		:AddSpell(11366, 000,"Default",	F.TICKS) -- Pyroblast
		:AddSpell(92315, 000,"Default",	F.TICKS) -- Pyroblast!
		:AddSpell( 2120,   8,"Default",	F.AOE_DMG):SetTickSpeed(2) -- Flamestrike
		:AddSpell(31589, 000,"Crowd",	F.UNIQUE) -- slow
		:AddSpell(  120,   8,"Crowd",	F.AOE) -- cone of cold
		:AddSpell(  122,   8,"Crowd",	F.AOE) -- frost nova
		:AddSpell(11113,   3,"Crowd",	F.AOE):SetSpellModGlph(62126,1) -- Blast Wave
		:AddSpell(82676,  12,"Crowd",	F.AOE) -- Ring of Frost
		
		:AddSpell(44572,   5,"Crowd",	F.UNIQUE) -- deep freeze
		:AddSpell(31661,   5,"Crowd",	F.UNIQUE) -- Dragon's Breath
		:AddSpell(44614, 000,"Default") -- Frostfire Bolt 9 sec slow or 12 sec dot on land
		:AddSpell(55342,  30,"Pet",		F.SUMMON) -- Mirror Image
		:AddSpell(12484, 000,"Default") -- Chilled
		:AddSpell(82731,  15,"Pet",		F.SUMMON):SetTickSpeed(1) -- Flame Orb
		:AddSpell(84726,  15,"Pet",		F.SUMMON):SetTickSpeed(1) -- Frostfire Orb
		:AddSpell(11129,  10,"Default",	F.TICKS):SetTickSpeed(2) -- Combustion
		
		:AddBuff(12536) -- Clearcasting
		:AddBuff(44445) -- Hot Streak
		:AddBuff(37445)	-- Mana Surge
		
		:AddBuff(12042) -- Arcane Power
		:AddBuff(1463) -- Mana Shield
		:AddBuff(543) -- Mage Ward
		:AddBuff(12472) -- Icy Veins
		:AddBuff(57761) -- Brain Freeze
		:AddBuff(70753) -- Pushing the Limit
		
		:AddBuff(66) -- Invisibility
		:AddBuff(12051):SetTickSpeed(2) -- Evocation
		:AddBuff(45438) -- Ice Block
		
		:AddBuff(6117) -- Mage Armor
		:AddBuff(30482) -- Molten Armor
		:AddBuff(7302) -- Frost Armor
		
		:AddBuff(44543) -- Fingers of Frost
		:AddBuff(64343) -- Impact
		:AddBuff(11426) -- Ice Barrier
		:AddBuff(105068) -- Arcane Missile Barrage
		
		:AddBuff(105785) -- Stolen Time
		
		-- self debuffs
		:AddSelfDebuff(36032) -- Arcane Blast

		--target debuffs
		:AddDebuff(120) -- cone of cold
		:AddDebuff(122) -- frost nova
		:AddDebuff(11113) -- Blast Wave
		:AddDebuff(82676) -- Ring of Frost
		:AddDebuff(83301) -- Improved Cone of Cold
		:AddDebuff(33395) -- Freeze
		
		:AddCooldown(2136,008) -- Fire Blast

		:AddCasterBuffs()
		
		local poly = FW:SpellName(118);
		ST:RegisterOnTimerBreak(function(unit,mark,spell)
			if spell == poly then
				if mark~=0 then unit=FW.RaidIcons[mark]..unit;end
				CA:CastShow("PolymorphBreak",unit);
			end
		end);
		ST:RegisterOnTimerFade(poly,"PolymorphFade");
		
		local clearcasting = FW:SpellName(12536);
		ST:RegisterOnBuffGain(function(buff)
			if buff == clearcasting then
				FW:PlaySound("TimerClearcastingSound");
			end
		end);
		
	end
	if CD then
		CD:AddHiddenCooldown(nil,86948,60); -- Cauterize
		CD:AddCasterPowerupCooldowns();
	end

	FW:SetMainCategory(FWL.RAID_MESSAGES);

	if ST then

		FW:SetSubCategory(FWL.BREAK_FADE,FW.ICON.SPECIFIC,2);
			FW:AddOption("INF",FWL.BREAK_FADE_HINT1);
			FW:AddOption("MS2",FWL.POLYMORPH_BREAK,		"",    "PolymorphBreak");
			FW:AddOption("MS2",FWL.POLYMORPH_FADE,		"",    "PolymorphFade");

	FW:SetMainCategory(FWL.SOUND);
		FW:SetSubCategory(FWL.SPELL_TIMER,FW.ICON.DEFAULT,2);
			FW:AddOption("SND",FWL.CLEARCASTING,"","TimerClearcastingSound");
	end
	
	FW.Default.PolymorphBreak = 	{[0]=0,">> Polymorph on %s Broke Early! <<"};
	FW.Default.PolymorphFade = 		{[0]=0,">> Polymorph on %s Fading in 3 seconds! <<"};

end