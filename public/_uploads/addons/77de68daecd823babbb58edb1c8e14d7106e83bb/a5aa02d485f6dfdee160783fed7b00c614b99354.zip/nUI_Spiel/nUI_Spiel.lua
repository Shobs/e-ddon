﻿local frame = CreateFrame( "Frame", "nUI_Spiel", UIParent );

local function onEvent()

	nUI_TopBars1:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_t1" );
	nUI_TopBars2:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_t2" );
	nUI_TopBars3:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_t3" );
	nUI_TopBars4:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_t4" );
	nUI_TopBars5:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_t5" );

	nUI_BottomBars1:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b1" );
	nUI_BottomBars2:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b2" );
	nUI_BottomBars3:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b3" );
	nUI_BottomBars4:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b4" );
	nUI_BottomBars5:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b5" );
	
	nUI_Dashboard_Panel1:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b1" );
	nUI_Dashboard_Panel2:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b2" );
	nUI_Dashboard_Panel3:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b3" );
	nUI_Dashboard_Panel4:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b4" );
	nUI_Dashboard_Panel5:SetTexture( "Interface\\AddOns\\nUI_Spiel\\nUI_Spiel_b5" );

	frame:UnregisterEvent( "PLAYER_ENTERING_WORLD" );
	
end

frame:SetScript( "OnEvent", onEvent );
frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
