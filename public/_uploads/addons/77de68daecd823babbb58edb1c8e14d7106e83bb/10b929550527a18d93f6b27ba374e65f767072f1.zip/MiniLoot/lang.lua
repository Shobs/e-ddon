﻿local name, addon = ...

addon.name = name
addon.name2 = "MiniLoot"
addon.name3 = "ML"
addon.version = GetAddOnMetadata(addon.name, "Version")
addon.build = addon.version:gsub("[^%d]", "")

addon.L = setmetatable({}, {__index=function(_, key)
  return tostring(key) --return (GetLocale() ~= "enUS" and "|TInterface\\PVPFrame\\Icons\\PVP-Banner-Emblem-85:0:0:0:0|t" or "")..tostring(key)
end})

local L, locale = addon.L, GetLocale()
addon.locale = locale

if locale == "deDE" then -- German [Leilameda]
  L["The chat window \"%s\" already exists.\nAre you sure you wish to overwrite it?\n\nBy overwriting it will reset the messages it shows to default. (Messages like experience, honor, money, reputation, and many others.)"] = "Das Chat fenster \"%s\" existiert bereits.\nBist du dir sicher das du es überschreiben willst?\n\nDadurch werden die gezeigten Meldungen wie erfahrung, Ehre usw zum Standart zurückgesetzt.)"
  L["Disenchant"] = "Entzaubern"
  L["Greed"] = "Gier"
  L["Need"] = "Bedarf"
  L["Pass"] = "Passen"
  L["no loot"] = "keine Beute"
  L["Roll"] = "Wurf um"
  L["N"] = "B"
  L["G"] = "G"
  L["D"] = "E"
  L["P"] = "P"
  L["Note that %s had to reset %d setting(s) due to various reasons. This may happen when you update the addon, in that case please check the addon configurations as some may have been reset to default value."] = "Note that %s had to reset %d setting(s) due to various reasons. This may happen when you update the addon, in that case please check the addon configurations as some may have been reset to default value."
  L["Hide all"] = "Alle verstecken"
  L[" settings"] = " einstellungen"
  L["Set custom font-size if you wish, or change what chat frame the loot is written to."] = "Eigene Schriftgröße festlegen und einstellen in welchem Chatfenster der Loot angezeigt wird."
  L["Font size"] = "Schriftgröße"
  L["Enter \"0\" to let the game decide."] = "Gebe \"0\" ein um das Spiel entscheiden zu lassen"
  L["did the new size fit?"] = "passt die neue Schritfgröße?" 
  L["Output chat"] = "Ausgabe Chat"
  L["This message should have been shown in %s."] = "Diese Meldung sollte in %s dargestellt worden sein."
  L["Filter"] = "Filter"
  L["Filter settings"] = "Filter Einstellungen"
  L["Decide what you see and what is hidden and ignored."] = "Entscheide was du sehen willst und was versteckt und Ignoriert wird"
  L["Hide these events"] = "Verstecke diese Abläufe"
  L["Hide all junk loot"] = "Verstecke Graue Beute"
  L["All items of poor quality will not be shown."] = "Alle Items mit Schlechter Qualität werden nicht gezeigt."
  L["Hide own loot"] = "Verstecke eigegene Beute"
  L["Hide items below specific quality."] = "Verstecke Items unter einer bestimmten Qualität"
  L["Quality threshold"] = "Qualitäts Grenze"
  L["Hide party loot"] = "Verstecke Beute der Gruppe"
  L["Roll settings"] = "Wüfeleinstellungen"
  L["Change the roll handling behavior."] = "Verändere das Wurf Handhabungs Verhalten"
  L["Show roll decisions"] = "Wurf Entscheidungen"
  L["The need/greed decisions are instantly shown."] = "Die Bedarf/Gier entscheidungen werden sofort gezeigt."
  L["Show roll summary"] = "Wurf Zusammenfassung"
  L["Prints the roll results in one line together\nwith the rest of the report."] = "Zeige Würfelergebnisse in einer Zeile zusammen\n mit dem rest des Berichtes."
  L["Show rolls as icons"] = "Zeige Würfe als Icon"
  L["Instead of item links, will show icons at roll related events."] = "Instead of item links, will show icons at roll related events."
  L["Timer"] = "Timer"
  L["Timer settings"] = "Timer einstellungen"
  L["Change how quickly the summary is shown and interval that data is gathered."] = "Verändere wie schnell die zusammenfassung gezeigt wurd und den Interwall in dem die Daten gesammelt werden."
  L["Sleep after combat"] = "Warten nach Kampf"
  L["Sleep between events"] = "Warte zwischen Ereignissen"
  L["Extra"] = "Extra"
  L["Extra features"] = "Extra Funktionen"
  L["Not perhaps a major aspect of the addon, but may be helpful."] = "Not perhaps a major aspect of the addon, but may be helpful."
  L["Original loot chat"] = "Originaler Beute Chat"
  L["This will create an additional chat frame,\ndo not be afraid it will overwrite anything\nbecause it wont."] = "Erstellt einen neuen Chattab, überschreibt nichts!"
  L["Create this window!"] = "Fenster Erstellen!"
  L["Show mouseover links"] = "Zeige mouseover links"
  L["For example when you mouseover an item\nthe tooltip is shown without clicking it."] = "For example when you mouseover an item\nthe tooltip is shown without clicking it."
  L["Anchor to the chat"] = "Am Chat verankern"
  L["Anchor the mouseover tooltip to the top\nof the chat frame."] = "Den mouseover tooltip oben am Chat verankern."
  L["Show tooltip icon"] = "Zeige Icon am Tooltip"
  L["Shows an icon on the side of the tooltip."] = "Shows an icon on the side of the tooltip."
  L["Show lootcount"] = "Zeige Beutezähler"
  L[([=[
The reports will be printed in this chat.
If what you enter is not valid the value will
reset to default.
"ChatFrame2" would print in the Combat log,
"ChatFrame3" would print in a custom chat
you made that is next to the Combat log,
and so forth. Use "/fstack" to find the
name of the frame you wish to use.
]=])] = ([=[
The reports will be printed in this chat.
If what you enter is not valid the value will
reset to default.
"ChatFrame2" would print in the Combat log,
"ChatFrame3" would print in a custom chat
you made that is next to the Combat log,
and so forth. Use "/fstack" to find the
name of the frame you wish to use.
]=])   
  L[([=[
For example "1.5" would make the addon wait
1.5 seconds before printing the report in the
chat. This gives you time to finish looting
after the combat, it would merge the combat-
looters and the loot after combat ended.
Use "-1" to skip combat checking and only
use between events sleep timer. Using "0"
will only instantly display after combat,
not during.
]=])] = ([=[
For example "1.5" would make the addon wait
1.5 seconds before printing the report in the
chat. This gives you time to finish looting
after the combat, it would merge the combat-
looters and the loot after combat ended.
Use "-1" to skip combat checking and only
use between events sleep timer. Using "0"
will only instantly display after combat,
not during.
]=])
  L[([=[
Each time there is an event like item loot,
experience gain, honor gain and such, the addon
waits for a moment to make sure no more events
will come, then when it's "safe" it will report
the findings and await new information.
This timer will decide how long it waits between
an event and until the next one, if no next event
then it reports and continues as normal.
]=])] = ([=[
Each time there is an event like item loot,
experience gain, honor gain and such, the addon
waits for a moment to make sure no more events
will come, then when it's "safe" it will report
the findings and await new information.
This timer will decide how long it waits between
an event and until the next one, if no next event
then it reports and continues as normal.
]=])

elseif locale == "esES" then -- Spanish (European)

elseif locale == "esMX" then -- Spanish (Latin American)

elseif locale == "frFR" then -- French

elseif locale == "koKR" then -- Korean

elseif locale == "ruRU" then -- Russian

elseif locale == "zhCN" then -- Chinese (simplified; China) [SilentWorld]
  L["The chat window \"%s\" already exists.\nAre you sure you wish to overwrite it?\n\nBy overwriting it will reset the messages it shows to default. (Messages like experience, honor, money, reputation, and many others.)"] = "聊天窗口\"%s\"已经存在.\n你确定要覆盖它吗?\n\n覆盖它会重设显示在默认聊天窗口的信息. (经验、荣誉、金钱、声望、等。)"
  L["Disenchant"] = "分解"
  L["Greed"] = "贪婪"
  L["Need"] = "需求"
  L["Pass"] = "放弃"
  L["no loot"] = "无拾取"
  L["Roll"] = "掷骰"
  L["N"] = "需求"
  L["G"] = "贪婪"
  L["D"] = "分解"
  L["P"] = "放弃"
  L["Note that %s had to reset %d setting(s) due to various reasons. This may happen when you update the addon, in that case please check the addon configurations as some may have been reset to default value."] = "这个 %s 已重设为 %d 的设置值，这可能发生在插件更新後，请查看插件设置，有些可能已被重设为默认值。"
  L["Hide all"] = "隐藏全部"
  L[" settings"] = "设置"
  L["Set custom font-size if you wish, or change what chat frame the loot is written to."] = "设置文本字体大小以及变更信息输出的聊天窗口。"
  L["Font size"] = "文本字体大小"
  L["Enter \"0\" to let the game decide."] = "设置 0 将自动调整大小。"
  L["did the new size fit?"] = "新的文本大小合适吗？"  
  L["Output chat"] = "输出聊天窗口"
  L["This message should have been shown in %s."] = "信息将显示在 %s。"
  L["Filter"] = "过滤"
  L["Filter settings"] = "过滤设置"
  L["Decide what you see and what is hidden and ignored."] = "过滤你想看见的以及要隐藏和忽略的。"
  L["Hide these events"] = "隐藏这些事件"
  L["Hide all junk loot"] = "隐藏全部垃圾拾取"
  L["All items of poor quality will not be shown."] = "所有灰色质量的物品将不会显示。"
  L["Hide own loot"] = "隐藏自身拾取"
  L["Hide items below specific quality."] = "隐藏低於指定质量的物品。"
  L["Quality threshold"] = "质量临界值"
  L["Hide party loot"] = "隐藏队伍拾取"
  L["Roll settings"] = "掷骰设置"
  L["Change the roll handling behavior."] = "变更掷骰处理方式。"
  L["Show roll decisions"] = "显示掷骰动作"
  L["The need/greed decisions are instantly shown."] = "需求/贪婪的动作将立即显示。"
  L["Show roll summary"] = "显示掷骰细节"
  L["Prints the roll results in one line together\nwith the rest of the report."] = "将掷骰结果发送独立的一行\n不与其他的报告合并。"
  L["Show rolls as icons"] = "显示掷骰图标"
  L["Instead of item links, will show icons at roll related events."] = "将掷骰相关事件的物品连结显示为图标。"
  L["Timer"] = "延迟"
  L["Timer settings"] = "延迟设置"
  L["Change how quickly the summary is shown and interval that data is gathered."] = "变更细节显示和收集资料的间隔速度。"
  L["Sleep after combat"] = "战斗之後延迟"
  L["Sleep between events"] = "事件之间延迟"
  L["Extra"] = "额外"
  L["Extra features"] = "额外功能"
  L["Not perhaps a major aspect of the addon, but may be helpful."] = "这或许不是插件的主要功能，但可能会有所帮助。"
  L["Original loot chat"] = "独立拾取聊天窗口"
  L["This will create an additional chat frame,\ndo not be afraid it will overwrite anything\nbecause it wont."] = "这将创建一个额外的聊天窗口，\n它不会覆盖任何设置。"
  L["Create this window!"] = "创建聊天窗口！"
  L["Show mouseover links"] = "显示鼠标悬停连结"
  L["For example when you mouseover an item\nthe tooltip is shown without clicking it."] = "当你鼠标悬停於一个物品\n无须点击即可显示物品的工具提示。"
  L["Anchor to the chat"] = "提示位置定位"
  L["Anchor the mouseover tooltip to the top\nof the chat frame."] = "定位工具提示在聊天窗口的顶端。"
  L["Show tooltip icon"] = "显示工具提示图标"
  L["Shows an icon on the side of the tooltip."] = "在工具提示信息中显示图标。"
  L[([=[
The reports will be printed in this chat.
If what you enter is not valid the value will
reset to default.
"ChatFrame2" would print in the Combat log,
"ChatFrame3" would print in a custom chat
you made that is next to the Combat log,
and so forth. Use "/fstack" to find the
name of the frame you wish to use.
]=])] = ([=[
报告将会发送到你设置聊天窗口。
如果您输入无效的值将会重设为插件默认值。
"ChatFrame2"将会发送到战斗记录窗口中，
"ChatFrame3"将会发送到你自订的窗口中。
使用"/fstack"指令可开启窗口侦测工具。
]=])   
  L[([=[
For example "1.5" would make the addon wait
1.5 seconds before printing the report in the
chat. This gives you time to finish looting
after the combat, it would merge the combat-
looters and the loot after combat ended.
Use "-1" to skip combat checking and only
use between events sleep timer. Using "0"
will only instantly display after combat,
not during.
]=])] = ([=[
如果设置为"1.5"将使插件在发送报告到聊天窗口前等待1.5秒。
这让你在战斗之後有时间来完成拾取动作，如果还在时间范围内，
它会将战斗中的拾取和战斗结束後的拾取合并。
如果设置为"-1"忽略战斗查看只使用事件之间的延迟时间。
如果设置为"0"将只会在战斗後才显示。
]=])
  L[([=[
Each time there is an event like item loot,
experience gain, honor gain and such, the addon
waits for a moment to make sure no more events
will come, then when it's "safe" it will report
the findings and await new information.
This timer will decide how long it waits between
an event and until the next one, if no next event
then it reports and continues as normal.
]=])] = ([=[
每次有一个类似的物品拾取事件，
该插件将会等待一段时间，以确保没有更多的动作，
当它"超过时间范围"时将会发送报告，并等待新的信息。
此时间决定两个事件之间等待的时间，
如果没有下一个事件那麽它将会发送报告，并继续正常运作。
]=])

elseif locale == "zhTW" then -- Chinese (traditional; Taiwan) [SilentWorld, BNS]
  L["The chat window \"%s\" already exists.\nAre you sure you wish to overwrite it?\n\nBy overwriting it will reset the messages it shows to default. (Messages like experience, honor, money, reputation, and many others.)"] = "聊天視窗\"%s\"已經存在.\n你確定要覆蓋它嗎?\n\n覆蓋它會重設顯示在預設聊天視窗的訊息. (經驗、榮譽、金錢、聲望、等。)"
  L["Disenchant"] = "分解"
  L["Greed"] = "貪婪"
  L["Need"] = "需求"
  L["Pass"] = "放棄"
  L["no loot"] = "無拾取"
  L["Roll"] = "擲骰"
  L["N"] = "需求"
  L["G"] = "貪婪"
  L["D"] = "分解"
  L["P"] = "放棄"
  L["Note that %s had to reset %d setting(s) due to various reasons. This may happen when you update the addon, in that case please check the addon configurations as some may have been reset to default value."] = "這個 %s 已重設為 %d 的設定值，這可能發生在插件更新後，請檢查插件設置，有些可能已被重設為預設值。"
  L["Hide all"] = "隱藏全部"
  L[" settings"] = "設定"
  L["Set custom font-size if you wish, or change what chat frame the loot is written to."] = "設定文字字型大小以及變更掉訊息輸出的聊天視窗。"
  L["Font size"] = "文字字型大小"
  L["Enter \"0\" to let the game decide."] = "設定 0 將自動調整大小。"
  L["did the new size fit?"] = "新的文字大小合適嗎？"  
  L["Output chat"] = "輸出聊天視窗"
  L["This message should have been shown in %s."] = "訊息將顯示在 %s。"
  L["Filter"] = "過濾"
  L["Filter settings"] = "過濾設定"
  L["Decide what you see and what is hidden and ignored."] = "過濾你想看見的以及要隱藏和忽略的。"
  L["Hide these events"] = "隱藏這些事件"
  L["Hide all junk loot"] = "隱藏全部垃圾拾取"
  L["All items of poor quality will not be shown."] = "所有灰色品質的物品將不會顯示。"
  L["Hide own loot"] = "隱藏自身拾取"
  L["Hide items below specific quality."] = "隱藏低於指定品質的物品。"
  L["Quality threshold"] = "品質臨界值"
  L["Hide party loot"] = "隱藏隊伍拾取"
  L["Roll settings"] = "擲骰設定"
  L["Change the roll handling behavior."] = "變更擲骰處理方式。"
  L["Show roll decisions"] = "顯示擲骰動作"
  L["The need/greed decisions are instantly shown."] = "需求/貪婪的動作將立即顯示。"
  L["Show roll summary"] = "顯示擲骰細節"
  L["Prints the roll results in one line together\nwith the rest of the report."] = "將擲骰結果發送獨立的一行\n不與其他的報告合併。"
  L["Show rolls as icons"] = "顯示擲骰圖示"
  L["Instead of item links, will show icons at roll related events."] = "將擲骰相關事件的物品連結顯示為圖示。"
  L["Timer"] = "延遲"
  L["Timer settings"] = "延遲設定"
  L["Change how quickly the summary is shown and interval that data is gathered."] = "變更細節顯示和收集資料的間隔速度。"
  L["Sleep after combat"] = "戰鬥之後延遲"
  L["Sleep between events"] = "事件之間延遲"
  L["Extra"] = "額外"
  L["Extra features"] = "額外功能"
  L["Not perhaps a major aspect of the addon, but may be helpful."] = "這或許不是插件的主要功能，但可能會有所幫助。"
  L["Original loot chat"] = "獨立拾取聊天視窗"
  L["This will create an additional chat frame,\ndo not be afraid it will overwrite anything\nbecause it wont."] = "這將建立一個額外的聊天視窗，\n它不會覆蓋任何設定。"
  L["Create this window!"] = "建立聊天視窗！"
  L["Show mouseover links"] = "顯示游標懸停連結"
  L["For example when you mouseover an item\nthe tooltip is shown without clicking it."] = "當你游標懸停於一個物品\n無須點擊即可顯示物品的工具提示。"
  L["Anchor to the chat"] = "提示位置定位"
  L["Anchor the mouseover tooltip to the top\nof the chat frame."] = "定位工具提示在聊天視窗的頂端。"
  L["Show tooltip icon"] = "顯示工具提示圖示"
  L["Shows an icon on the side of the tooltip."] = "在工具提示訊息中顯示圖示。"
  L[([=[
The reports will be printed in this chat.
If what you enter is not valid the value will
reset to default.
"ChatFrame2" would print in the Combat log,
"ChatFrame3" would print in a custom chat
you made that is next to the Combat log,
and so forth. Use "/fstack" to find the
name of the frame you wish to use.
]=])] = ([=[
報告將會發送到你設定聊天視窗。
如果您輸入無效的值將會重設為插件預設值。
"ChatFrame2"將會發送到戰鬥記錄視窗中，
"ChatFrame3"將會發送到你自訂的視窗中。
使用"/fstack"指令可開啟視窗偵測工具。
]=])
  L[([=[
For example "1.5" would make the addon wait
1.5 seconds before printing the report in the
chat. This gives you time to finish looting
after the combat, it would merge the combat-
looters and the loot after combat ended.
Use "-1" to skip combat checking and only
use between events sleep timer. Using "0"
will only instantly display after combat,
not during.
]=])] = ([=[
如果設定為"1.5"將使插件在發送報告到聊天視窗前等待1.5秒。
這讓你在戰鬥之後有時間來完成拾取動作，如果還在時間範圍內，
它會將戰鬥中的拾取和戰鬥結束後的拾取合併。
如果設定為"-1"忽略戰鬥檢查只使用事件之間的延遲時間。
如果設定為"0"將只會在戰鬥後才顯示。
]=])
  L[([=[
Each time there is an event like item loot,
experience gain, honor gain and such, the addon
waits for a moment to make sure no more events
will come, then when it's "safe" it will report
the findings and await new information.
This timer will decide how long it waits between
an event and until the next one, if no next event
then it reports and continues as normal.
]=])] = ([=[
每次有一個類似的物品拾取事件，
該插件將會等待一段時間，以確保沒有更多的動作，
當它"超過時間範圍"時將會發送報告，並等待新的訊息。
此時間決定兩個事件之間等待的時間，
如果沒有下一個事件那麼它將會發送報告，並繼續正常運作。
]=])

end
