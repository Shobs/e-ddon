local L = LibStub("AceLocale-3.0"):NewLocale("ExtVendor", "enUS", true)

if L then

L["LOADED_MESSAGE"] = "Version %s loaded.";
L["ADDON_TITLE"] = "Extended Vendor UI";

L["SELL_JUNK_TOOLTIP"] = "Sell all junk (gray) items";

L["CONFIRM_SELL_JUNK"] = "Do you want to sell the following items:";
L["TOTAL_SALE_PRICE"] = "Total sale price";

L["SOLD"] = "Sold:";
L["JUNK_MONEY_EARNED"] = "Money earned from junk items: %s";

L["HIDE_UNUSABLE"] = "Usable Items";
L["HIDE_FILTERED"] = "Hide Filtered";
L["OPTIMAL_ARMOR"] = "Optimal Armor";
L["FILTER_SUBOPTIMAL"] = "Filter Suboptimal Armor";
L["NEVER_HIDE"] = "Never Hide";
L["QUALITY_FILTER_MINIMUM"] = "Quality (Minimum)";
L["QUALITY_FILTER_SPECIFIC"] = "Quality (Specific)";

L["ARMOR"] = "Armor";
L["ARMOR_CLOTH"] = "Cloth";
L["ARMOR_LEATHER"] = "Leather";
L["ARMOR_MAIL"] = "Mail";
L["ARMOR_PLATE"] = "Plate";

end
