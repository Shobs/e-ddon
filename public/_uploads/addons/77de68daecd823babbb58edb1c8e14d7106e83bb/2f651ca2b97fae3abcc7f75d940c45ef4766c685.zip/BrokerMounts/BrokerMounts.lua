local LDB

local menu = {}
local parent = CreateFrame('Frame')

local startChar = {
	["AB"] = {
	},
	["CD"] = {
	},
	["EF"] = {
	},
	["GH"] = {
	},
	["IJ"] = {
	},
	["KL"] = {
	},
	["MN"] = {
	},
	["OP"] = {
	},
	["QR"] = {
	},
	["ST"] = {
	},
	["UV"] = {
	},
	["WX"] = {
	},
	["YZ"] = {
	}
}

local function pairsByKeys (startChar, f)
	local a = {}
		for n in pairs(startChar) do table.insert(a, n) end
		table.sort(a, f)
		local i = 0      -- iterator variable
		local iter = function ()   -- iterator function
			i = i + 1
			if a[i] == nil then return nil
			else return a[i], startChar[a[i]]
			end
		end
	return iter
end

local function UpdateDisplay()
	if lastmountIndex ~= nil then
		LDB.text = lastmountText
		LDB.icon = lastmountIcon
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", lastmountIndex) -- check to see if a new companion was learned and moved the index of the last
		if creatureName ~= lastmountText then
			for i = 1, GetNumCompanions("MOUNT") do
			local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", i)
			if creatureName == lastmountText then
				lastmountIndex = i
			end
			end
		end
	end
	
	if favmount1index ~= nil  then
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", favmount1index)
		if creatureName ~= favmount1name then
			for i = 1, GetNumCompanions("MOUNT") do
			local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", i)
			if creatureName == favmount1name then
				favmount1index = i
			end
			end
		end
	end
	if favmount2index ~= nil  then
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", favmount2index)
		if creatureName ~= favmount2name then
			for i = 1, GetNumCompanions("MOUNT") do
			local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", i)
			if creatureName == favmount2name then
				favmount2index = i
			end
			end
		end
	end
	if favmount3index ~= nil  then
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", favmount3index)
		if creatureName ~= favmount3name then
			for i = 1, GetNumCompanions("MOUNT") do
			local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", i)
			if creatureName == favmount3name then
				favmount3index = i
			end
			end
		end
	end
	
	for i = 1, GetNumCompanions("MOUNT") do
	local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", i)
		if issummoned then
			LDB.text = creatureName
			LDB.icon = icon
			lastmountIcon = icon
			lastmountIndex = i
			lastmountSpell = creatureSpellID
			lastmountText = creatureName
			return
		end
		if lastmountSpell ~= nil and lastmountText ~= nil then
		local isUsable, notEnoughMana = IsUsableSpell(lastmountSpell)
			if isUsable then
				LDB.text = lastmountText
			else
				LDB.text = string.format('|cff848484%s|r', lastmountText)
			end
		end
	end
end

local function ModifiedClick(button, i)	
local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", i)
	if IsShiftKeyDown() then
		PickupCompanion("MOUNT", i)
	elseif IsAltKeyDown()and not IsControlKeyDown()  then
		favmount1index = i
		favmount1name = creatureName
		favmount1icon = icon
		DEFAULT_CHAT_FRAME:AddMessage(string.format("|cffffff00BrokerMounts:|r %s added as favorite 1.", creatureName))
	elseif IsControlKeyDown() and not IsAltKeyDown() then
		favmount2index = i
		favmount2name = creatureName
		favmount2icon = icon
		DEFAULT_CHAT_FRAME:AddMessage(string.format("|cffffff00BrokerMounts:|r %s added as favorite 2.", creatureName))
	elseif IsControlKeyDown() and IsAltKeyDown() then
		favmount3index = i
		favmount3name = creatureName
		favmount3icon = icon
		DEFAULT_CHAT_FRAME:AddMessage(string.format("|cffffff00BrokerMounts:|r %s added as favorite 3.", creatureName))
	else
		CallCompanion("MOUNT", i)
	end
end

local function OnTooltipShow(self)
	self:AddLine('|cff00ffffBrokerMounts|r')
	self:AddLine("<Right Click> to open mount list")
	self:AddLine("<Left Click> to mount/dismount")
	self:AddLine("<Shift-Left Click> on mount to pick it up")
	self:AddLine("<ALT-Click> mount to set as favorite 1")
	self:AddLine("<CTRL-Click> mount to set as favorite 2")
	self:AddLine("<CTRL-ALT-Click> mount to set as favorite 3")
	if GetNumCompanions("MOUNT") == 0 then
	self:AddLine("|cffff0000You have no mounts|r")
	else
	self:AddLine(string.format("|cff00ff00You have %s mounts|r", GetNumCompanions("MOUNT")))
	end
end

local function OnClick(self, button)
	if button == 'RightButton' then
		ToggleDropDownMenu(1, nil, parent, self, 0, 0)
	end
	if button == 'LeftButton' then
		if IsMounted() then
			Dismount()
		elseif lastmountIndex ~= nil then
			CallCompanion("MOUNT", lastmountIndex)
		end
	end
end

local function CreateMenu(self, level)
	menu = wipe(menu)
	local firstChar
	if 	GetNumCompanions("MOUNT") <= 20 then
	for i = 1, GetNumCompanions("MOUNT") do
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", i)
		local isUsable, notEnoughMana = IsUsableSpell(creatureSpellID)
		menu.text = creatureName
		menu.icon = icon
		menu.colorCode = "|cffffffff"
		menu.func = ModifiedClick
		menu.arg1 = i
		menu.notCheckable = 1
		if not isUsable then
			menu.colorCode = "|cff848484"
		end
		if issummoned then
			menu.colorCode = "|cff00ff00"
		end
		UIDropDownMenu_AddButton(menu)
	end
	elseif GetNumCompanions("MOUNT") >= 21 then
	level = level or 1;
	if (level == 1) then
	for key, v in pairsByKeys(startChar) do
		menu.text = key
		menu.notCheckable = 1
		menu.hasArrow = true;
		menu.value = {
			["Level1_Key"] = key;
		};
	
		UIDropDownMenu_AddButton(menu, level)
	end
		if favmount1index ~= nil then
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", favmount1index)
		local isUsable, notEnoughMana = IsUsableSpell(creatureSpellID)
			menu.text = format('1. %s', favmount1name)
			menu.icon = favmount1icon
			menu.colorCode = "|cffffffff"
			menu.func = ModifiedClick
			menu.arg1 = favmount1index
			menu.hasArrow = nil;
			menu.notCheckable = 1
			if not isUsable then
				menu.colorCode = "|cff848484"
			end
			if issummoned then
				menu.colorCode = "|cff00ff00"
			end
			UIDropDownMenu_AddButton(menu, level)
		end
		if favmount2index ~= nil then
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", favmount2index)
		local isUsable, notEnoughMana = IsUsableSpell(creatureSpellID)
			menu.text = format('2. %s', favmount2name)
			menu.icon = favmount2icon
			menu.colorCode = "|cffffffff"
			menu.func = ModifiedClick
			menu.arg1 = favmount2index
			menu.hasArrow = nil;
			menu.notCheckable = 1
			if not isUsable then
				menu.colorCode = "|cff848484"
			end
			if issummoned then
				menu.colorCode = "|cff00ff00"
			end
			UIDropDownMenu_AddButton(menu, level)
		end
		if favmount3index ~= nil then
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", favmount3index)
		local isUsable, notEnoughMana = IsUsableSpell(creatureSpellID)
			menu.text = format('3. %s', favmount3name)
			menu.icon = favmount3icon
			menu.colorCode = "|cffffffff"
			menu.func = ModifiedClick
			menu.arg1 = favmount3index
			menu.hasArrow = nil;
			menu.notCheckable = 1
			if not isUsable then
				menu.colorCode = "|cff848484"
			end
			if issummoned then
				menu.colorCode = "|cff00ff00"
			end
			UIDropDownMenu_AddButton(menu, level)
		end
	end
	if (level == 2) then
	 -- getting values of first menu
    local Level1_Key = UIDROPDOWNMENU_MENU_VALUE["Level1_Key"];
		
    for i = 1, GetNumCompanions("MOUNT") do
		
		local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", i)
		local isUsable, notEnoughMana = IsUsableSpell(creatureSpellID)
		firstChar = strupper(strsub(creatureName, 1, 1))

		menu.hasArrow = false;
		menu.notCheckable = true;
		menu.text = creatureName
		menu.icon = icon
		menu.colorCode = "|cffffffff"
		menu.func = ModifiedClick
		menu.arg1 = i
		
		if not isUsable then
			menu.colorCode = "|cff848484"
		end
		if issummoned then
			menu.colorCode = "|cff00ff00"
		end
		
		if firstChar >= "A" and firstChar <= "B" and Level1_Key == "AB" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "C" and firstChar <= "D" and Level1_Key == "CD" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "E" and firstChar <= "F" and Level1_Key == "EF" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "G" and firstChar <= "H" and Level1_Key == "GH" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "I" and firstChar <= "J" and Level1_Key == "IJ" then
			UIDropDownMenu_AddButton(menu, level)
		end
	
		if firstChar >= "K" and firstChar <= "L" and Level1_Key == "KL" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "M" and firstChar <= "N" and Level1_Key == "MN" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "O" and firstChar <= "P" and Level1_Key == "OP" then
			UIDropDownMenu_AddButton(menu, level)
		end
	
		if firstChar >= "Q" and firstChar <= "R" and Level1_Key == "QR" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "S" and firstChar <= "T" and Level1_Key == "ST" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "U" and firstChar <= "V" and Level1_Key == "UV" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "W" and firstChar <= "X" and Level1_Key == "WX" then
			UIDropDownMenu_AddButton(menu, level)
		end
		
		if firstChar >= "Y" and firstChar <= "Z" and Level1_Key == "YZ" then
			UIDropDownMenu_AddButton(menu, level)
		end
	
	end
	end
	end

end

function parent:PLAYER_LOGIN()
	LDB = LibStub('LibDataBroker-1.1'):NewDataObject('BrokerMounts', {
		icon = "Interface\\Icons\\INV_Misc_QuestionMark.blp",
		text = "BrokerMounts",
		type = 'data source',
		OnTooltipShow = OnTooltipShow,
		OnClick = OnClick,
	})
	self:RegisterEvent('SPELL_UPDATE_USABLE')
	self:RegisterEvent('COMPANION_UPDATE')
	self.COMPANION_UPDATE = UpdateDisplay
	self.SPELL_UPDATE_USABLE = UpdateDisplay

	self.initialize = CreateMenu
	self.displayMode = 'MENU'
	
	UpdateDisplay()
end

parent:SetScript('OnEvent', function(self, event, ...) self[event](self, ...) end)
parent:RegisterEvent('PLAYER_LOGIN')