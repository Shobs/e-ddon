local Version = "1.0"
local Loaded = false

AltsMail_OrigGetAutoCompleteResults = nil
local RealmName
local MyAlts = { }

local menu
local expandButton

local settingsFrame = nil
local searchAlts, searchGroup, searchGuild, searchFriend, searchBnet, searchInteracted, searchOnline, searchAll
local searchFlag = AUTOCOMPLETE_FLAG_ALL
local mailOpen = false

local AUTOCOMPLETE_FLAG_ALTS 			= 0x100

local function OnCharHandler(s)

	local name = s:GetText()

	if ( strlen(name) <= 0 ) then
		return
	end

	local completedName = (
		AltsMail_GetAutoCompleteAltResults(name) or
		AltsMail_OrigGetAutoCompleteResults(name, searchFlag, 0, 1)
	)

	local completedNameRemainderPosition = s:GetCursorPosition()
	if completedName then
		s:SetText(completedName)
		s:HighlightText(completedNameRemainderPosition, strlen(completedName))
	end

	-- to keep the new auto complete functionality
	AutoComplete_Update(s, name, completedNameRemainderPosition)
	SendMailFrame_Update()
end

local function NewGetAutoCompleteResults(t, include, exclude, maxResults, ...)
	local result
	if not(mailOpen) then
		result = { AltsMail_OrigGetAutoCompleteResults(t, include, exclude, maxResults, ...) }
		return unpack(result)
	else
		result = { AltsMail_OrigGetAutoCompleteResults(t, searchFlag, exclude, maxResults, ...) }
	end

	local k, v, ik, iv
	if (searchAlts) then
		for k, v in ipairs { AltsMail_GetAutoCompleteAltResults(t) } do
			local found = 0
			for ik, iv in ipairs(result) do
				if ( v == iv ) then
					found = 1
				end
			end

			if ( found == 0 ) then
				table.insert(result, v)
			end
		end
	end

	table.sort(result)

	local i = table.getn(result)
	while ( i > maxResults ) do
		table.remove(result)
		i=i-1
	end

	return unpack(result)
end

function AltsMail_GetAutoCompleteAltResults(t)

	local result = { }

	local text = string.lower(t)
	local textlen = strlen(text)

	for name, _ in pairs(MyAlts) do
		if (( strlen(name) >= textlen ) and ( string.sub(string.lower(name), 1, textlen) == text )) then
			table.insert(result, name)
		end
	end

	return unpack(result)
end

local function SetSearchFlag()
	searchFlag = 0
	if searchAll then
		searchFlag = searchFlag + AUTOCOMPLETE_FLAG_ALL
		return searchFlag
	end
	
	if searchAlts then
		searchFlag = searchFlag + AUTOCOMPLETE_FLAG_ALTS
	end
	if searchGroup then
		searchFlag = searchFlag + AUTOCOMPLETE_FLAG_IN_GROUP
	end
	if searchGuild then
		searchFlag = searchFlag + AUTOCOMPLETE_FLAG_IN_GUILD
	end
	if searchFriend then
		searchFlag = searchFlag + AUTOCOMPLETE_FLAG_FRIEND
	end
	if searchBnet then
		searchFlag = searchFlag + AUTOCOMPLETE_FLAG_BNET
	end
	if searchInteracted then
		searchFlag = searchFlag + AUTOCOMPLETE_FLAG_INTERACTED_WITH
	end
	if searchOnline then
		searchFlag = searchFlag + AUTOCOMPLETE_FLAG_ONLINE
	end
	return searchFlag
end

local function ParseSearchFlag(flag)
	if searchFlag == AUTOCOMPLETE_FLAG_ALL then
		searchAll = true
	end
	searchAlts = bit.band(flag, AUTOCOMPLETE_FLAG_ALTS) ~= 0
	searchGroup = bit.band(flag, AUTOCOMPLETE_FLAG_IN_GROUP) ~= 0
	searchGuild = bit.band(flag, AUTOCOMPLETE_FLAG_IN_GUILD) ~= 0
	searchFriend = bit.band(flag, AUTOCOMPLETE_FLAG_FRIEND) ~= 0
	searchBnet = bit.band(flag, AUTOCOMPLETE_FLAG_BNET) ~= 0
	searchInteracted = bit.band(flag, AUTOCOMPLETE_FLAG_INTERACTED_WITH) ~= 0
	searchOnline = bit.band(flag, AUTOCOMPLETE_FLAG_ONLINE) ~= 0
end

function AltsMailSettings_MenuItemChecked(self)
	--print(self.value.." checked "..tostring(self.checked))
	if self.value == "Alts" then
		searchAlts = self.checked
	end
	if self.value == "Group" then
		searchGroup = self.checked
	end
	if self.value == "Guild" then
		searchGuild = self.checked
	end
	if self.value == "Friend" then
		searchFriend = self.checked
	end
	if self.value == "Bnet" then
		searchBnet = self.checked
	end
	if self.value == "Interacted" then
		searchInteracted = self.checked
	end
	if self.value == "Online" then
		searchOnline = self.checked
	end
	if self.value == "All" then
		searchAll = self.checked
	end

	SetSearchFlag()
	--print(string.format("flag %X", searchFlag))

	AltsMail_Alts["searchFlag"] = searchFlag
end

local function expandButton_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	if (self.expanded) then
		GameTooltip:SetText(HIGHLIGHT_FONT_COLOR_CODE..self.collapseTooltip..FONT_COLOR_CODE_CLOSE)
	else
		GameTooltip:SetText(HIGHLIGHT_FONT_COLOR_CODE..self.expandTooltip..FONT_COLOR_CODE_CLOSE)
	end
end

local function expandButton_OnLeave(self)
	GameTooltip:Hide()
end

local function setExpandButtonTextures(self)
	if (self.expanded) then
		self:SetNormalTexture([[Interface\Buttons\UI-SpellbookIcon-PrevPage-Up]])
		self:SetPushedTexture([[Interface\Buttons\UI-SpellbookIcon-PrevPage-Down]])
		self:SetDisabledTexture([[Interface\Buttons\UI-SpellbookIcon-PrevPage-Disabled]])
	else
		self:SetNormalTexture([[Interface\Buttons\UI-SpellbookIcon-NextPage-Up]])
		self:SetPushedTexture([[Interface\Buttons\UI-SpellbookIcon-NextPage-Down]])
		self:SetDisabledTexture([[Interface\Buttons\UI-SpellbookIcon-NextPage-Disabled]]) 		
	end
end

local function expandButton_OnClick(self)
	if (self.expanded) then
		PlaySound("igCharacterInfoClose")
	else
		PlaySound("igCharacterInfoOpen")
	end
	self.expanded = not(self.expanded)
	setExpandButtonTextures(self)
	if (GameTooltip:GetOwner() == self) then
		self:GetScript("OnEnter")(self)
	end

	if (self.expanded) then
		menu[2].checked = searchAlts
		menu[3].checked = searchGroup
		menu[4].checked = searchGuild
		menu[5].checked = searchFriend
		menu[6].checked = searchBnet
		menu[7].checked = searchInteracted
		menu[8].checked = searchOnline
		menu[9].checked = searchAll
		EasyMenu(menu, self, expandButton, 0, 0, nil)
	else
		CloseDropDownMenus(1)
	end
end

function AltsMail_CloseSettings()
	expandButton_OnClick(expandButton)
end

-- slash handlers

local function SlashTable_help(rest)
	print("AltsMail slash commands:")
	print("help - shows available slash commands")
	print("show - shows your stored alt character's names")
	print("add altname - to add your alt character name")
	print("remove altname - to remove your alt character name")
end

local function SlashTable_show(rest)
	for name, lastLogin in pairs(AltsMail_Alts[RealmName]) do
		print(name)
	end
end

local function SlashTable_add(name)
	if name ~= "" then
		local now = time()		
		AltsMail_Alts[RealmName][name] = now
		MyAlts[name] = 1
	end
end

local function SlashTable_remove(name)
	if name ~= "" then
		AltsMail_Alts[RealmName][name] = nil
		MyAlts[name] = nil
	end
end

local SlashTable = {
	{
		['name'] = 'show',
		['hint'] = "show alt names",
		['func'] = SlashTable_show,
	},
	{
		['name'] = 'add',
		['hint'] = "add alt name",
		['func'] = SlashTable_add,
	},
	{
		['name'] = 'remove',
		['hint'] = "remove alt name",
		['func'] = SlashTable_remove,
	}
}

local function SlashHandler(msg, editbox)
	local command, rest = msg:match("^(%S*)%s*(.-)$")
	-- Any leading non-whitespace is captured into command
	-- the rest (minus leading whitespace) is captured into rest.
	command = string.lower(command)
	
	if (command == "") or (command == "help") then
		print("AltsMail slash commands:\n/AltsMail, params:")
		for _, v in ipairs(SlashTable) do
			print(v.name.." : "..v.hint)
		end
	else
		local found = false
		for _, v in ipairs(SlashTable) do
			if v.name == command then
				found = true
				v.func(rest)
				break
			end
		end
		
		if not(found) then
			print("unknown command '"..command.."'")
		end
	end
end

local function initialize()

	if ( Loaded ) then
		return
	end
	Loaded = true

	RealmName = GetCVar("realmName")

	if ( AltsMail_Alts == nil ) then
		AltsMail_Alts = { }
	end

	if ( AltsMail_Alts[RealmName] == nil ) then
		AltsMail_Alts[RealmName] = { }
	end

	local now = time()
	local myName = UnitName("player")

	if ( ( AltsMail_Alts[RealmName][myName] == nil ) or
	     ( AltsMail_Alts[RealmName][myName] > 0 ) ) then
		AltsMail_Alts[RealmName][myName] = now
	end

	for name, lastLogin in pairs(AltsMail_Alts[RealmName]) do
		if ( ( AltsMail_Alts[RealmName][name] >= 0 ) and
		     ( name ~= myName ) ) then
			MyAlts[name] = 1
		end
	end

	AltsMail_OrigGetAutoCompleteResults = GetAutoCompleteResults
	GetAutoCompleteResults = NewGetAutoCompleteResults

	SendMailNameEditBox:SetScript("OnTextChanged", nil)
	SendMailNameEditBox:SetScript("OnChar", OnCharHandler)

	if not(AltsMail_Alts["searchFlag"]) then
		searchFlag = AUTOCOMPLETE_FLAG_ALL
	else
		searchFlag = AltsMail_Alts["searchFlag"]
	end
	
	ParseSearchFlag(searchFlag)

	if expandButton == nil then
		expandButton = CreateFrame("Button", "AltsMailExpandButton", SendMailFrame)
		expandButton:SetWidth(32)
		expandButton:SetHeight(32)
		
		expandButton.expanded = false
		
		setExpandButtonTextures(expandButton)
		expandButton:SetHighlightTexture([[Interface\Buttons\UI-Common-MouseHilight]])
		expandButton.collapseTooltip = "Hide filters"
		expandButton.expandTooltip = "Show filters"
		expandButton:SetScript("OnEnter", expandButton_OnEnter)
		expandButton:SetScript("OnLeave", expandButton_OnLeave)
		expandButton:SetScript("OnClick", expandButton_OnClick)
		
		expandButton:ClearAllPoints()
		expandButton:SetPoint("BOTTOMLEFT", SendMailNameEditBox, "BOTTOMRIGHT", 0, -6)
		expandButton:SetFrameLevel(expandButton:GetParent():GetFrameLevel() + 2)
	end
	
	if menu == nil then
		menu = {
			{ text = "Search filters", isTitle = true, notCheckable = true, justifyH = "CENTER"},
			{ text = "Alts", value = text, func = AltsMailSettings_MenuItemChecked, checked = searchAlts, keepShownOnClick = true },
			{ text = "Group", value = text, func = AltsMailSettings_MenuItemChecked, checked = searchGroup, keepShownOnClick = true },
			{ text = "Guild", value = text, func = AltsMailSettings_MenuItemChecked, checked = searchGuild, keepShownOnClick = true },
			{ text = "Friend", value = text, func = AltsMailSettings_MenuItemChecked, checked = searchFriend, keepShownOnClick = true },
			{ text = "Bnet", value = text, func = AltsMailSettings_MenuItemChecked, checked = searchBnet, keepShownOnClick = true },
			{ text = "Interacted", value = text, func = AltsMailSettings_MenuItemChecked, checked = searchInteracted, keepShownOnClick = true },
			{ text = "Online", value = text, func = AltsMailSettings_MenuItemChecked, checked = searchOnline, keepShownOnClick = true },
			{ text = "All", value = text, func = AltsMailSettings_MenuItemChecked, checked = searchAll, keepShownOnClick = true },
		}
	end

	SLASH_ALTSMAIL1 = "/AltsMail"
	SlashCmdList["ALTSMAIL"] = SlashHandler
end

local function EventHandler(self, event, ...)

	if ( event == "ADDON_LOADED" ) then
		local addon = ...
		if ( addon == nil ) then
			return
		end
			
		if ( addon == "AltsMail" ) then
			self:UnregisterEvent("ADDON_LOADED")
			initialize()
		end

	elseif event == "MAIL_SHOW" then
		mailOpen = true
	elseif event == "MAIL_CLOSED" then
		mailOpen = false
		if expandButton.expanded then
			expandButton_OnClick(expandButton)
		end
	end
end

-- main
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("MAIL_SHOW")
frame:RegisterEvent("MAIL_CLOSED")
frame:SetScript("OnEvent", EventHandler)

