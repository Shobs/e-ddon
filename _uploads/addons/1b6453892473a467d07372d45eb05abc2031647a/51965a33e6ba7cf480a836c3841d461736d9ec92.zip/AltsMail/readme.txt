You can select in send mail dialog autocomplete for:

 * One of your alts
 * One of your friends who is online
 * One of your guildies who is online
 * One of your friends who is offline
 * One of your guildies who is offline
 * Someone you interacted with

Changes:

v1.01
added slash handlers to show, add and remove alts